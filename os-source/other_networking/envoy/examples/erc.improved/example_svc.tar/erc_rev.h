#define	VERSION		1
#define	REVISION	1
#define	DATE	"8.6.92"
#define	VERS	"erc 1.1"
#define	VSTRING	"erc 1.1 (8.6.92)\n\r"
#define	VERSTAG	"\0$VER: erc 1.1 (8.6.92)"
