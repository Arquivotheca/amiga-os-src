#include     <stdio.h>
#include     "nipcbase.h"


main()
{

    printf("struct StartMessage : %ld\n",sizeof(struct StartMessage));
    printf("struct NBase : %ld\n",sizeof(struct NBase));

}
