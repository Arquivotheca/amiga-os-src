
#include <stdio.h>
#include "nipcinternal.h"
#include "externs.h"

main()
{

 printf("size is %lx\n",sizeof(struct NBase));


}
