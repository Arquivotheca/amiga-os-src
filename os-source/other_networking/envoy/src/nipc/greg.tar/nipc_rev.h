#define	VERSION		37
#define	REVISION	114
#define	DATE	"12.4.93"
#define	VERS	"nipc 37.114"
#define	VSTRING	"nipc 37.114 (12.4.93)\n\r"
#define	VERSTAG	"\0$VER: nipc 37.114 (12.4.93)"
