#define	VERSION		1
#define	REVISION	9
#define	DATE	"20.2.92"
#define	VERS	"nipc.library 1.9"
#define	VSTRING	"nipc.library 1.9 (20.2.92)\n\r"
#define	VERSTAG	"\0$VER: nipc.library 1.9 (20.2.92)"
