#define	VERSION		37
#define	REVISION	85
#define	DATE	"2.12.92"
#define	VERS	"nipc.library 37.85"
#define	VSTRING	"nipc.library 37.85 (2.12.92)\n\r"
#define	VERSTAG	"\0$VER: nipc.library 37.85 (2.12.92)"
