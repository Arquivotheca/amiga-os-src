/****************************************************************************

    PROGRAM: photo.c

    PURPOSE: Loads PhotoCD images into DIBs, displays them, etc.

    FUNCTIONS:

        WinMain() - calls initialization function, processes message loop
        InitApplication() - initializes window data and registers window
        InitInstance() - saves instance handle and creates main window
        MainWndProc() - processes messages
        OpenDlg() - let user select a file, and open it.
        UpdateListBox() - Update the list box of OpenDlg
        ChangeDefExt() - Change the default extension
        SeparateFile() - Separate filename and pathname
        AddExt() - Add default extension

****************************************************************************/

#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <errno.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "pcdovw.h"

#include "showdib.h"
#include "photo.h"
#include "image.h"
#include "pcdcbf.h"

#include "ppal.h"
#include <time.h>

long    planeBytes = 1;
short   columnBytes = 3;


/***************************************************************************\
*
* - Function name:     CalcBufferAddr
*
* - Description:      Compute the buffer address to hold the image rectangle
*              which is to be inserted into the destination rectangle.
*
* - Arguments:       PCDphotoHdl - toolkit data handle
*              *source rectangle
*              *destination rectangle
*              full buffer pointer
*              *Stride value (which is a return var)
*
* - Returns:        address of buffer needed to hold sub-image.
*
* - Side effects:      None.
*
* - Notes:         This function assumes that you have set up the toolkit
*              properly before calling.
*
* ToolKit Functions Used: PCDgetBytesPerRow
*              PCDgetPlaneColumn
*
* - Author:         Jerry Shields.
*
* - Created:        07/02/91
*
\***************************************************************************/
PCDRAWDATA
CalcBufferAddr( PCDphotoHdl hPhoto, LPRECT sRect, LPRECT dRect, 
        PCDRAWDATA buffer, long FAR * Stride )
{
  short  Width;
  long  planeBytes;
  short  colBytes;
  
  Width = dRect->right - dRect->left;/*destination witdh used to calc stride*/
  PCDgetBytesPerRow(hPhoto,Width,Stride);
  PCDgetPlaneColumn(hPhoto,&planeBytes,&colBytes);
  
  /**********************************************************************\
  *                                                 *
  * NOTE: Since bitmaps in Windows are essentially scanned bottom - up, *
  *    and the rectangle coordinates are based on (0,0) being the   *
  *    top left corner of the image, the buffer address calculated      *
  *    below defines the address of the bottom scan line            *
  *                                                     *
  \**********************************************************************/
  
  return( (PCDRAWDATA)(buffer +
((unsigned long)(dRect->bottom - sRect->bottom) * (unsigned long)*Stride) +
((unsigned long)(sRect->left - dRect->left) * (unsigned long)colBytes)) );
}

/* Symbolizes rightmost/bottommost pixel for given resolution */
#define TO_THE_MAX      -1
/* Sentinel */
#define ENDRECT         -2

#define MAX_RECT_LIST   16
/* Base/16 relative */
RECT    rectList[MAX_RECT_LIST] = {
    /*  L          T           R           B */
    {   0,         0,         33,   TO_THE_MAX      },  /* 0 */
    {  33,         0,        177,         47        },  /* 1 */
    {  33,        47,         96,        100        },  /* 2 */
    {  96,        47,        177,        101        },  /* 3 */
    {  33,       101,   TO_THE_MAX, TO_THE_MAX      },  /* 4 */
    { 177,         0,   TO_THE_MAX,      101        },  /* 5 */
    {  33,       100,         96,        101        },  /* 6 */
    { ENDRECT, ENDRECT, ENDRECT, ENDRECT }
};
/* Must match above */
int nRects = 7;

HWND hwnd;                                      /* handle to main window */

int getRect(HWND hwnd, LPRECT r, PCDresolution res, PCDtransform xform);

PCDstatus
doComposite(PCDphotoHdl hPcd, HANDLE FAR *lpDib)
{
    HANDLE  hDib, hHeader;
    LPBITMAPINFO    lpb;
    int             depth;
    long            nrows, ncols, pb, cb;
    PCDRAWDATA      image, buf;
    PCDstatus       res;
    RECT            rect, fullRect;
    unsigned long   pixoff, size;
    long            stride;
    int             mult, i;
    PCDresolution   step;
    PCDtransform    xform;

    if ((res = PCDgetResolution(hPcd, &step) != pcdSuccess))
        return(res);
    if ((res = PCDgetTransform(hPcd, &xform) != pcdSuccess))
        return(res);
    fullRect.top = fullRect.left = 0;
    getRect(hwnd, (LPRECT)&fullRect, step, xform);
    rect.left = rect.right = rect.top = rect.bottom = 0;
    if ((res = PCDloadImage(hPcd, (LPRECT)&rect, &hHeader)) != pcdSuccess)
        return(res);
    if (getImageInfo(hHeader, &lpb, &depth, &nrows, &ncols, 
            &pb, &cb, &image))
        return(ENOMEM);
    if (!lpb || !image)
        return(ENOMEM);
    pixoff = image - ((PCDRAWDATA)lpb);

    lpb->bmiHeader.biWidth = nrows = fullRect.right;
    lpb->bmiHeader.biHeight = ncols = fullRect.bottom;

    size = (nrows * ncols * (long)depth) / 8L;
    size += pixoff;
    if (size > (16L * 1024L * 1024L))
        return(ENOMEM);
    if ((hDib = GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE, size)) == 0)
        return(ENOMEM);
    image = (PCDRAWDATA)GlobalLock(hDib);
    _fmemcpy(image, lpb, pixoff);
    GlobalUnlock(hHeader);
    GlobalFree(hHeader);
    image += pixoff;

    for (i = 0; i < nRects; i++) {
        HDC hdc;

#define FIX_RECT(x) \
    if (rect.x == TO_THE_MAX) rect.x = fullRect.x;

        rect = rectList[i];
        if (rect.top == ENDRECT) break;
        FIX_RECT(top);
        FIX_RECT(bottom);
        FIX_RECT(left);
        FIX_RECT(right);

        if (rect.right > fullRect.right) rect.right = fullRect.right;
        if (rect.bottom > fullRect.bottom) rect.bottom = fullRect.bottom;

        buf = CalcBufferAddr(hPcd, &rect, &fullRect, 
            image, &stride);
        res = PCDgetBlock(hPcd, &rect, buf, stride);
        if (res != pcdSuccess) return(res);
        if (i < nRects - 1) {
            char    msg[80];
            HDC hdc = 0;

            hdc = GetDC(hwnd);
            DibBlt(hdc, 0, 0, 0, 0, 
                    hDib, 0, 0,SRCCOPY, 0);
            if (hdc) ReleaseDC(hwnd, hdc);
            wsprintf(msg, "After rect %d", i);
            MessageBox(GetFocus(), msg,
             "Composite Test", MB_OK);
        }
    }
    GlobalUnlock(hDib);
    *lpDib = hDib;

    return(pcdSuccess);
}

void 
myDrawBitmap(HDC hdc, HBITMAP hBitmap, short xStart, short yStart)
{
    BITMAP  bm;
    HDC     hdcMem;
    DWORD   dwSize;
    POINT   ptSize, ptOrg;

    hdcMem = CreateCompatibleDC(hdc);
    SelectObject(hdcMem, hBitmap);
    SetMapMode(hdcMem, GetMapMode(hdc));

    GetObject(hBitmap, sizeof(bm), (LPSTR)&bm);

    ptSize.x = bm.bmWidth;
    ptSize.y = bm.bmHeight;
    DPtoLP(hdc, &ptSize, 1);

    ptOrg.x = 0;
    ptOrg.y = 0;
    DPtoLP(hdc, &ptOrg, 1);

    BitBlt(hdc, xStart, yStart, ptSize.x, ptSize.y,
            hdcMem, ptOrg.x, ptOrg.y, SRCCOPY);
    DeleteDC(hdcMem);
}


PCDphotoHdl hPcd = 0;

char    defaultDrive[4] = { 'D', ':', '\0', '\0' };

time_t  time0, time1;

#define START_TIMER if (bTime) time0 = time((time_t *)0)

#define END_TIMER \
    if (bTime) { \
        char tmsg[64]; \
        short tdiff; \
        time1 = time((time_t *)0); \
        tdiff = time1 - time0; \
        wsprintf(tmsg, "Elapsed time = %2.2d:%2.2d", \
                tdiff / 60, tdiff % 60); \
        MessageBox ( \
             GetFocus(), \
             tmsg, \
             "PhotoCD Sample Application", \
             MB_OK); \
    } 

struct cbinfo {
    HWND            hwnd;
    HBRUSH          hBrush;
    char            pct[20]; 
    char            pctdone[12];
    long            percent; 
    RECT            r;
    HDC             hdc;
    LPBITMAPINFO    lpb;
    int             depth;
    long            nrows, ncols, pb, cb;
    unsigned char _huge *image;
    int             count;
    int             mod;
    BOOL            therm;
    BOOL            swaprowcol;
    BOOL            lineatatime;
    struct xb {
                    BITMAPINFOHEADER    b;
                    RGBQUAD             c[256];
    }               xb;
};

BOOL    therm = TRUE;

/*
 * Graphic positioning defines for progress function
 */
#define XLEFT           350
#define YTOP            100
#define YBOTTOM         YTOP+20

/* 
 * COLORS 
 */
 #define PURE_BLUE         0x00FF0000
 #define PURE_GREEN        0x0000FF00

RGBQUAD xpal[256];
RGBQUAD FAR *palpal = xpal;

RGBQUAD rgbk[] = {
    { 255, 255, 255, 0 },
    {   0,   0, 255, 0 },
    {   0, 255,   0, 0 },
    { 255,   0,   0, 0 },
    {   0,   0,   0, 0 }
};

RGBQUAD cmyk[] = {
    { 255, 255, 255, 0 },
    {   0, 255, 255, 0 },
    { 255, 255,   0, 0 },
    { 255,   0, 255, 0 },
    {   0,   0,   0, 0 }
};

RGBQUAD bicolors[] = {
/*    C2    C1    Y  */
/*  (Blue Green  Red)*/
    { 137, 156,   0, 0 },
    { 137, 156, 200, 0 }
};

unsigned char bi4lut[] = {
    0, 0, 1, 1
};

RGBQUAD s4colors[] = {
    { 137, 156,   0, 0 }, /*  0 */
    { 137, 156,  91, 0 }, /*  1 */
    { 137, 156, 139, 0 }, /*  2 */
    { 137, 156, 181, 0 }, /*  3 */
};

RGBQUAD s16colors[] = {
    { 137, 156,   0, 0 }, /*  0 */
    { 137, 156,  10, 0 }, /*  1 */
    { 137, 156,  20, 0 }, /*  2 */
    { 137, 156,  30, 0 }, /*  3 */
    { 137, 156,  40, 0 }, /*  4 */
    { 137, 156,  50, 0 }, /*  5 */
    { 137, 156,  60, 0 }, /*  6 */
    { 137, 156,  80, 0 }, /*  7 */
    { 137, 156, 100, 0 }, /*  8 */
    { 137, 156, 120, 0 }, /*  9 */
    { 137, 156, 140, 0 }, /* 10 */
    { 137, 156, 160, 0 }, /* 11 */
    { 137, 156, 180, 0 }, /* 12 */
    { 137, 156, 200, 0 }, /* 13 */
    { 137, 156, 220, 0 }, /* 14 */
    { 137, 156, 255, 0 }  /* 15 */
};

RGBQUAD vga8colors[16] = {
/*   Blue Green  Red */
    {   0,   0,   0, 0 },
    {   0,   0, 255, 0 },
    {   0, 255,   0, 0 },
    {   0, 255, 255, 0 },
    { 255,   0,   0, 0 },
    { 255,   0, 255, 0 },
    { 255, 255,   0, 0 },
    { 255, 255, 255, 0 },
};


RGBQUAD vga16ycc[16] = {
/*    C2    C1    Y  */
/*  (Blue Green  Red)*/
    { 137, 156,   0, 0 },
    { 184, 139,  27, 0 },
    {  95, 122,  55, 0 },
    { 145, 105,  83, 0 },
    { 129, 207,  10, 0 },
    { 178, 190,  39, 0 },
    {  88, 173,  66, 0 },
    { 137, 156, 141, 0 },
    { 137, 156,  91, 0 },
    { 235, 121,  56, 0 },
    {  55,  88, 110, 0 },
    { 153,  54, 166, 0 },
    { 121, 255,  22, 0 },
    { 219, 223,  78, 0 },
    {  38, 190, 132, 0 },
    { 137, 156, 188, 0 },
};

RGBQUAD vga16colors[16] = {
/*   Blue Green  Red */
    {   0,   0,   0, 0 },
    {   0,   0, 128, 0 },
    {   0, 128,   0, 0 },
    {   0, 128, 128, 0 },
    { 128,   0,   0, 0 },
    { 128,   0, 128, 0 },
    { 128, 128,   0, 0 },
    { 192, 192, 192, 0 },
    { 128, 128, 128, 0 },
    {   0,   0, 255, 0 },
    {   0, 255,   0, 0 },
    {   0, 255, 255, 0 },
    { 255,   0,   0, 0 },
    { 255,   0, 255, 0 },
    { 255, 255,   0, 0 },
    { 255, 255, 255, 0 },
};

                

BOOL    bInPlace = FALSE, bComposite = FALSE,
        bWholeThing = FALSE, bUseRGB = TRUE, 
        bRGBpal = TRUE, bDoErrDiff = TRUE,
        bAnalyze = FALSE, bAbort = FALSE,
        bPrintInfo = FALSE, bGenericOverview = FALSE, bDoYCC = TRUE,
        bHighRes = TRUE, bSquish = FALSE, bBitmap = FALSE;

PCDpaletteHdl   hPCDpal = 0;

int nPalColors = 256;
RGBQUAD FAR *pal = 0;
unsigned char _huge *lut = 0;

unsigned char   rbits = 3, gbits = 3, bbits = 2;

BOOL    bAuto = FALSE;
PCDtransform    transform = PCD_ROTATE_0;
PCDresolution   oviewRes = PCD_BASE_OVER_64;

HPALETTE hNewPalette = 0;
HPALETTE hOldPalette = 0;

HANDLE hInst;

char pbuf[sizeof(LOGPALETTE) + 256 * sizeof(PALETTEENTRY)];
LPLOGPALETTE curPalette = (LPLOGPALETTE)pbuf;
HANDLE hAccTable;                                /* handle to accelerator tbl */
HDC  hdc;

int             curZoom = IDM_NOZOOM;
int             zoomNum = 1, zoomDenom = 1;
int             palfmt = IDM_P332;
PCDformat       format = PCD_SINGLE;
PCDresolution   resolution = PCD_BASE_OVER_4;

char FileName[128];
char PathName[128];
char OpenName[128];
char DefPath[128];
char DefSpec[13] = "*.pcd";
char DefOutSpec[13] = "*.bmp";
char DefExt[] = ".pcd";
char str[255];

HANDLE  hDib = 0;

BOOL bProf = FALSE;
BOOL bTime = FALSE;
BOOL bValidFile = FALSE;
BOOL bValidDib = FALSE;
BOOL bDoProgress = TRUE;
BOOL b24 = TRUE;
BOOL b24d = FALSE;

#define START_PROFILER \
    if (bProf) ProfStart()

#define END_PROFILER \
    if (bProf) { ProfStop(); ProfFinish(); }

/****************************************************************************

    FUNCTION: WinMain(HANDLE, HANDLE, LPSTR, int)

    PURPOSE: calls initialization function, processes message loop

****************************************************************************/

int PASCAL WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HANDLE hInstance;
HANDLE hPrevInstance;
LPSTR lpCmdLine;
int nCmdShow;
{
    MSG msg;
	char theBuff[256];

    hInst = hInstance;
    if (!hPrevInstance)
        if (!InitApplication(hInstance))
            return (FALSE);

	PCDgetInternalVersion(theBuff);

    if (!InitInstance(hInstance, nCmdShow))
        return (FALSE);

    while (GetMessage(&msg, NULL, NULL, NULL)) {

    /* Only translate message if it is not an accelerator message */

        if (!TranslateAccelerator(hwnd, hAccTable, &msg)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg); 
        }
    }
    return (msg.wParam);
}


/****************************************************************************

    FUNCTION: InitApplication(HANDLE)

    PURPOSE: Initializes window data and registers window class

****************************************************************************/

BOOL InitApplication(hInstance)
HANDLE hInstance;
{
    WNDCLASS  wc;

    wc.style = NULL;
    wc.lpfnWndProc = MainWndProc;
    wc.cbClsExtra = 0;
    wc.cbWndExtra = 0;
    wc.hInstance = hInstance;
    wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = GetStockObject(WHITE_BRUSH); 
    wc.lpszMenuName =  "PhotoCDMenu";
    wc.lpszClassName = "PhotoCDwClass";

    return (RegisterClass(&wc));
}


/****************************************************************************

    FUNCTION:  InitInstance(HANDLE, int)

    PURPOSE:  Saves instance handle and creates main window

****************************************************************************/

BOOL InitInstance(hInstance, nCmdShow)
    HANDLE          hInstance;
    int             nCmdShow;
{
    RECT            Rect;
    WORD            version;
    static char     caption[256];

    PCDgetToolkitVersion(&version);
    wsprintf(caption, "PCDTK - version %d.%d", 
            version & 0xff, (version >> 8) & 0xff);

    hInst = hInstance;

    hAccTable = LoadAccelerators(hInst, "PhotoCD");

    hwnd = CreateWindow(
        "PhotoCDwClass",
        caption,
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        NULL,
        NULL,
        hInstance,
        NULL
    );

    if (!hwnd)
        return (FALSE);

    GetClientRect(hwnd, (LPRECT) &Rect);

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    return (TRUE);

}

BOOL bRound = TRUE;

getRect(HWND hwnd, LPRECT r, PCDresolution res, PCDtransform xform)
{
    int x, y, tmp;
    RECT    cr;

    PCDlistResolution(res, &x, &y);
    if (xform & PCD_90_ROTATION && x > y) {
        tmp = x;
        x = y;
        y = tmp;
    }
    if (bWholeThing) {
        r->top = r->left = 0;
        r->right = x;
        r->bottom = y;
        return;
    }
    GetClientRect(hwnd, &cr);
    if (cr.bottom > 40)
        cr.bottom -= 32;
    if (cr.right > x)
        cr.right = x;
    if (cr.bottom > y)
        cr.bottom = y;
    cr.left = r->left;
    cr.top = r->top;
    if (r->bottom && cr.bottom > r->bottom)
        cr.bottom = r->bottom;
    if (r->right && cr.right > r->right)
        cr.right = r->right;
    *r = cr;

    if (bRound) {
        r->top &= ~3;
        r->left &= ~3;
        r->right &= ~3;
        r->bottom &= ~3;
    }
}

void analyze(PCDphotoHdl hPcd)
{
    return;
}    


PCDstatus
getAndDisplay(PCDphotoHdl hPcd, LPRECT r, HANDLE FAR *lpDib, HDC hDC)
{
    PCDstatus res;
    RECT    x = *r;
    int     xinc, yinc;
    int     firsttime = 1;
    unsigned char _huge *cp;
    long    stride;

    *lpDib = 0;

    xinc = (x.right - x.left) / 2;
    yinc = (x.bottom - x.top) / 2;

    x.right = r->left + xinc;
    while (x.right <= r->right) {
        x.top = r->top;
        x.bottom = r->top + yinc;
        while (x.bottom <= r->bottom) {
            if (firsttime) {
                firsttime = 0;
                if ((res = PCDloadImage(hPcd, &x, lpDib)) != pcdSuccess)
                    goto out;
                if ((cp = GlobalLock(*lpDib)) == 0) {
                    res = 3000;
                    goto out;
                }
                cp += sizeof(BITMAPINFOHEADER) + PaletteSize(cp);
                PCDgetBytesPerRow(hPcd, x.right - x.left, &stride);
            } else {
                if ((res = PCDgetBlock(hPcd, &x, cp, stride)) != pcdSuccess)
                    goto out;
            }

            DibBlt(hDC, x.left - r->left, x.top - r->top, 
                    0, 0, *lpDib, 0, 0, SRCCOPY, 0);
            x.top = x.bottom;
            x.bottom += yinc;
        }
        x.left = x.right;
        x.right += xinc;
    }
out:
    if (*lpDib)
        PCDfreeBitmap(*lpDib);
    *lpDib = 0;
    return(res);
}

lines(HWND hwnd, short rop, int x1, int y1, int x2, int y2)
{
    HDC hdc = GetDC(hwnd);
    short oldrop = SetROP2(hdc, rop);

    MoveTo(hdc, x1, y1);
    LineTo(hdc, x2, y1);
    LineTo(hdc, x2, y2);
    LineTo(hdc, x1, y2);
    LineTo(hdc, x1, y1);

    SetROP2(hdc, oldrop);
    ReleaseDC(hwnd, hdc);
}

RECT
mkRect(int x1, int y1, int x2, int y2)
{
    RECT    r;

    if (x1 < x2) {
        r.left = x1;
        r.right = x2;
    } else {
        r.left = x2;
        r.right = x1;
    }
    if (y1 < y2) {
        r.top = y1;
        r.bottom = y2;
    } else {
        r.top = y2;
        r.bottom = y1;
    }
    return(r);
}

/****************************************************************************

    FUNCTION: MainWndProc(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages

    MESSAGES:

        WM_COMMAND    - application menu (About dialog box)
        WM_DESTROY    - destroy window

    COMMENTS:

        WM_COMMAND processing:

            IDM_OPEN - query to save current file if there is one and it
                       has been changed, open a new file.

            IDM_ABOUT - display "About" box.

****************************************************************************/

BOOL    bMirror = FALSE;
BOOL    bHMirror = FALSE;
BOOL    bRotate = FALSE;
HMENU   hMenu;

long FAR PASCAL MainWndProc(hWnd, message, wParam, lParam)
HWND hWnd;
unsigned message;
WORD wParam;
LONG lParam;
{
    FARPROC lpProcAbout, lpOpenDlg, lpSaveAsDlg;

    int Success;                            /* return value from SaveAsDlg() */
    int IOStatus;                           /* result of file i/o      */
    int Return;
    static WORD wResolution = IDM_TV;
    LPSTR exname = "";

    static BOOL bNewRect = FALSE;
    static BOOL bCapturing = FALSE, bSelectRect = TRUE;
    static POINT ptBegin, ptEnd;
    static HDC hDC;
    static HPEN hBlackPen;
    static HPEN hOldPen;
    static RECT rSelect;

    switch (message) {
        case WM_LBUTTONDOWN:
            if (!bCapturing) {
                bCapturing = TRUE;
                SetCapture(hwnd);
                SetCursor(LoadCursor(NULL, IDC_CROSS));
                ptEnd = ptBegin = MAKEPOINT(lParam);
                return(0);
            }
            /* else FALLTHROUGH: shouldn't happen */
        case WM_LBUTTONUP:
            if (bCapturing) {
                bCapturing = FALSE;
                lines(hwnd, R2_NOT, ptBegin.x, ptBegin.y, ptEnd.x, ptEnd.y);
                ptEnd = MAKEPOINT(lParam);
                bSelectRect = TRUE;
                SetCursor(LoadCursor(NULL, IDC_ARROW));
                ReleaseCapture();

                rSelect = mkRect(ptBegin.x, ptBegin.y, ptEnd.x, ptEnd.y);
                goto reRead;
            }
            break;
        case WM_MOUSEMOVE:
            if (bCapturing) {
                lines(hwnd, R2_NOT, ptBegin.x, ptBegin.y, ptEnd.x, ptEnd.y);
                ptEnd = MAKEPOINT(lParam);
                lines(hwnd, R2_NOT, ptBegin.x, ptBegin.y, ptEnd.x, ptEnd.y);
                return(0);
            }
            break;

        case WM_COMMAND:
            switch (wParam) {
            case IDM_NOZOOM:
                if (curZoom == wParam) return(0);
                zoomNum = 1; zoomDenom = 1;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);
            case IDM_ZIN2:
                if (curZoom == wParam) return(0);
                zoomNum = 2; zoomDenom = 1;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);
            case IDM_ZIN4:
                if (curZoom == wParam) return(0);
                zoomNum = 4; zoomDenom = 1;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);
            case IDM_ZIN8:
                if (curZoom == wParam) return(0);
                zoomNum = 8; zoomDenom = 1;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);
            case IDM_ZOUT2:
                if (curZoom == wParam) return(0);
                zoomNum = 1; zoomDenom = 2;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);
            case IDM_ZOUT4:
                if (curZoom == wParam) return(0);
                zoomNum = 1; zoomDenom = 4;
                if (bValidDib || bValidFile)
                    InvalidateRect(hWnd, NULL, TRUE);
                curZoom = wParam;
                return(0);

            case IDM_TP: {
#define NOPENS  100
                static PCDphotoHdl xhPcd[NOPENS];
                int i, maxok = 0;

                if (!OpenName[0]) {
                    MessageBox (
                             GetFocus(),
                             "No current file",
                             "PhotoCD Test Application",
                             MB_ICONASTERISK | MB_OK);
                    break;
                }
                for (i = 0; i < NOPENS; i++) {
                    if (PCDopen(OpenName, &xhPcd[i]) != pcdSuccess) {
                        static char msg[32];

                        wsprintf((LPSTR)msg, "Failed at %d", i);
                        MessageBox (
                                 GetFocus(),
                                 msg,
                                 "PhotoCD Test Application",
                                 MB_ICONASTERISK | MB_OK);
                        break;
                    }
                    maxok = i;
                }
                for (i = 0; i <= maxok; i++) {
                    PCDclose(&xhPcd[i]);
                }
            }
            case IDM_ADRIVE:
            case IDM_BDRIVE:
            case IDM_CDRIVE:
            case IDM_DDRIVE:
            case IDM_EDRIVE:
            case IDM_FDRIVE:
                defaultDrive[0] = 'A' + (wParam - IDM_ADRIVE);
                return(0);
            case IDM_PROFILE:
                if (ProfInsChk() != 2) {
                    MessageBox ( GetFocus(), "Profiler not running",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                }
                bProf = !bProf;
                break;

            case IDM_PCDINFO: {
                    static char volInfo[100];
                    static char outStr[100];
                    static char cdate[64], mdate[64];
                    LPSTR cd, md;
                    static unsigned long serial, ct, mt;
                    int i, j;

                    if (PCDgetVolume(defaultDrive, volInfo) != pcdSuccess) {
                        MessageBox ( GetFocus(), "PCDgetVolume failed",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }
                    i = j = 0;
                    serial = 0;
                    while (i < sizeof(volInfo)) {
                        if (volInfo[i] < '0' || volInfo[i] > '9')
                            break;
                        serial *= 10;
                        serial += volInfo[i] - '0';
                        if (serial)
                            outStr[j++] = volInfo[i];
                        i++;
                    }
                    outStr[j++] = '\n';
                    while (i < sizeof(volInfo)) {
                        if (volInfo[i] >= '0' && volInfo[i] <= '9')
                            break;
                        i++;
                    }
                    ct = 0;
                    while (i < sizeof(volInfo)) {
                        if (volInfo[i] < '0' || volInfo[i] > '9')
                            break;
                        ct *= 10;
                        ct += volInfo[i] - '0';
                        i++;
                    }
                    while (i < sizeof(volInfo)) {
                        if (volInfo[i] >= '0' && volInfo[i] <= '9')
                            break;
                        i++;
                    }
                    mt = 0;
                    while (i < sizeof(volInfo)) {
                        if (volInfo[i] < '0' || volInfo[i] > '9')
                            break;
                        mt *= 10;
                        mt += volInfo[i] - '0';
                        i++;
                    }

                    strcpy(cdate, ctime(&ct));
                    strcpy(mdate, ctime(&mt));
                    cd = cdate;
                    md = mdate;
                    while (*cd != '\n')
                        outStr[j++] = *cd++;
                    outStr[j++] = '\n';
                    while (*md != '\n')
                        outStr[j++] = *md++;
                    outStr[j++] = '\0';

                    MessageBox ( GetFocus(), outStr,
                         "PhotoCD Information",
                         MB_OK);
                    break;
            }
            case IDM_EPSEXPORT:
                exname = "eps";
                goto doExport;
            case IDM_TIFEXPORT:
                exname = "tif";
                goto doExport;
            case IDM_RIFEXPORT:
                exname = "rif";
                goto doExport;
            case IDM_PCXEXPORT:
                exname = "pcx";
                goto doExport;
            case IDM_DIBEXPORT:
                exname = "bmp";
doExport:
{
                    PCDstatus res;
                    PCDphotoHdl hPcd;
                    HANDLE  hSaveDib;
                    HANDLE hCBinfo = 0;
                    struct cbinfo FAR *cbp;
                    FARPROC     fp = 0, fpa = 0;
                    void FAR PASCAL CheckProgressCallback(unsigned, 
                                                        unsigned, long);
                    BOOL FAR PASCAL AbortCallback(long);
                    RECT x;
                    LPRECT lpRect = &x;

                    if (hCBinfo=GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
                                            sizeof(struct cbinfo))) {
                        cbp = (struct cbinfo FAR *)GlobalLock(hCBinfo);
                        cbp->hwnd = hwnd;
                        cbp->hdc = 0;
                        cbp->count = 0;
                        cbp->mod = 0;
                        cbp->therm = TRUE;
                        GlobalUnlock(hCBinfo);
                    }

                    fp = MakeProcInstance(CheckProgressCallback,
                                        hInst);
                    fpa = MakeProcInstance(AbortCallback,
                                        hInst);

                    hDib = 0; /* Save from freeing */
                    lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                    Return = DialogBox(hInst, "Xfrom", hWnd, lpOpenDlg);
                    FreeProcInstance(lpOpenDlg);

                    hDib = hSaveDib;
                    if (!Return) {
                        MessageBox ( GetFocus(), "No Such Input File",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }

                    if (PCDopen(OpenName,&hPcd) != pcdSuccess) {
                        MessageBox ( GetFocus(), "Cannot Open Input File",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }

                    x.top = x.bottom = x.left = x.right = 0;
                    getRect(hwnd, lpRect, resolution, transform);
                    if (bDoProgress)
                        PCDsetProgress(hPcd, fp, hCBinfo);
                    PCDsetAbort(hPcd, fpa, hCBinfo);
                    if (format == PCD_PALETTE) {
                        if (!hPCDpal) 
                           PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                        PCDsetPalette(hPcd, hPCDpal);
                    }


                    hDib = 0; /* Save from freeing */
                    lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                    Return = DialogBox(hInst, "Xto", hWnd, lpOpenDlg);
                    FreeProcInstance(lpOpenDlg);

                    hDib = hSaveDib;
                    if (!Return) {
                        MessageBox ( GetFocus(), "Bad Output File",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }

                    PCDsetFormat(hPcd, format);
                    PCDsetResolution(hPcd, resolution);
                    PCDsetTransform(hPcd, transform);
                    
                    START_TIMER;

                    res = PCDexport(hPcd, lpRect, exname, OpenName);
                    
                    END_TIMER;

                    PCDclose(hPcd);
                    if (fp) FreeProcInstance(fp);
                    if (fpa) FreeProcInstance(fpa);
                    if (hCBinfo) GlobalFree(hCBinfo);
                    if (res != pcdSuccess) {
                        MessageBox ( GetFocus(), "Export Failed",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }
                    break;
}
            case IDM_PROGRESS:
                    bDoProgress = !bDoProgress;
                    break;
            case IDM_ABORT:
                    bAbort = TRUE;
                    break;
            case IDM_TIME:
                    bTime = !bTime;
                    break;
            case IDM_INFO:
                    bPrintInfo = !bPrintInfo;
                    break;
            case IDM_ANALYZE:
                    // bAnalyze = !bAnalyze;
                    break;

            case IDM_PCMYK:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = cmyk;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 5;

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_PCMY:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = cmyk;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 4;

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
                    break;
            case IDM_PRGBK:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = rgbk;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 5;

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_PRGB:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = rgbk;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 4;

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_SINGLE:
                    format = PCD_SINGLE;
                    break;
            case IDM_P332:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = 0;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    /*  make332palette(palpal); */

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(0, 0, 0, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_PGRAYISH:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 3;
                    pal = palpal;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    makeKBpalette(palpal);

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
                    break;
            case IDM_PREDDISH:
                    format = PCD_PALETTE;
                    rbits = 4;
                    gbits = 3;
                    bbits = 3;
                    pal = palpal;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    makeRBpalette(palpal);

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
                    break;
            case IDM_PGREENISH:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 4;
                    bbits = 3;
                    pal = palpal;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    makeGBpalette(palpal);

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
                    break;
            case IDM_PBLUISH:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 4;
                    pal = palpal;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    makeBBpalette(palpal);

                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
                break;

            case IDM_THERM:
                therm = !therm;
                break;
            case IDM_COMPOSITE:
                bComposite = !bComposite;
                break;
            case IDM_TOGINPLACE:
                bInPlace = !bInPlace;
                break;
            case IDM_24:
                b24 = !b24;
                break;
            case IDM_D24:
                b24d = !b24d;
                break;
            case IDM_AUTO:
                    bAuto = !bAuto;
                    break;
            case IDM_YCC:
                    format = PCD_YCC;
                    break;

            case IDM_RDFLOYD:
                    bDoErrDiff = !bDoErrDiff;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(pal ? &pal[0].rgbRed : 0, 
                                    -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;

            case IDM_BITONAL: {
                    static HANDLE hLUT = 0;
                    static fact = 1, divisor = 2, midpoint = 128;
                    unsigned char FAR *lp;
                    int i;

                    if (hLUT) {
                        GlobalFree(hLUT);
                        hLUT = 0;
                    }
                    if (hLUT == 0) {
                        if (hLUT = GlobalAlloc(GMEM_ZEROINIT|
                                                GMEM_MOVEABLE, 256)) {
                            if (lp = GlobalLock(hLUT)) {
                                for (i = 0; i < 256; i++) {
                                    int x, v;

                                    if (i == midpoint) {
                                        v = 1;
                                    } else if (i > midpoint) {
                                        x = fact * (i - midpoint);
                                        x /= divisor;
                                        if (!x || (rand() % x) == 0)
                                            v = 0;
                                        else
                                            v = 1;
                                    } else {
                                        x = fact * (midpoint - i);
                                        x /= divisor;
                                        if (!x || (rand() % x) == 0)
                                            v = 1;
                                        else
                                            v = 0;
                                    }
                                    *lp++ = v;
                                }
                                GlobalUnlock(hLUT);
                            } else {
                                GlobalFree(hLUT);
                                hLUT = 0;
                            }
                        }
                    }
                    format = PCD_PALETTE;
                    pal = bicolors;
                    nPalColors = 2;
                    rbits = 8;
                    gbits = 0;
                    bbits = 0;
                    bUseRGB = 0;
                    bRGBpal = 0;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    hLUT, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            }
            case IDM_VGA16Y: {
                    static HANDLE hLUT = 0;
                    extern unsigned char vga16from332[];

                    format = PCD_PALETTE;
                    pal = vga16ycc;
                    nPalColors = 16;
                    rbits = 4;
                    gbits = 3;
                    bbits = 3;
                    bUseRGB = 0;
                    bRGBpal = 0;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    hLUT, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            } case IDM_VGA8:
                    format = PCD_PALETTE;
                    pal = vga8colors;
                    // lut = vga16from422ycc;
                    lut = 0;
                    nPalColors = 8;
                    rbits = 4;
                    gbits = 4;
                    bbits = 3;
                    bUseRGB = 1;
                    bRGBpal = 1;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_VGA16:
                    format = PCD_PALETTE;
                    pal = vga16colors;
                    // lut = vga16from422ycc;
                    lut = 0;
                    nPalColors = 16;
                    rbits = 4;
                    gbits = 4;
                    bbits = 3;
                    bUseRGB = 1;
                    bRGBpal = 1;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_RGB:
                    format = PCD_RGB;
                    break;
            case IDM_GRAY4:
                    format = PCD_PALETTE;
                    pal = s4colors;
                    lut = 0;
                    nPalColors = 4;
                    rbits = 4;
                    gbits = 0;
                    bbits = 0;
                    bUseRGB = 0;
                    bRGBpal = 0;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_GRAY16:
                    format = PCD_PALETTE;
                    pal = s16colors;
                    lut = 0;
                    nPalColors = 16;
                    rbits = 4;
                    gbits = 0;
                    bbits = 0;
                    bUseRGB = 0;
                    bRGBpal = 0;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;
            case IDM_PALETTE:
                    format = PCD_PALETTE;
                    rbits = 3;
                    gbits = 3;
                    bbits = 2;
                    pal = 0;
                    lut = 0;
                    bRGBpal = 1;
                    bUseRGB = 1;
                    nPalColors = 256;
                    if (hPCDpal) PCDfreePalette(hPCDpal);
                    PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                    break;

            case IDM_IMIRROR:
                hMenu = GetMenu(hwnd);
                hMenu = GetSubMenu(hMenu, 3);
                CheckMenuItem(hMenu, wParam, bMirror?MF_UNCHECKED:MF_CHECKED);
                bMirror = !bMirror;
                break;

            case IDM_IHMIRROR:
                hMenu = GetMenu(hwnd);
                hMenu = GetSubMenu(hMenu, 3);
                CheckMenuItem(hMenu, wParam, bHMirror?MF_UNCHECKED:MF_CHECKED);
                bHMirror = !bHMirror;
                break;

            case IDM_IROTATE:
                hMenu = GetMenu(hwnd);
                hMenu = GetSubMenu(hMenu, 3);
                CheckMenuItem(hMenu, wParam, bRotate?MF_UNCHECKED:MF_CHECKED);
                bRotate = !bRotate;
                break;

                case IDM_TV16:
                case IDM_TV4:
                case IDM_TV:
                case IDM_4TV:
                case IDM_16TV:

                hMenu = GetMenu(hwnd);
                hMenu = GetSubMenu(hMenu, 2);

                CheckMenuItem(hMenu, wResolution, MF_UNCHECKED);
                wResolution = wParam;
                CheckMenuItem(hMenu, wResolution, MF_CHECKED);

                switch (wParam) {
                    case IDM_TV16:
                        resolution = PCD_BASE_OVER_16;
                        break;
                    case IDM_TV4:
                        resolution = PCD_BASE_OVER_4;
                        break;
                    case IDM_TV:
                        resolution = PCD_BASE;
                        break;
                    case IDM_4TV:
                        resolution = PCD_4BASE;
                        break;
                    case IDM_16TV:
                        resolution = PCD_16BASE;
                        break;
                }
                break;

                case IDM_OVERVIEW: {
                    PCDtransform x;
                    short imgno;
                    static PCDoviewHdl hpcdo = 0;
                    PCDstatus res = pcdSuccess;
                    HDC hDC = GetDC(hwnd);
                    short cnt;
                    PCDRAWDATA hpImage, hpDIB;
                    long stride;
                    long width, height, depth;
                    int nToRead, i;
                    int chunksize;
                    char friend[32];
                    LPSTR lpFriend = friend;
                    PCDformat orient;
                    int xoff, yoff;
                    RECT rect;
                    LOGBRUSH lb;
                    HBITMAP hBitmap = 0;
                    HBRUSH hBrush = 0;
                    static BITMAP bitmap = { 0, 8, 8, 2, 1, 1 };
                    static LOGBRUSH logbrush = { BS_SOLID, RGB(128,128,128) };
                    static WORD wBrickBits[] =
                        { 0xff, 0x0c, 0x0c, 0xff, 0xc0, 0xc0, 0xc0 };
                    static char oviewName[64] = {
                        'D', ':', 
                        '\\', 'P', 'H', 'O', 'T', 'O', '_', 'C', 'D',
                        '\\', 'O', 'V', 'E', 'R', 'V', 'I', 'E', 'W',
                        '.', 'P', 'C', 'D', '\0' };

                    if (oviewName[0] != defaultDrive[0]) {
                        oviewName[0] = defaultDrive[0];
                        hpcdo = 0;
                    }
                    if (bGenericOverview) {
                        /* Call OpenDlg() to get the filename */

                        lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                        Return = DialogBox(hInst, "Open", hWnd, lpOpenDlg);
                        FreeProcInstance(lpOpenDlg);
                        if (Return) {
                            _fstrncpy(oviewName, OpenName, sizeof(oviewName));
                        }
                        hpcdo = 0;
                    }
                    if (hpcdo == 0) {
                        res = PCDOopen(oviewName, &hpcdo);
                        if (res != pcdSuccess)
                            goto foout;
                    }                            
                    width = height = 100;
                    if (oviewRes == PCD_BASE_OVER_16) 
                        chunksize = 4;
                    else
                        chunksize = 8;
                    if (format == PCD_SINGLE || format == PCD_PALETTE)
                        depth = 1;
                    else
                        depth = 3;
                    if (format == PCD_PALETTE) {
                        if (!hPCDpal) 
                         PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                0, rbits, gbits, bbits, 
                                bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                         PCDOsetPalette(hpcdo, hPCDpal);
                    }


                    PCDOsetResolution(hpcdo, oviewRes);
                    PCDOsetFormat(hpcdo, format);
                    PCDOgetCount(hpcdo, &cnt);

                    START_TIMER;

                    for (imgno = 0; imgno < cnt; imgno++) {
                        res = PCDOsetSelect(hpcdo, imgno + 1);
                        PCDOgetRotation(hpcdo, &orient);
                        if (orient & PCD_90_ROTATION) {
                            xoff = ((100 - 64) / 2) + 2;
                            yoff = 2;
                        } else {
                            yoff = ((100 - 64) / 2) + 2;
                            xoff = 2;
                        }
                        /*
                        PCDOsetTransform(hpcdo, PCD_ROTATE_0);
                        */
                        res = PCDOloadImage(hpcdo, &hDib);
                        if (res != pcdSuccess)
                            goto foout;

                        if (format != PCD_YCC)
                            DibBlt(hDC, 
                                (width * (imgno % chunksize) + xoff), 
                                (height * (imgno / chunksize) + yoff), 
                                0, 0, hDib, 0, 0, SRCCOPY, palfmt);
                        else
                            BlastYCC(hDC, 
                                (width * (imgno % chunksize) + xoff), 
                                (height * (imgno / chunksize) + yoff), 
                                0, 0, hDib, 0, 0, SRCCOPY, palfmt);
                        if (hDib) {
                            GlobalFree(hDib);
                            hDib = 0;
                        }
                    }
                foout:

                    END_TIMER;

                    if (hBrush) DeleteObject(hBrush);
                    if (hBitmap) DeleteObject(hBitmap);

                    if (hDib) {
                        GlobalFree(hDib);
                        hDib = 0;
                    }
                    if (hDC)
                        ReleaseDC(hwnd, hDC);
                    if (res != pcdSuccess) {
                        MessageBox (
                             GetFocus(),
                             "Failed to read overview pac(k)",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        if (hpcdo)
                            PCDOclose(hpcdo);
                    }
                    break;
                }
                case IDM_FOVERVIEW: {
                    PCDtransform x;
                    short imgno;
                    static PCDoviewHdl hpcdo = 0;
                    PCDstatus res = pcdSuccess;
                    HDC hDC = GetDC(hwnd);
                    short cnt;
                    LPSTR oviewName;
                    int fd = -1;
                    int nToRead;

                    oviewName = "d:\\photo_cd\\overview.pcd";
                    if (bGenericOverview) {
                        /* Call OpenDlg() to get the filename */

                        lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                        Return = DialogBox(hInst, "Open", hWnd, lpOpenDlg);
                        FreeProcInstance(lpOpenDlg);
                        if (Return)
                            oviewName = OpenName;
                    }
                    if (hpcdo == 0) {
                        res = PCDOopen(oviewName, &hpcdo);
                        if (res != pcdSuccess)
                            goto xoout;
                    }
                    PCDOgetCount(hpcdo, &cnt);
                    if ((fd = _lopen(oviewName, OF_READ)) < 0)
                        goto xoout;
                    _llseek(fd, PCDOS_IMG(1), 0);

                    START_TIMER;

                    for (imgno = 0; imgno < cnt; ) {
                        if (cnt - imgno < 8)
                            nToRead = cnt - imgno;
                        else
                            nToRead = 8;

                        hDib = ReadNOviews(fd, nToRead, format);

                        if (format != PCD_YCC)
                            DibBlt(hDC, 
                                100 * (imgno % 8),  68 * (imgno / 8), 
                                0, 0, hDib, 0, 0, SRCCOPY, palfmt);
                        else
                            BlastYCC(hDC, 
                                100 * (imgno % 8),  68 * (imgno / 8), 
                                0, 0, hDib, 0, 0, SRCCOPY, palfmt);

                        imgno += nToRead;

                        GlobalFree(hDib);
                        hDib = 0;
                    }
                xoout:

                    END_TIMER;

                    if (fd >= 0)
                        _lclose(fd);
                    if (hDC)
                        ReleaseDC(hwnd, hDC);
                    if (res != pcdSuccess) {
                        MessageBox (
                             GetFocus(),
                             "Failed to read overview pac(k)",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        if (hpcdo)
                            PCDOclose(hpcdo);
                    }
                    break;
                }
                case IDM_PASTE: {
                    HANDLE  hClpDib;

                    if (!IsClipboardFormatAvailable(CF_DIB)) {
                        MessageBeep(0);
                        break;
                    }

                    if (hDib && bValidDib) 
                        GlobalFree(hDib);

                    OpenClipboard(hWnd);
                    if (hClpDib = GetClipboardData(CF_DIB)) {
                        bValidDib = TRUE;
                        hDib = hClpDib;
                        InvalidateRect(hWnd, NULL, TRUE);
                        CloseClipboard();
                    } else {
                        MessageBeep(0);
                    }
                    break;
                }
                case IDM_COPY: {
                    HANDLE  hCopy;

                    if (hDib && bValidDib && (hCopy = CopyDib(hDib))) {
                        OpenClipboard(hWnd);
                        EmptyClipboard();
                        SetClipboardData(CF_DIB, hCopy);
                        CloseClipboard();
                    } else
                        MessageBeep(0);
                    break;
                }
                case IDM_IROTATE0:
                case IDM_IROTATE90:
                case IDM_IROTATE180:
                case IDM_IROTATE270:
                case IDM_IMIRROR0:
                case IDM_IMIRROR90:
                case IDM_IMIRROR180:
                case IDM_IMIRROR270:
                    hMenu = GetMenu(hwnd);
                    hMenu = GetSubMenu(hMenu, 4);
                    CheckMenuItem(hMenu, transform + IDM_IXFORM, MF_UNCHECKED);
                    CheckMenuItem(hMenu, wParam, MF_CHECKED);
                    transform = wParam - IDM_IXFORM;
                    break;

                case IDM_ROTATE0:
                case IDM_ROTATE90:
                case IDM_ROTATE180:
                case IDM_ROTATE270:
                case IDM_MIRROR0:
                case IDM_MIRROR90:
                case IDM_MIRROR180:
                case IDM_MIRROR270:
                    if (hDib && bValidDib) {
                        HANDLE  hNewDib;
                        HANDLE hCBinfo = 0;
                        struct cbinfo FAR *cbp;
                        FARPROC     fp = 0, fpa = 0;
                        void FAR PASCAL CheckProgressCallback(unsigned, 
                                                            unsigned, long);
                        BOOL FAR PASCAL AbortCallback(long);

                        if (hCBinfo=GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
                                                sizeof(struct cbinfo))) {
                            cbp = (struct cbinfo FAR *)GlobalLock(hCBinfo);
                            cbp->hwnd = hwnd;
                            cbp->hdc = 0;
                            cbp->count = 0;
                            cbp->mod = 0;
                            if ((wParam - IDM_XFORM) & PCD_90_ROTATION)
                                cbp->swaprowcol = TRUE;
                            else
                                cbp->swaprowcol = FALSE;
                            cbp->therm = TRUE;
                            GlobalUnlock(hCBinfo);
                        }

                        fp = MakeProcInstance(CheckProgressCallback,
                                            hInst);
                        fpa = MakeProcInstance(AbortCallback, hInst);

                        if (PCDapplyTransform(hDib, wParam - IDM_XFORM, 
                            bInPlace, fpa, 0, fp, hCBinfo, 
                            &hNewDib) == pcdSuccess) {
                            InvalidateRect(hwnd, NULL, TRUE);
                            if (hNewDib != hDib)
                                GlobalFree(hDib);
                            hDib = hNewDib;
                        }
                        if (fp) FreeProcInstance(fp);
                        if (fpa) FreeProcInstance(fpa);
                        if (hCBinfo) GlobalFree(hCBinfo);
                    }
                    break;
                case IDM_ABOUT:
doAbout:
                    lpProcAbout = MakeProcInstance(About, hInst);
                    DialogBox(hInst, "AboutBox", hWnd, lpProcAbout);
                    FreeProcInstance(lpProcAbout);
                    break;

                case IDM_SAVE:
                case IDM_SAVEAS: {
                    HANDLE  hSaveDib = hDib;

                    if (!bValidDib || !hDib) {
                        MessageBox (
                             GetFocus(),
                             "No bitmap to save",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    } 
                    /* Call OpenDlg() to get the filename */

                    ChangeDefExt(DefExt, DefOutSpec);
                    hDib = 0; /* Save from freeing */
                    lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                    Return = DialogBox(hInst, "Open", hWnd, lpOpenDlg);
                    FreeProcInstance(lpOpenDlg);

                    hDib = hSaveDib;
                    if (!Return || !WriteDib((LPSTR)OpenName, hDib)) {
                        MessageBox (
                             GetFocus(),
                             "Failed to write file",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                    }

                    ChangeDefExt(DefExt, DefSpec);
                    break;
                }
                case IDM_OPEN:
                    /* Call OpenDlg() to get the filename */

                    lpOpenDlg = MakeProcInstance((FARPROC) OpenDlg, hInst);
                    Return = DialogBox(hInst, "Open", hWnd, lpOpenDlg);
                    FreeProcInstance(lpOpenDlg);

                    if (Return) {
                        int         res;
                        BOOL        dibname(LPSTR);
                        void FAR PASCAL CheckProgressCallback(unsigned, 
                                                            unsigned, long);

                        if (hPcd) {
                            PCDclose(hPcd);
                            hPcd = 0;
                        }
reRead:
                        if (hDib)
                            PCDfreeBitmap(hDib);

                        if (dibname(OpenName)) {
                            StartWait();
                            hDib = OpenDIB(OpenName);
                            EndWait();
                            bValidDib = TRUE;
                            InvalidateRect(hwnd, NULL, TRUE);
                        } else if (hPcd || (res = PCDopen(OpenName,&hPcd)) 
                            == pcdSuccess) {
                            HANDLE hCBinfo = 0;
                            struct cbinfo FAR *cbp;
                            FARPROC     fp = 0, fpa = 0, fpd;
                            BOOL FAR PASCAL AbortCallback(long lData);
                            BOOL FAR PASCAL DiscChgCallback(LPSTR, long);
                            void printInfo(PCDphotoHdl);

                    {
/* XXX test getSize */
                    RECT x;
                    LPRECT lpRect = &x;

                    if (PCDgetSize(hPcd, lpRect) != pcdSuccess)
                        x.top = x.bottom = 0;
                    }
                            if (bPrintInfo)
                                printInfo(hPcd);

                            if (hCBinfo=GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
                                                    sizeof(struct cbinfo))) {
                                cbp = (struct cbinfo FAR *)GlobalLock(hCBinfo);
                                cbp->hwnd = hwnd;
                                cbp->hdc = 0;
                                cbp->count = 0;
                                cbp->mod = 4;
                                cbp->therm = therm;
                                cbp->swaprowcol = FALSE;
                                GlobalUnlock(hCBinfo);
                            }

                            fp = MakeProcInstance(CheckProgressCallback,
                                                hInst);
                            fpa = MakeProcInstance(AbortCallback, hInst);
                            fpd = MakeProcInstance(DiscChgCallback, hInst);
                            if (format == PCD_PALETTE) {
                                if (!hPCDpal) 
                                    PCDcreatePalette(pal ? &pal[0].rgbRed:0, 
                                            -1, 4, nPalColors, 
                                            0, rbits, gbits, bbits, 
                                            bUseRGB, bRGBpal, bDoErrDiff, 
                                            &hPCDpal);
                                PCDsetPalette(hPcd, hPCDpal);
                            }
                            if (format == PCD_PALETTE || format == PCD_SINGLE)
                                columnBytes = 1;
                            else
                                columnBytes = 3;
                            PCDsetPlaneColumn(hPcd, planeBytes, columnBytes);
                            PCDsetTransform(hPcd, transform);
                            PCDsetFormat(hPcd, format);
                            PCDsetResolution(hPcd, resolution);
                            if (bDoProgress && !bComposite)
                                PCDsetProgress(hPcd, fp, hCBinfo);
                            PCDsetAbort(hPcd, fpa, 0);
                            PCDsetDiscChanged(hPcd, fpd, 0);

                            getRect(hwnd, &rSelect, resolution, transform);

                            if (resolution > PCD_BASE) {
                                PCDphotoPtr p;

                                if (p = (PCDphotoPtr)GlobalLock(hPcd)) {
                                    if (bHighRes)
                                        p->maxstep = PCD_16BASE; 
                                    else
                                        p->maxstep = PCD_BASE; 
                                    GlobalUnlock(hPcd);
                                }
                            }
                            START_TIMER;

                            START_PROFILER;

                            if (bComposite) {
                                res = doComposite(hPcd, &hDib);
                            } else {
                                res = PCDloadImage(hPcd, &rSelect, &hDib);
                            }

                            END_PROFILER;

                            END_TIMER;

                            rSelect.top = rSelect.bottom =
                                rSelect.right = rSelect.left = 0;
                            if (res != pcdSuccess)
                                goto oops;

                            bValidDib = TRUE;
                            InvalidateRect(hwnd, NULL, TRUE);
                            if (fp) FreeProcInstance(fp);
                            if (fpa) FreeProcInstance(fpa);
                            if (fpd) FreeProcInstance(fpd);
                            if (hCBinfo) GlobalFree(hCBinfo);
                        } else
                            bValidDib = FALSE;
                    } else {
oops:
                        MessageBox (
                             GetFocus(),
                             "Failed to get file",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                    }
                    return(0);
                case IDM_BITMAP:
                    bBitmap = !bBitmap;
                    return(0);
                case IDM_GOVIEW:
                    bGenericOverview = !bGenericOverview;
                    return(0);
                case IDM_DOYCC:
                    bDoYCC = !bDoYCC;
                    return(0);
                case IDM_HIRES:
                    bHighRes = !bHighRes;
                    return(0);

                case IDM_WHOLE:
                    bWholeThing = !bWholeThing;
                    return(0);

                case IDM_OSMALL:
                    if (oviewRes == PCD_BASE_OVER_64)
                        oviewRes = PCD_BASE_OVER_16;
                    else
                        oviewRes = PCD_BASE_OVER_64;
                    return(0);

                case IDM_NEW:
                case IDM_PRINT: {
                    PCDstatus res;
                    HANDLE  hSaveDib;
                    HANDLE hCBinfo = 0;
                    struct cbinfo FAR *cbp;
                    FARPROC     fp = 0, fpa = 0;
                    void FAR PASCAL CheckProgressCallback(unsigned, 
                                                        unsigned, long);
                    BOOL FAR PASCAL AbortCallback(long);
                    RECT x;
                    LPRECT lpRect = &x;

                    if (hPcd == 0) {
                        MessageBox ( GetFocus(), 
                             "Open an image first - nothing to export",
                             "PhotoCD Test Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    }
                    if (hCBinfo=GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
                                            sizeof(struct cbinfo))) {
                        cbp = (struct cbinfo FAR *)GlobalLock(hCBinfo);
                        cbp->hwnd = hwnd;
                        cbp->hdc = 0;
                        cbp->count = 0;
                        cbp->mod = 0;
                        cbp->therm = TRUE;
                        GlobalUnlock(hCBinfo);
                    }

                    fp = MakeProcInstance(CheckProgressCallback,
                                        hInst);
                    fpa = MakeProcInstance(AbortCallback,
                                        hInst);

                    x.top = x.bottom = x.left = x.right = 0;
                    getRect(hwnd, lpRect, resolution, transform);
                    if (bDoProgress)
                        PCDsetProgress(hPcd, fp, hCBinfo);
                    PCDsetAbort(hPcd, fpa, hCBinfo);
                    if (format == PCD_PALETTE) {
                        if (!hPCDpal) 
                           PCDcreatePalette(&pal[0].rgbRed, -1, 4, nPalColors, 
                                    0, rbits, gbits, bbits, 
                                    bUseRGB, bRGBpal, bDoErrDiff, &hPCDpal);
                        PCDsetPalette(hPcd, hPCDpal);
                    }

                    PCDsetFormat(hPcd, format);
                    PCDsetResolution(hPcd, resolution);
                    PCDsetTransform(hPcd, transform);
                    
                    START_TIMER;

                    res = PCDexport(hPcd, lpRect, 
                                "eps", "tmpprt.eps");
                    
                    END_TIMER;

                    PCDclose(hPcd);
                    if (fp) FreeProcInstance(fp);
                    if (fpa) FreeProcInstance(fpa);
                    if (hCBinfo) GlobalFree(hCBinfo);
                    if (res != pcdSuccess) {
                        MessageBox ( GetFocus(), "Export Failed",
                             "PhotoCD Sample Application",
                             MB_ICONASTERISK | MB_OK);
                        break;
                    } else {
                        WinExec("c:\\tcp\\lpr tmpprt.eps", 
                                SW_SHOW);
                    }
                    break;
}
                    MessageBox (
                          GetFocus(),
                          "Command not implemented",
                          "PhotoCD Sample Application",
                          MB_ICONASTERISK | MB_OK);
                    break;  

                case IDM_EXIT:
                    DestroyWindow(hWnd);
                    break;
    
                /* edit menu commands */

                case IDM_UNDO:
                case IDM_CUT:
                case IDM_CLEAR:
                    MessageBox (
                          GetFocus(),
                          "Command not implemented",
                          "PhotoCD Sample Application",
                          MB_ICONASTERISK | MB_OK);
                    break;  

                case IDC_EDIT:
                    if (HIWORD (lParam) == EN_ERRSPACE) {
                        MessageBox (
                              GetFocus ()
                            , "Out of memory."
                            , "PhotoCD Sample Application"
                            , MB_ICONHAND | MB_OK
                        );
                    }
                    break;

            } 
            break;

        case WM_CREATE: {

            hMenu = GetMenu(hwnd);
            hMenu = GetSubMenu(hMenu, 2);

            CheckMenuItem(hMenu, wResolution, MF_CHECKED);

#ifdef  ENHANCED_COMPAT
            {
                PCDstatus FAR PASCAL PCDsetCompat(void);

                PCDsetCompat();
            }
#endif

            return(0);
        }
        case WM_DESTROY:
            PostQuitMessage(0);
            break;
        case WM_PAINT: {
            PAINTSTRUCT ps;
            HDC     hDC;

            hdc = hDC = BeginPaint(hwnd, &ps);
            if (bValidDib) {
                if (hDib) {
                    bValidDib = TRUE;
                    if (!bBitmap) {
                        if (format != PCD_YCC)
                            DibBlt(hDC, 0, 0, 0, 0, hDib, 0, 0,SRCCOPY,palfmt);
                        else
                            BlastYCC(hDC, 0, 0, 0, 0, hDib,0,0,SRCCOPY,palfmt);
                    } else {
                        HBITMAP hBitmap;

                        if (PCDconvertBitmap(hDib, hDC, &hBitmap) == pcdSuccess)
                            myDrawBitmap(hDC, hBitmap, 0, 0);
                    }
                    EndPaint(hwnd, &ps);
                } else {
                    bValidDib = FALSE;
                    EndPaint(hwnd, &ps);
                    MessageBox (
                         hwnd,
                         "failed to retrieve image",
                         "PhotoCD Sample Application",
                         MB_ICONASTERISK | MB_OK);
                }
            } else
                EndPaint(hwnd, &ps);
            break;
        }

        default:
            return (DefWindowProc(hWnd, message, wParam, lParam));
    }
    return (NULL);
}
