#include <windows.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "pcdovw.h"

#include "showdib.h"
#include "photo.h"
#include "image.h"

#include "ppal.h"
#include <time.h>

extern PCDpaletteHdl	hPCDpal;
unsigned char	TPycc[64 * 3];
unsigned char	TPrgb[64 * 3];
unsigned char	TPpal1[64];
unsigned char	TPpal2[64];

PCDstatus rv;
void testPalette(void)
{
	int	i;

	if (!hPCDpal) return;
	for (i = 0; i < 64 * 3; i++)
		TPycc[i] = rand() & 255;
	rv = PCDYCCtoPalette(TPycc, 1, 3, TPpal1, 64, hPCDpal);
	if (rv) return;
	rv = PCDYCCtoRGB(TPycc, 1, 3, TPrgb + 2, -1, 3, 64);
	if (rv) return;
	rv = PCDRGBtoPalette(TPrgb, 1, 3, TPpal2, 64, hPCDpal);
}

#define	SET_BASE_RES(hpcd) \
	((PCDphotoPtr)GlobalLock(hpcd))->maxstep = PCD_BASE ; GlobalUnlock(hpcd)

#define	SET_HIGH_RES(hpcd) \
	((PCDphotoPtr)GlobalLock(hpcd))->maxstep = PCD_16BASE ; GlobalUnlock(hpcd)

extern time_t	time0, time1;

#define	START_TIMER if (bTime) time0 = time((time_t *)0)

#define	END_TIMER \
	if (bTime) { \
		char tmsg[64]; \
		short tdiff; \
		time1 = time((time_t *)0); \
		tdiff = time1 - time0; \
		wsprintf(tmsg, "Elapsed time = %2.2d:%2.2d", \
				tdiff / 60, tdiff % 60); \
		MessageBox ( \
			 GetFocus(), \
			 tmsg, \
			 "PhotoCD Sample Application", \
			 MB_OK); \
	} 

struct cbinfo {
	HWND 			hwnd;
	HBRUSH         	hBrush;
	char           	pct[20]; 
	char		   	pctdone[12];
	long    		percent; 
	RECT			r;
	HDC				hdc;
	LPBITMAPINFO	lpb;
	int				depth;
	long			nrows, ncols, pb, cb;
	unsigned char _huge *image;
	int				count;
	int				mod;
	BOOL			therm;
	BOOL			swaprowcol;
	BOOL			lineatatime;
	struct xb {
					BITMAPINFOHEADER	b;
					RGBQUAD				c[256];
	}				xb;
};

extern BOOL	therm;

/*
 * Graphic positioning defines for progress function
 */
#define XLEFT           350
#define YTOP            100
#define YBOTTOM         YTOP+20

/* 
 * COLORS 
 */
 #define PURE_BLUE         0x00FF0000
 #define PURE_GREEN        0x0000FF00

/*
void doComposite(PCDbitmapHdl, PCDphotoHdl, 
				PCDresolution, PCDformat, PCDtransform);
*/

extern BOOL	bInPlace, bComposite,
		bWholeThing, bUseRGB, 
		bRGBpal, bDoErrDiff,
		bAnalyze, bAbort,
		bPrintInfo, bGenericOverview, bDoYCC,
		bHighRes;

extern PCDpaletteHdl	hPCDpal;

extern int	nPalColors;
extern RGBQUAD FAR *pal;
extern unsigned char _huge *lut;

extern BOOL	bAuto;
extern PCDtransform	transform;
extern PCDresolution	oviewRes;

extern HPALETTE hNewPalette;
extern HPALETTE hOldPalette;

extern HANDLE hInst;

extern char pbuf[sizeof(LOGPALETTE) + 256 * sizeof(PALETTEENTRY)];
extern LPLOGPALETTE curPalette;
HANDLE hAccTable;                                /* handle to accelerator tbl */
extern HWND hwnd;                             /* handle to main window */
extern HDC  hdc;

extern int				palfmt;
extern PCDformat		format;
extern PCDresolution	resolution;

extern char FileName[128];
extern char PathName[128];
extern char OpenName[128];
extern char DefPath[128];
extern char DefSpec[13];
extern char DefOutSpec[13];
extern char DefExt[];
extern char str[255];

extern HANDLE	hDib;

extern BOOL bTime;
extern BOOL bValidFile;
extern BOOL bValidDib;
extern BOOL bDoProgress;
extern BOOL b24;
extern BOOL b24d;
/****************************************************************************

    FUNCTION: OpenDlg(HWND, unsigned, WORD, LONG)

    PURPOSE: Let user select a file, and return.  Open code not provided.

****************************************************************************/

HANDLE FAR PASCAL OpenDlg(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    WORD index;
    PSTR pTptr;
    HANDLE hFile=1;     /* Temp value for return */

    switch (message) {
        case WM_COMMAND:
            switch (wParam) {

                case IDC_LISTBOX:
                    switch (HIWORD(lParam)) {

                        case LBN_SELCHANGE:
                            /* If item is a directory name, append "*.*" */
                            if (DlgDirSelect(hDlg, str, IDC_LISTBOX)) 
                                strcat(str, DefSpec);

                            SetDlgItemText(hDlg, IDC_EDIT, str);
                            SendDlgItemMessage(hDlg,
                                IDC_EDIT,
                                EM_SETSEL,
                                NULL,
                                MAKELONG(0, 0x7fff));
                            break;

                        case LBN_DBLCLK:
                            goto openfile;
                    }
                    return (0);

                case IDOK: {
					OFSTRUCT	ofstruct;
openfile:
					bValidFile = FALSE;
                    GetDlgItemText(hDlg, IDC_EDIT, OpenName, 128);
                    if (strchr(OpenName, '*') || strchr(OpenName, '?')) {
                        SeparateFile(hDlg, (LPSTR) str, (LPSTR) DefSpec,
                            (LPSTR) OpenName);
                        if (str[0])
                            strcpy(DefPath, str);
                        ChangeDefExt(DefExt, DefSpec);
                        UpdateListBox(hDlg);
                        return (0);
                    }

                    if (!OpenName[0]) {
                        MessageBox(hDlg, "No filename specified.",
                            NULL, MB_OK | MB_ICONHAND);
                        return (0);
                    }

                    AddExt(OpenName, DefExt);

                    EndDialog(hDlg, hFile);

					if (hDib && bValidDib)
						GlobalFree(hDib);
					hDib = 0;
					bValidDib = FALSE;
					bValidFile = TRUE;
                    return (1);
				}
                case IDCANCEL:
                    EndDialog(hDlg, NULL);
                    return (0);
            }
            break;

        case WM_INITDIALOG:                        /* message: initialize    */
            UpdateListBox(hDlg);
            SetDlgItemText(hDlg, IDC_EDIT, DefSpec);
            SendDlgItemMessage(hDlg,               /* dialog handle      */
                IDC_EDIT,                          /* where to send message  */
                EM_SETSEL,                         /* select characters      */
                NULL,                              /* additional information */
                MAKELONG(0, 0x7fff));              /* entire contents      */
            SetFocus(GetDlgItem(hDlg, IDC_EDIT));
            return (0); /* Indicates the focus is set to a control */
    }
    return 0;
}

/****************************************************************************

    FUNCTION: UpdateListBox(HWND);

    PURPOSE: Update the list box of OpenDlg

****************************************************************************/

void UpdateListBox(hDlg)
HWND hDlg;
{
    strcpy(str, DefPath);
    strcat(str, DefSpec);
    DlgDirList(hDlg, str, IDC_LISTBOX, IDC_PATH, 0x4010);

    /* To ensure that the listing is made for a subdir. of
     * current drive dir...
     */
    if (!strchr (DefPath, ':'))
	DlgDirList(hDlg, DefSpec, IDC_LISTBOX, IDC_PATH, 0x4010);

    /* Remove the '..' character from path if it exists, since this
     * will make DlgDirList move us up an additional level in the tree
     * when UpdateListBox() is called again.
     */
    if (strstr (DefPath, ".."))
	DefPath[0] = '\0';

    SetDlgItemText(hDlg, IDC_EDIT, DefSpec);
}

/****************************************************************************

    FUNCTION: ChangeDefExt(PSTR, PSTR);

    PURPOSE: Change the default extension

****************************************************************************/

void ChangeDefExt(Ext, Name)
PSTR Ext, Name;
{
    PSTR pTptr;

    pTptr = Name;
    while (*pTptr && *pTptr != '.')
        pTptr++;
    if (*pTptr)
        if (!strchr(pTptr, '*') && !strchr(pTptr, '?'))
            strcpy(Ext, pTptr);
}

/****************************************************************************

    FUNCTION: SeparateFile(HWND, LPSTR, LPSTR, LPSTR)

    PURPOSE: Separate filename and pathname

****************************************************************************/

void SeparateFile(hDlg, lpDestPath, lpDestFileName, lpSrcFileName)
HWND hDlg;
LPSTR lpDestPath, lpDestFileName, lpSrcFileName;
{
    LPSTR lpTmp;
    char  cTmp;

    lpTmp = lpSrcFileName + (long) lstrlen(lpSrcFileName);
    while (*lpTmp != ':' && *lpTmp != '\\' && lpTmp > lpSrcFileName)
        lpTmp = AnsiPrev(lpSrcFileName, lpTmp);
    if (*lpTmp != ':' && *lpTmp != '\\') {
        lstrcpy(lpDestFileName, lpSrcFileName);
        lpDestPath[0] = 0;
        return;
    }
    lstrcpy(lpDestFileName, lpTmp + 1);
    cTmp = *(lpTmp + 1);
    lstrcpy(lpDestPath, lpSrcFileName);
     *(lpTmp + 1) = cTmp;
    lpDestPath[(lpTmp - lpSrcFileName) + 1] = 0;
}

/****************************************************************************

    FUNCTION: AddExt(PSTR, PSTR);

    PURPOSE: Add default extension

/***************************************************************************/

void AddExt(Name, Ext)
PSTR Name, Ext;
{
    PSTR pTptr;

    pTptr = Name;
    while (*pTptr && *pTptr != '.')
        pTptr++;
    if (*pTptr != '.')
        strcat(Name, Ext);
}

/****************************************************************************

    FUNCTION: About(HWND, unsigned, WORD, LONG)

    PURPOSE:  Processes messages for "About" dialog box

    MESSAGES:

        WM_INITDIALOG - initialize dialog box
        WM_COMMAND    - Input received

****************************************************************************/

BOOL FAR PASCAL About(hDlg, message, wParam, lParam)
HWND hDlg;
unsigned message;
WORD wParam;
LONG lParam;
{
    switch (message) {
        case WM_INITDIALOG:
            return (TRUE);

        case WM_COMMAND:
	    if (wParam == IDOK
                || wParam == IDCANCEL) {
                EndDialog(hDlg, TRUE);
                return (TRUE);
            }
            break;
    }
    return (FALSE);
}



HWND	hwndPercentDone;

#if 0
VOID
InitPercentDone(LPSTR lpszName)
{
	HANDLE     hcti;
	int        cx, cy;

	// Note: we would have to call LoadLibrary ("perdone.dll") if we
	// weren't going to call any routines in the library!  That is because
	// even if we link with perdone.lib, the linker doesn't produce any
	// references to the lib in our .exe file if we don't call any library
	// rtns - without such a reference, the loader doesn't know that we
	// need the library loaded!
	// Since we're calling PercentDoneInfo(), we don't need to LoadLibrary(..)

	/* Create the % Done Bar */
	hcti = PercentDoneInfo();
	cx = 40;
	cy = 200;
	if (hcti)
		GlobalFree (hcti);
	hwndPercentDone = CreateWindow (CLASS_PERCENTDONE,  // class 
#if 1
  				"", //window text
				WS_CHILD | WS_VISIBLE | // styles
				    WS_BORDER |
#else
  				lpszName, //window text
				WS_POPUP | WS_VISIBLE | // styles
				    WS_BORDER | WS_CAPTION |
#endif
				    PDS_VERTICAL,
				400, 10, cx, cy,         // position (x,y) and size (cx,cy)
				hwnd, 6,                // parent, child id
				hInst, NULL);
	SendMessage (hwndPercentDone, PD_SETPOS, 0, 0L);
}


VOID FAR PASCAL
CheckProgress(WORD wNum, WORD wDenom)
{
	WORD	pos;
	double dNum = wNum, dDenom = wDenom, dPos;
    MSG msg;

	if (wNum >= wDenom) {
		pos = 100;
	} else  if (wNum == 0 || wDenom == 0) {
		pos = 1;
	} else {
		dPos = (dNum * 100.0) / dDenom;
		pos = dPos;
	}
	PeekMessage(&msg, 0, 0, 0, PM_NOREMOVE);
	SendMessage (hwndPercentDone, PD_SETPOS, pos, 0L);
	UpdateWindow(hwndPercentDone);
	if (pos == 100)
		DestroyWindow(hwndPercentDone);
}
#endif /* 0 */

/* Hack. Returns TRUE if file name 's' has an extension other than .pcd */
BOOL
dibname(LPSTR s)
{
	while (*s && *s != '.')
		s++;
	if (*s == '.') {
		s++;
		if (*s == 'p' || *s == 'P') {
/* PCD or PPM? */
			s++;
			if (*s == 'c' || *s == 'C')
				s++;
				if (*s == 'd' || *s == 'D')
					return(FALSE);
			}
	}
	return(TRUE);
}

#if 0
void 
doComposite(PCDbitmapHdl hDib, PCDphotoHdl hPcd, PCDresolution res, 
		PCDformat fmt, PCDtransform trans)
{
	LPBITMAPINFO	lpb;
	long 			nrows, ncols; 
	long			pb, cb;
	long			x, y;
	int				depth;
	char _huge		*image;
	DWORD			stride;
	RECT			r;

	if (getImageInfo(hDib, &lpb, &depth, &nrows, &ncols, &pb, &cb, &image))
		return;
	if (!lpb || !image)
		return;

	stride = ncols * cb;

	PCDsetResolution(hPcd, PCD_BASE_OVER_16);
	PCDgetSize(hPcd, &r);
/* Get size does this
	if ((int)trans & PCD_90_ROTATION) { 
		long tmp = r.bottom; 
		r.bottom = r.right; 
		r.right = tmp;
	}
*/
	PCDgetBlock(hPcd, &r, image, stride);

	relseImage(hDib);
}
#endif




/****************************************************************************

    FUNCTION:  CheckProgressCallback
    
    PURPOSE:  A callback function that provides a means of 
              graphically displaying the percentage of the
              current operation's work that has been completed
              so far.

    SYNOPSIS:  void FAR PASCAL CheckProgressCallback(int wNum, int wDenom);

                wNum   - numerator of fraction, specifying completion
                wDenom - denominator 

    RETURN VALUE(S): NONE

    COMMENTS: NONE

****************************************************************************/
int	badProgress = 0;

void FAR PASCAL CheckProgressCallback(unsigned wNum,unsigned wDenom,long lData) 
{
	struct cbinfo FAR *cbp;
	HANDLE	hcb = (HANDLE)lData;
	static time_t lasttime = 0;
	time_t thistime;

	if (wNum > wDenom) {
		badProgress++;
	}
	if (wDenom != wNum) {
		time(&thistime);
		if (thistime == lasttime)
			return;
		lasttime = thistime;
	}
	if (!hcb || !(cbp = (struct cbinfo FAR *)GlobalLock(hcb)))
		return;
	if (cbp->hdc == 0)
		cbp->hdc = GetDC(hwnd);
	if (!cbp->hwnd || !cbp->hdc)
		return;

GetClientRect(cbp->hwnd, &cbp->r);
#undef	XLEFT
#undef	YTOP
#undef	YBOTTOM
#define	XLEFT 8
#define	YTOP cbp->r.bottom - 16
#define	YBOTTOM cbp->r.bottom

	if(wNum==0) {
	/*
		if (transform == PCD_ROTATE_0 || transform == PCD_MIRROR_0)
			cbp->lineatatime = TRUE;
		else
	*/
			cbp->lineatatime = FALSE;
	     /* initialize display    */
		if (!IsIconic(cbp->hwnd)) {
			if (!cbp->therm) {
				DibBlt(cbp->hdc, 0, 0, 0, 0, hDib, 0, 0, SRCCOPY, 0);
				getImageInfo(hDib, &cbp->lpb, &cbp->depth,
					&cbp->nrows, &cbp->ncols, &cbp->pb, &cbp->cb, &cbp->image);
				cbp->xb = *(struct xb FAR *)cbp->lpb;
				cbp->lpb = (LPBITMAPINFO)&cbp->xb;
				if (cbp->swaprowcol) {
					long	tmp;

					cbp->lpb->bmiHeader.biWidth = cbp->nrows;
					cbp->lpb->bmiHeader.biHeight = cbp->ncols;
					tmp = cbp->nrows;
					cbp->nrows = cbp->ncols;
					cbp->ncols = tmp;
				}
			} /* else */
			{
			    cbp->hBrush = CreateSolidBrush(PURE_BLUE);
			    SelectObject(cbp->hdc, cbp->hBrush);
			    Rectangle(cbp->hdc, XLEFT, YTOP, XLEFT+200, YBOTTOM);
				SelectObject(cbp->hdc, GetStockObject(NULL_BRUSH));
				DeleteObject(cbp->hBrush);
			}
		}
		cbp->hBrush = 0;
	} else
		cbp->lpb = (LPBITMAPINFO)&cbp->xb;

	if (!IsIconic(cbp->hwnd)) {
		if (!cbp->therm) {
			if (/* cbp->lineatatime ||  */
			    (cbp->mod == 0 || (cbp->count % cbp->mod) == 0)) {
				if (cbp->lineatatime) {
					if (wNum)
					/*                hDC   DestX */
					SetDIBitsToDevice(cbp->hdc, 0,
					/* DestY  nWidth     nHeight */
					wNum - 1, cbp->ncols,   1,
					/* SrcX SrcY nStartScan nNumScan */
						  0, 0,    0,          1,
					/* lpBits */
					  cbp->image + (cbp->nrows - wNum) * cbp->ncols, 
					/* lpBitsInfo  wUsage */
					   cbp->lpb, DIB_RGB_COLORS);
				} else {
					/*                hDC   DestX DestY nWidth    nHeight */
					SetDIBitsToDevice(cbp->hdc, 0, 0, cbp->ncols, cbp->nrows, 
					/* SrcX SrcY nStartScan nNumScan */
						  0,   0,     0,    cbp->nrows, 
					/* lpBits lpBitsInfo  wUsage */
					cbp->image, cbp->lpb, DIB_RGB_COLORS);
				}
			}
		} /* else */ {
			cbp->hBrush = CreateSolidBrush(PURE_GREEN);    
			SelectObject(cbp->hdc, cbp->hBrush);

			cbp->percent = ((long)wNum * 100L) / wDenom;   
			cbp->pctdone[0] = '%';
			cbp->pctdone[1] = 'd';
			cbp->pctdone[2] = '%';
			cbp->pctdone[3] = '%';
			cbp->pctdone[4] = ' ';
			cbp->pctdone[5] = 'D';
			cbp->pctdone[6] = 'o';
			cbp->pctdone[7] = 'n';
			cbp->pctdone[8] = 'e';
			cbp->pctdone[9] = ' ';
			cbp->pctdone[10] = ' ';
			cbp->pctdone[11] = '\0';

			wsprintf(cbp->pct, cbp->pctdone, (short)cbp->percent);
			TextOut(cbp->hdc,XLEFT+10,YTOP-20, cbp->pct, lstrlen(cbp->pct));
			Rectangle(cbp->hdc,XLEFT,YTOP,XLEFT+(short)(2 * cbp->percent), YBOTTOM);
			SelectObject(cbp->hdc, GetStockObject(NULL_BRUSH));
			DeleteObject(cbp->hBrush);
		}
	}
	cbp->count++;
	cbp->hBrush = 0;
	if (wNum == wDenom) {
			if (!cbp->therm && cbp->lpb && hDib) 
				relseImage(hDib);
			ReleaseDC(cbp->hwnd, cbp->hdc);
	}
	{
		MSG	msg;

		while (PeekMessage(&msg, cbp->hwnd, 0, 0, PM_REMOVE))
			if (msg.message == WM_QUIT) {
				bAbort = TRUE;
				break;
			} else {
	            TranslateMessage(&msg);
	            DispatchMessage(&msg); 
			}
	}
	GlobalUnlock(hcb);
}

BOOL FAR PASCAL AbortCallback(long lData) 
{
	if (bAbort) {
		bAbort = FALSE;
		return(TRUE);
	}
	return(FALSE);
}

char	infoBuf[2048];
PCDpacInfoRec	pacInfo;
unsigned long	tv1, tv2, tv3;

#define	ONE_YEAR_OF_SECONDS \
	(unsigned long)(60UL * 60UL * 24UL * 365UL)

char st1[128], st2[128], st3[128];

void
printInfo(PCDphotoHdl hpcd)
{
	PCDpacInfoPtr	lpPacInfo = &pacInfo;
	int	i;

	if (PCDreadImageInfo(hpcd, lpPacInfo) != pcdSuccess)
		goto bad;

	lpPacInfo->mediaType[19] = '\0';
	lpPacInfo->scannerVendor[19] = '\0';
	lpPacInfo->scannerProdID[15] = '\0';
	lpPacInfo->scannerSerial[19] = '\0';
	lpPacInfo->piwEquipment[19] = '\0';

	tv1 = lpPacInfo->scanTime; 
	tv2 = lpPacInfo->modTime; 

/*
	for (i = 0; i < 10; i++) {
		tv1 -= (ONE_YEAR_OF_SECONDS);
		tv2 -= (ONE_YEAR_OF_SECONDS);
	}
*/
	time(&tv3);

	_fstrcpy(st1, (LPSTR)ctime(&tv1));
	_fstrcpy(st2, (LPSTR)ctime(&tv2));
	_fstrcpy(st3, (LPSTR)ctime(&tv3));

	wsprintf(infoBuf, "Version=%d.%d\n"
					"Ctime=%s"
					"Mtime=%s"
					"NOW=%s"
					"Magnification=%d, Medium type=%d\n"
					"Product type=%s\n"
					"Scanner Vendor=%s\n"
					"Scanner Product ID=%s\n"
					"Scanner Serial #=%s\n"
					"Scanner Pixel Size %d.%d\n"
					"PIW Equipment=%s\n"
					"Copyright=%d\n"
					"Copyright file=%s",
						(lpPacInfo->version & 0xff00) >> 8, 
						lpPacInfo->version & 0xff, 
						(LPSTR)st1, (LPSTR)st2, (LPSTR)st3,
						lpPacInfo->magnification,
						lpPacInfo->mediaId,
						lpPacInfo->mediaType,
						lpPacInfo->scannerVendor,
						lpPacInfo->scannerProdID,
						lpPacInfo->scannerSerial,
						lpPacInfo->scannerSize[0],
						lpPacInfo->scannerSize[1],
						lpPacInfo->piwEquipment,
						lpPacInfo->copyright,
						lpPacInfo->copyrightFile
						);

	MessageBox(GetFocus(), infoBuf,
						   "PhotoCD Sample Application",
						   MB_OK);

	return;

bad:
	MessageBox(GetFocus(), "Failed to retrieve image info.", 
						   "PhotoCD Sample Application",
						   MB_ICONASTERISK | MB_OK);
}

BOOL FAR PASCAL DiscChgCallback(LPSTR volID, long lData) 
{
	static int count = 0;

	if (count++ > 4) {
		wsprintf(infoBuf, "I GIVE UP!");
		count = 0;
		return(FALSE);
	} else
		wsprintf(infoBuf, "Please insert disk \"%s\"", volID);
	MessageBox(GetFocus(), infoBuf, "Wrong Disc", 
						   MB_ICONASTERISK | MB_OK);
	return(TRUE);
}
