/*�TS4,8,12,16,20,24,28� *  Photo CD Development Toolkit * *  util.c *  Routines of general
utility. * *  Copyright (c) 1991, INTERACTIVE Systems Corporation. *  All rights reserved. */ /*
LINTLIBRARY */ 

#ifdef  IDENT
#ident  "@(#)util.c 1.91 - 92/06/03" 
#endif

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <windows.h>
#include <string.h>
#include <direct.h>
#include <dos.h>
#include <stdlib.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "RectCalc.h"
#include "pcdovw.h"
#include "util.h"
#include "image.h"

#ifdef  NDEBUG
#define STATIC  static
#else
#define STATIC
#endif


#define WINBUF 0 /* use dos alloc */
DWORD FAR PASCAL GlobalDosAlloc (DWORD dwSize);
WORD FAR PASCAL GlobalDosFree (WORD wSelector);

long    currentSector = 0,
        currentOffset = 0;

PCDstatus PCDreadSome(PCDioStatePtr io, unsigned char HUGE *userBuf, long count)
{
    int ncount;
    assert(io);
    assert(userBuf);
    assert(count >= 0);

    if (io->seekloc > io->filesize)
        goto err;
	if (io->flags & PCD_IO_USE_BUF) { /* use prebuffering -- for oview */
		unsigned char FAR *preBuf;  /* pointer to current position in prebuffer */
		unsigned char FAR *cp;
		register unsigned char FAR *buf = userBuf;
		register short 	  copycount; 
#if WINBUF  /* windows alloc version */
		if (io->hBuff == NULL){
			if (count >= INTBUFFSIZE) 
			   goto unbufRead;	/* process unbuffered read */	
			if ((io->hBuff = GlobalAlloc(GMEM_MOVEABLE, INTBUFFSIZE))== NULL) 
				goto unbufRead;	/* process unbuffered read */
			io->remainder = 0;
			io->position = 0;		
		}	
	   	if ((preBuf = GlobalLock(io->hBuff)) == NULL)
			goto err;
#else	/* dos alloc version */
	  	if (io->dosAlloc == 0L){
			if (count >= INTBUFFSIZE) 
			   goto unbufRead;	/* process unbuffered read */	
			if ((io->dosAlloc = GlobalDosAlloc(INTBUFFSIZE))== NULL) 
				goto unbufRead;	/* process unbuffered read */
			io->remainder = 0;
			io->position = 0;		
		}	
	   	if ((preBuf = (LPSTR)MAKELONG(0, (LOWORD(io->dosAlloc)) )) == NULL)
			goto err;
#endif
		while (count)
		{
			if (io->remainder <= 0) /* buffer exhausted, refill */
			{
#if WINBUF 
				if (count >= INTBUFFSIZE) { /* no sense using buffer */
					GlobalUnlock (io->hBuff);
					GlobalFree (io->hBuff);
					io->hBuff = NULL;
					goto unbufRead;
				}
#endif
				if ((io->remainder = _lread(io->fd, preBuf, INTBUFFSIZE)) == (unsigned)-1) 
        			goto err;
				io->seekloc += io->remainder;
				io->position = 0;
			}
			copycount = (count < (long)io->remainder) ? (short)count : io->remainder;
			cp = preBuf + io->position;
			io->position += copycount;
			io->remainder -= copycount;
			count -= copycount;
			while (copycount-- > 0)
				*buf++ = *cp++;
		}
#if WINBUF 
		GlobalUnlock (io->hBuff);
#endif
		return(pcdSuccess);
	}
unbufRead:
	if ((ncount = _lread(io->fd, userBuf, (WORD) count)) != (int) count) 
        goto err;
    io->seekloc += ncount;
    return(pcdSuccess);

err:
    if (io->throwInError) {
        io->throwInError = FALSE;
        Throw((LPCATCHBUF)io->catchbuf, 1);
    }
    return(EIO);
}

PCDstatus PCDsetMark(PCDioStatePtr io, long off, short whence)
{
    assert(io && io->fd >= 0);
    if (_llseek(io->fd, off, whence) < 0)
        return(EIO);
    switch (whence) {
    case 0:
		if (io->hBuff) {
			GlobalFree (io->hBuff); 
			io->hBuff = NULL;  /* force re-establishment of buffer on next read */
		}
		if (io->dosAlloc) {
			GlobalDosFree (LOWORD(io->dosAlloc));
			io->dosAlloc = NULL;
		}                                                                       
		io->seekloc = off;
        break;
    case 1: /* relative set mark case */
		if ((io->flags & PCD_IO_USE_BUF) && (io->hBuff || io->dosAlloc)) {
			/* if offset is within buffer (offset may be neg), then reset io->position instead of io->seekloc */
			if ( ((io->position + off) >= 0) && (off < io->remainder)) {
				io->position += (short)off;
				break;
			}
			else { /* get rid of buffer & fall thru to readjust seekloc */
				if (io->hBuff) {
					GlobalFree (io->hBuff); 
					io->hBuff = NULL;  /* force re-establishment of buffer on next read */
				}
				if (io->dosAlloc) {
					GlobalDosFree (LOWORD(io->dosAlloc));
					io->dosAlloc = NULL;
				}
				io->seekloc -= (io->position + io->remainder);
			}
		}						
       	io->seekloc += off;
        break;
    case 2:
        if (io->hBuff) {
			GlobalFree (io->hBuff); 
			io->hBuff = NULL;  /* force re-establishment of buffer on next read */
		}
		if (io->dosAlloc) {
			GlobalDosFree (LOWORD(io->dosAlloc));
			io->dosAlloc = NULL;
		}
		io->seekloc = io->filesize - off;
    }
    return(pcdSuccess);
}

/*
 *  needswab - returns 1 if this machine is big-endian
 *  0 otherwise.
 */
int needswab(void)
{
    union {
        char c[2];
        short s;
    } un;
    un.c[0] = 1;
    un.c[1] = 2;
    assert((un.s == 0x0102) || (un.s == 0x0201));
    return (un.s == 0x0102);
}

char HUGE *
memcpyg(dst, src, n, dstskip)
    register unsigned char HUGE *dst, HUGE *src;
    long n;
    long dstskip;
{
	register unsigned long HUGE	*hSrc;
	register unsigned long HUGE	*hDst;
    char		HUGE *rv;
	DWORD		indx, nLongs;
	WORD		nBytes,j;

    rv = dst;
    if (dstskip == 1) 
    {
		hSrc = (unsigned long HUGE *) src;
		hDst = (unsigned long HUGE *) dst;
		nLongs = n / 4;									/* copy 4 bytes at a time */
		
		for(indx = 0; indx < nLongs; indx++)
			*hDst++ = *hSrc++;

		if((nBytes = (WORD) (n & 0x3)) != 0)
		{												/* copy left over bytes */
			src = (unsigned char HUGE *) hSrc;
			dst = (unsigned char HUGE *) hDst;
			for(j = 0; j < nBytes; j++)
				*dst++ = *src++;
		}
		 
    }
	else
	{
	    while (n--)
	    {
	        *dst = *src++;
	        dst += dstskip;
		}
    }
    return (rv);
}

LPRECT
RectRotate(LPRECT r, int width, int height)
{
    RECT    rc = *r;

    rc.top = r->left;
    rc.bottom = r->right;
    rc.left = width - r->bottom;
    rc.right = width - r->top;
    *r = rc;
    return(r);
}

LPRECT  RectVertMirror(LPRECT r, int imgwd)
{
    RECT    rc = *r;

    rc.right  = imgwd - r->left;
    rc.left   = imgwd - r->right;
    *r = rc;
    return(r);
}

LPRECT  RectHorizMirror(LPRECT r, int imght)
{
    RECT    rc = *r;

    rc.bottom = imght - r->top;
    rc.top    = imght - r->bottom;
    *r = rc;
    return(r);
}

#ifndef NDEBUG
void
chkPtr(unsigned char HUGE *ptr, HANDLE h)
{
    unsigned char HUGE *hbase;

    if (!ptr)
        assert(ptr != 0);
    if (((unsigned long)ptr & 0xffff0000) == 0)
        assert(((unsigned long)ptr & 0xffff0000) != 0);
    if (h) {
        WORD    gf = GlobalFlags(h);
        unsigned long size;

        if (gf & GMEM_DISCARDED)
            assert((gf & GMEM_DISCARDED) == 0);
        if ((size = GlobalSize(h)) == 0)
            assert(size != 0);
        if ((hbase = (unsigned char HUGE *)GlobalLock(h)) == 0) 
            assert(hbase != 0);
        if (ptr < hbase)
            assert(ptr >= hbase);
        if (ptr >= hbase + size);
            assert(ptr < hbase + size);
        GlobalUnlock(h);
    } else
        hbase = 0; 
}
#endif /*NDEBUG*/

/*
 * Malloc replacement (aids debugging to have handle readily available).
 */
#define MBMAGIC 0x1234

typedef struct memblk {
    HANDLE          hMem;
    unsigned short  nMagic;
    unsigned long   lSize;
}   FAR *PCDmemblk;

PCDRAWDATA
PCDmalloc(unsigned long size)
{
    HANDLE h;
    PCDmemblk mb;
    PCDRAWDATA rd;

    assert(size != 0);
    if ((h = GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, 
                    size + sizeof(struct memblk))) == 0) 
        return(0);
    if ((rd = (PCDRAWDATA)GlobalLock(h)) == 0) {
        GlobalFree(h);
        return(0);
    }
    mb = (PCDmemblk)rd;
    mb->hMem = h;
    mb->nMagic = MBMAGIC;
    mb->lSize = size;
    rd += sizeof(struct memblk);
    return(rd);
}

void
PCDfree(PCDRAWDATA rd)
{
    HANDLE h;
    PCDmemblk mb;

    assert(rd);
    if (!rd)
        return;
    rd -= sizeof(struct memblk);
    mb = (PCDmemblk)rd;
    assert(mb->nMagic == MBMAGIC);
    h = mb->hMem;
    assert(h);
    if (!h)
        return;
    assert(!(GlobalFlags(h) & GMEM_DISCARDED));
    GlobalUnlock(h);
    GlobalFree(h);
}

/*
 * Convert DIB to DDB using CreateDIBitmap().
 */
PCDstatus FAR PASCAL
PCDconvertBitmap(PCDbitmapHdl hPCDbitmap, HDC hDisplayContext,
                 HBITMAP FAR *lphBitmap)
{
    HBITMAP hb;
    LPBITMAPINFO    lpb;
    long            nrows, ncols; 
    long            pb, cb;
    int             depth;
    char _huge      *image;
    PCDstatus       rv = pcdSuccess;

    paramck(hPCDbitmap);
    paramck(hDisplayContext);
    paramck(lphBitmap);

    if (getImageInfo(hPCDbitmap, 
                     &lpb, &depth, &nrows, &ncols, &pb, &cb, &image))
        return(pcdBadParam);

    assert(lpb);
    assert(image);
    if (!lpb || !image)
        return(ENOMEM);

    hb = CreateDIBitmap(hDisplayContext, (LPBITMAPINFOHEADER)lpb, CBM_INIT,
                        (LPSTR)image, lpb, DIB_RGB_COLORS);
    if (!hb)
        rv = pcdBadParam; /* XXX - better return code */
    *lphBitmap = hb;
    relseImage(hPCDbitmap);
    return(rv);
}

/*
 * Re-open the IO stream.
 */
PCDstatus
PCDopenFile(PCDioStatePtr io)
{
    assert(io);
    if (io->flags & PCD_IO_IS_OPEN)
        return(pcdSuccess);
    if ((io->fd = OpenFile(io->of.szPathName, &io->of, OF_REOPEN)) < 0) {
        return(errno ? errno : EIO);
    }
    io->flags |= PCD_IO_IS_OPEN;
    return(pcdSuccess);
}

/*
 * Temporarily close the IO stream.
 * Added check for PCD_IO_LEAVE_OPEN. This is set if file was opened by user 
 * instead of the toolkit. (KS)
 */
PCDstatus
PCDcloseFile(PCDioStatePtr io)
{
    assert(io);
    if ((!(io->flags & PCD_IO_IS_OPEN)) || (io->flags & PCD_IO_LEAVE_OPEN))
        return(pcdSuccess);
    _lclose(io->fd);
    io->flags &= ~PCD_IO_IS_OPEN;
    return(pcdSuccess);
}


/*
 * Load a DLL.
 */
HANDLE
PCDloadLibrary(LPSTR lpszFileName)
{
    extern HANDLE hPCDlib; /* instance handle of PCDLIB.DLL */
    static BOOL firstTime = TRUE;
    static char moduleDir[_MAX_PATH];
    static char fullName[_MAX_PATH];
    static int  nNameLen = 0;
    int i;
    int lastSlash = -1;
    char c;

    if (!lpszFileName)
        return(0);
    if (firstTime || !moduleDir[0] || nNameLen <= 0) {
        if (!hPCDlib)
            return(0);
        if ((nNameLen = GetModuleFileName(hPCDlib, moduleDir, 
                sizeof(moduleDir))) <= 0) {
            moduleDir[0] = 0;
            return(0);
        }
        for (i = 0; i < nNameLen; i++) {
            c = fullName[i] = moduleDir[i];
            if (c == '\\' || c == '/')
                lastSlash = i;
        }
        if (lastSlash < 0)
            lastSlash = nNameLen;
        nNameLen = lastSlash;
        moduleDir[nNameLen] = '\\';
        firstTime = FALSE;
    }
    for (i = 0; lpszFileName[i]; i++)
        fullName[nNameLen + 1 + i] = lpszFileName[i];
    fullName[nNameLen + 1 + i] = 0;
    return(LoadLibrary(fullName));
}

#include "pcdcbf.h"

/*
 * See if the expected volume is present.
 */
BOOL
checkVolume(PCDioStatePtr io)
{
    char volIDbuf[PCDVOLSIZE];
    char FAR *volID = volIDbuf;
    discChgFuncPtr volFunc;

    assert(io);
    if (!io->volChg)
        return(TRUE);
    if (!io->drive[0] || io->drive[1] != ':' || 
                io->drive[2] != '\0')
        return(TRUE);
    for (;;) {
        if (PCDgetVolume(io->drive, volID) != pcdSuccess)
            break;
        if (_fstrncmp(io->volID, volID, PCDVOLSIZE - 1) == 0) 
            return(TRUE);
        /* Volume ID does not match */
        if ((volFunc = io->volChg) == 0)
            break;
        if (!(*volFunc)(io->volID, io->volChgData))
            break;
    }
    return(FALSE);
}

char dirbuf[_MAX_PATH];

/*
 * Attempt to determine the drive and volume ID
 * of the disc associated with |io|. 
 */

void getVolInfo(PCDioStatePtr io) 
{
    io->drive[0] = io->drive[1] = 
        io->drive[2] = '\0';
/* Only do the hard stuff for ipacs on removable media 
    if (io->of.fFixedDisk)
        return;
*/
    if (io->of.szPathName[1] == ':') {
        io->drive[0] = io->of.szPathName[0];
    } else {
        if (_getcwd(dirbuf, sizeof(dirbuf)) && dirbuf[1] == ':')
            io->drive[0] = dirbuf[0];
        else
            io->drive[0] = '\0';
    }
    if (io->drive[0]) {
        io->drive[1] = ':';
        if (PCDgetVolume(io->drive, io->volID) != pcdSuccess)
            io->drive[0] = '\0';
    }
}

#define DEFAULT_ALLOWANCE   0x200000
#define MIN_ALLOWANCE       0x006000

long    ToolkitAllowance = DEFAULT_ALLOWANCE;
long    TKAused = 0;

PCDstatus FAR PASCAL
PCDsetAllowance(long lMaxBytes)
{
    paramck(lMaxBytes >= 0);
    if (lMaxBytes < MIN_ALLOWANCE)
        lMaxBytes = MIN_ALLOWANCE;
    ToolkitAllowance = lMaxBytes;
    return(pcdSuccess);
}

PCDstatus FAR PASCAL
PCDgetAllowance(long FAR *lplMaxBytes)
{
    paramck(lplMaxBytes);
    *lplMaxBytes = ToolkitAllowance;
    return(pcdSuccess);
}

BOOL neverFits = FALSE;

BOOL
fitsInSegment(unsigned char HUGE *hp, long count, long colBytes)
{
    unsigned char HUGE *hp2;
    unsigned short seg, seg2;

/*XXX for now...*/
    if (colBytes < 0)
        return(FALSE);

    hp2 = hp + (count * colBytes);

    seg = _FP_SEG(hp);
    seg2 = _FP_SEG(hp2);

if (neverFits)
return(FALSE);

    return(seg == seg2);
}

#define SIXTYFOUR_K (0x10000)

unsigned short
pixInSegment(unsigned char HUGE *hp1, unsigned char HUGE *hp2, 
        short colBytes)
{
    unsigned char HUGE *hp;
    unsigned short bytesInSegment;
    short npix, resid;

    if (colBytes == 0 || (_FP_SEG(hp1) != _FP_SEG(hp2)))
        return(0L);

    if (colBytes > 0) {
        if (hp1 < hp2)
            hp = hp1;
        else
            hp = hp2;
        bytesInSegment = 0xffff - _FP_OFF(hp);
        npix = bytesInSegment / colBytes;
        resid = bytesInSegment % colBytes;
        if (npix && (resid == 0))
            npix--;
    } else {
        if (hp1 > hp2)
            hp = hp1;
        else
            hp = hp2;
        bytesInSegment = _FP_OFF(hp);
        npix = bytesInSegment / -colBytes;
    }
    return(npix);
}
