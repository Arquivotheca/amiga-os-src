/*
 *	Photo CD Development Toolkit
 *
 *	interp.c
 *	interpolation primitives
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)interp.c	1.64 - 92/06/03"
#endif
#include <windows.h>
#include <assert.h>
#include <dos.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "interp.h"

/*
 * Functions to perform bilinear interpolation.
 * Those starting with 'h' use HUGE pointers for
 * the source data; the 'f' functions use FAR.
 * The number is to the interpolation factor.
 */
void hlinear2(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes);

void flinear2(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char FAR *dst, 
			short count, long colBytes);

void hlinear4(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes);

void flinear4(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char FAR *dst, 
			short count, long colBytes);

void hlinear8(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes);

void flinear8(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char FAR *dst, 
			short count, long colBytes);


/*
 * General purpose bilinear interpolator. Divides its
 * work into three parts: those pixels falling to the left
 * of the first 'even' pixel, those to the right of the
 * last 'even' pixel, and those inbetween (where 'even' means
 * having a coordinate which is an even multiple of the factor). 
 * The middle pixels can be done with one of the optimized
 * functions above for speed.
 */
void linear(factor, syndrome, srcp, nextp, dst, 
			srcRight, dstLeft, dstRight, colBytes)
	short factor, syndrome;
	unsigned char FAR *srcp, FAR *nextp; 
	unsigned char HUGE *dst;
	short srcRight, dstLeft, dstRight;
	long colBytes;
{
	unsigned char FAR *base;
	unsigned short src, next;
	short srcMult, nextMult, leftMult, rightMult;
	unsigned short iv;
	short factminus1, factsquared;
	short firstEasy, lastEasy;
	short nEasy;
	unsigned char FAR *fdst;

	assert(syndrome >= 0 || syndrome <= (factor - 1));
	assert(srcp);
	assert(nextp);
	assert(dst);
	assert(dstLeft < dstRight);

	if (srcp <= nextp) {
		base = srcp;
		src = 0;
		next = nextp - srcp;
	} else {
		base = nextp;
		next = 0;
		src = srcp - nextp;
	}
	factminus1 = factor - 1;
	factsquared = factor * factor;

	src += dstLeft / factor;
	next += dstLeft / factor;
	srcMult = factor - syndrome;
	nextMult = syndrome;

	/*
	 * Calculate range of pixels which do not
	 * require special handling.
	 */
	if (dstLeft % factor)
		firstEasy = dstLeft + (factor - (dstLeft % factor));
	else
		firstEasy = dstLeft;
	if (firstEasy >= srcRight)
		firstEasy = srcRight - factor;

	if (dstRight < srcRight)
		lastEasy = dstRight & ~factminus1;
	else
		lastEasy = dstRight - factor;

	/* 
	 * Do leftmost pixels first.
	 */
	while (dstLeft < firstEasy) {
		rightMult = dstLeft % factor;
		leftMult = factor - rightMult;
		iv = ((srcMult  * leftMult  * base[src])
		 	  + (srcMult  * rightMult * base[src + 1])
		 	  + (nextMult * leftMult  * base[next])
		 	  + (nextMult * rightMult * base[next + 1]));
		if (iv & (factsquared >> 1)) iv += (factsquared >> 1);
		*dst = (unsigned char)(iv / factsquared);
		dst += colBytes;
		if ((dstLeft % factor) == factminus1)
			base++;
		dstLeft++;
	}

	if (firstEasy < lastEasy) {
		nEasy = lastEasy - firstEasy;
		/*
		 * Call optimized function to handle the easy parts.
		 */
		if (fitsInSegment(dst, (long)nEasy * (long)factor, colBytes)) {
			fdst = dst;

			switch(factor) {
			case 2:
				flinear2(syndrome, base, src, next, fdst, 
					nEasy, colBytes);
				break;
			case 4:
				flinear4(syndrome, base, src, next, fdst, 
					nEasy, colBytes);
				break;
			case 8:
				flinear8(syndrome, base, src, next, fdst, 
					nEasy, colBytes);
				break;
			default:
				assert(1011 == 2022);
			}
		} else {
/* Source doesn't fit in a segment: use HUGE pointers */
			switch(factor) {
			case 2:
				hlinear2(syndrome, base, src, next, dst, 
					nEasy, colBytes);
				break;
			case 4:
				hlinear4(syndrome, base, src, next, dst, 
					nEasy, colBytes);
				break;
			case 8:
				hlinear8(syndrome, base, src, next, dst, 
					nEasy, colBytes);
				break;
			default:
				assert(1011 == 2022);
			}
		}

		dstLeft += nEasy;
		dst += (unsigned long)nEasy * (unsigned long)colBytes;
		base += nEasy / factor;
	}

	/*
	 *	Handle rightmost pixels in image row.
	 */
	while (dstLeft < dstRight) {
		rightMult = dstLeft % factor;
		leftMult = factor - rightMult;
		if ((srcRight - dstLeft) > factminus1) {
			iv = ((srcMult  * leftMult  * base[src])
			 	  + (srcMult  * rightMult * base[src + 1])
			 	  + (nextMult * leftMult  * base[next])
			 	  + (nextMult * rightMult * base[next + 1]));
			if (iv & (factsquared >> 1)) iv += (factsquared >> 1);
			*dst = (unsigned char)(iv / factsquared);
		} else {
			iv = ((srcMult  * base[src]) 
				  + (nextMult * base[next]));
			if (iv & (factor >> 1)) iv += (factor >> 1);
			*dst = (unsigned char)(iv / factor);
		}
		dst += colBytes;
		dstLeft++;
	}
} /* end linear */

 
int	doInterpChroma = 1; /*XXX*/

void decimate(cp, len)
	unsigned char HUGE *cp;
	long len;
{
	long	i;
	unsigned short iv;

	len /= 2;
	if (!doInterpChroma) {
		for (i = 1; i < len; i++)
			cp[i] = cp[2 * i];
	} else {
		for (i = 1; i < len - 1; i++) {
//			cp[i] = (unsigned char) ((cp[2 * i] + cp[(2 * i) + 1]) / 2);
			iv = (unsigned short) (cp[2 * i] + cp[(2 * i) + 1]);
			if (iv & 1) iv++;
			cp[i] = (unsigned char)(iv >> 1);
		}
		cp[i] = cp[2 * i];
	}
} /* end decimate */

void expandchroma(cp, len)
	unsigned char HUGE *cp;
	long len;
{
	unsigned char HUGE *sp;
	unsigned short iv;
	
	assert(len > 0);
	assert((long)len < (16L * 1024L));

	len /= 2;
	sp = cp + len;
if (!doInterpChroma) {
	while (len--) {
		*cp++ = *sp;
		*cp++ = *sp++;
	}
} else {
	len--;
	while (len--) {
		*cp++ = sp[0];
//		*cp++ = (sp[0] + sp[1]) / 2;
		iv = (unsigned short) (sp[0] + sp[1]);
		if (iv & 1) iv++;
		*cp++ = (unsigned char)(iv >> 1);
		sp++;
	}
	*cp++ = *sp;
	*cp++ = *sp;
}
} /* end expandchroma */
 
 
#pragma	optimize("a", on)
#pragma	loop_opt(on)
#pragma	optimize("z", on)

void
foldchroma(unsigned char HUGE *bp, short s1, short s2, short d,
	 long len)
{
	unsigned short	iv;
	unsigned short boff = _FP_OFF(bp);
	const register _segment bseg = _FP_SEG(bp);
	unsigned char _based(void) *src1 = 0;
	unsigned char _based(void) *src2 = 0;
	unsigned char _based(void) *dst = 0;

	src1 += s1 + boff;
	src2 += s2 + boff;
	dst  += d  + boff;

	while (len--) {
		iv = *(bseg:>src1) + *(bseg:>src2);
		if (iv & 1) iv++; 
		*(bseg:>dst) = (unsigned char)(iv >> 1);
		src1++;
		src2++;
		dst++;
	}
} /* end foldchroma */

/*XXX - experimental*/ 
void 
interp1d(factor, syndrome, src, next, dst, colBytes, count)
	short factor, syndrome;
	unsigned char HUGE *src, HUGE *next, HUGE *dst;
	short colBytes;
	long  count;
{
	short srcMult, nextMult;

	assert(src);
	assert(next);
	assert(dst);

	nextMult = syndrome;
	srcMult = factor - syndrome;

	while (count--) {
		*dst = ((srcMult * *src) + (nextMult * *next)) / factor;
		src  += colBytes;
		next += colBytes;
		dst  += colBytes;
	}
} /* end foldchroma */

