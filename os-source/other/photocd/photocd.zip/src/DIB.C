/*******************************************************************************
 *                                         *
 *  MODULE  : DIB.C                                *
 *                                         *
 *  DESCRIPTION : Routines for dealing with Device Independent Bitmaps.        *
 *                                         *
 *  FUNCTIONS   : OpenDIB()       - Opens DIB file and creates a memory DIB*
 *                                         *
 *        WriteDIB()          - Writes a global handle in CF_DIB format*
 *                  to a file.                 *
 *                                         *
 *        DibInfo()       - Retrieves the info. block associated   *
 *                  with a CF_DIB format memory block.     *
 *                                         *
 *        CreateBIPalette()   - Creates a GDI palette given a pointer  *
 *                  to a BITMAPINFO structure.         *
 *                                         *
 *        CreateDibPalette()  - Creates a GDI palette given a HANDLE   *
 *                  to a BITMAPINFO structure.         *
 *                                         *
 *        ReadDibBitmapInfo() - Reads a file in DIB format and returns *
 *                  a global handle to it's BITMAPINFO     *
 *                                         *
 *        PaletteSize()       - Calculates the palette size in bytes   *
 *                  of given DIB                   *
 *                                         *
 *        DibNumColors()      - Determines the number of colors in DIB *
 *                                         *
 *        BitmapFromDib()     - Creates a DDB given a global handle to *
 *                  a block in CF_DIB format.          *
 *                                         *
 *        DibFromBitmap()     - Creates a DIB repr. the DDB passed in. *
 *                                         *
 *        DrawBitmap()        - Draws a bitmap at specified position   *
 *                  in the DC.                 *
 *                                         *
 *        DibBlt()        - Draws a bitmap in CIF_DIB format using *
 *                  SetDIBitsToDevice()            *
 *                                         *
 *        StretchDibBlt()     - Draws a bitmap in CIF_DIB format using *
 *                  StretchDIBits()                *
 *                                         *
 *        lread()         - Private routine to read more than 64k  *
 *                                         *
 *        lwrite()        - Private routine to write more than 64k *
 *                                         *
 *******************************************************************************/

#include <windows.h>
#include <ctype.h>
#include <assert.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "showdib.h"
#include "pal.h"
/*
#include "octree.h"
*/

#define DEFTABLES 1
#include "ycctab.h"

HCURSOR hcurSave;
BOOL    bPPM;
BOOL    bFakePPM;


/****************************************************************************
 *                                      *
 *  FUNCTION   :OpenDIB(LPSTR szFile)                       *
 *                                      *
 *  PURPOSE    :Open a DIB file and create a MEMORY DIB, a memory handle    *
 *      containing BITMAPINFO, palette data and the bits.       *
 *                                      *
 *  RETURNS    :A handle to the DIB.                        *
 *                                      *
 ****************************************************************************/
HANDLE OpenDIB (szFile)
LPSTR szFile;
{
    unsigned        fh;
    BITMAPINFOHEADER    bi;
    LPBITMAPINFOHEADER  lpbi;
    DWORD       dwLen = 0;
    DWORD       dwBits;
    HANDLE      hdib;
    HANDLE              h;
    OFSTRUCT        of;

    /* Open the file and read the DIB information */
    fh = OpenFile(szFile, &of, OF_READ);
    if (fh == -1)
    return NULL;

    hdib = ReadDibBitmapInfo(fh);
    if (!hdib)
    return NULL;
    DibInfo(hdib,&bi);

    /* Calculate the memory needed to hold the DIB */
    dwBits = bi.biSizeImage;
    dwLen  = bi.biSize + (DWORD)PaletteSize (&bi) + dwBits + PCDBMEXTRABYTES;

    /* Try to increase the size of the bitmap info. buffer to hold the DIB */
    h = GlobalReAlloc(hdib, dwLen, GHND);
    if (!h){
        GlobalFree(hdib);
        hdib = NULL;
    }
    else {
        hdib = h;
        lpbi = (VOID FAR *)GlobalLock(hdib);
    }
    /* Read in the bits */
    if (hdib){
        RGBQUAD FAR *pal = ((LPBITMAPINFO)lpbi)->bmiColors;
        char _huge  *pixls = (LPSTR)lpbi+(WORD)lpbi->biSize+PaletteSize(lpbi);

        lpbi = (VOID FAR *)GlobalLock(hdib);
if (lpbi->biWidth & 1) {
    char    _huge *cp = pixls;
/* Gross: if odd width, make even */
    DWORD   w = lpbi->biWidth;
    DWORD   h = lpbi->biHeight;
    DWORD   w3 = w * 3;

    lpbi->biWidth -= 1;

    while (h--) {
        _lread(fh, cp, w3);
        cp += w3 - 3;
    }
} else {
        lread(fh, pixls, dwBits);
}

    GlobalUnlock(hdib);
    }
    _lclose(fh);

    return hdib;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : WriteDIB(LPSTR szFile,HANDLE hdib)             *
 *                                      *
 *  PURPOSE    : Write a global handle in CF_DIB format to a file.      *
 *                                      *
 *  RETURNS    : TRUE  - if successful.                     *
 *       FALSE - otherwise                      *
 *                                      *
 ****************************************************************************/
BOOL WriteDIB (szFile, hdib)
LPSTR szFile;
HANDLE hdib;
{
    BITMAPFILEHEADER    hdr;
    LPBITMAPINFOHEADER  lpbi;
    int                 fh;
    OFSTRUCT            of;

    if (!hdib)
    return FALSE;

    fh = OpenFile (szFile, &of, OF_CREATE|OF_READWRITE);
    if (fh == -1)
    return FALSE;

    lpbi = (VOID FAR *)GlobalLock (hdib);

    /* Fill in the fields of the file header */
    hdr.bfType      = BFT_BITMAP;
    hdr.bfSize      = GlobalSize (hdib) + sizeof (BITMAPFILEHEADER);
    hdr.bfReserved1     = 0;
    hdr.bfReserved2     = 0;
    hdr.bfOffBits       = (DWORD)sizeof(BITMAPFILEHEADER) + lpbi->biSize +
                          PaletteSize(lpbi);

    /* Write the file header */
    _lwrite (fh, (LPSTR)&hdr, sizeof (BITMAPFILEHEADER));

    /* Write the DIB header and the bits */
    lwrite (fh, (LPSTR)lpbi, GlobalSize (hdib));

    GlobalUnlock (hdib);
    _lclose (fh);
    return TRUE;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : DibInfo(HANDLE hbi,LPBITMAPINFOHEADER lpbi)            *
 *                                      *
 *  PURPOSE    : Retrieves the DIB info associated with a CF_DIB        *
 *       format memory block.                       *
 *                                      *
 *  RETURNS    : TRUE  - if successful.                     *
 *       FALSE - otherwise                      *
 *                                      *
 ****************************************************************************/
BOOL DibInfo (hbi, lpbi)
HANDLE hbi;
LPBITMAPINFOHEADER lpbi;
{
    if (hbi){
    *lpbi = *(LPBITMAPINFOHEADER)GlobalLock (hbi);

    /* fill in the default fields */
    if (lpbi->biSize != sizeof (BITMAPCOREHEADER)){
            if (lpbi->biSizeImage == 0L)
        lpbi->biSizeImage =
            WIDTHBYTES(lpbi->biWidth*lpbi->biBitCount) * lpbi->biHeight;

            if (lpbi->biClrUsed == 0L)
        lpbi->biClrUsed = DibNumColors (lpbi);
        }
    GlobalUnlock (hbi);
    return TRUE;
    }
    return FALSE;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : CreateBIPalette(LPBITMAPINFOHEADER lpbi)           *
 *                                      *
 *  PURPOSE    : Given a Pointer to a BITMAPINFO struct will create a       *
 *       a GDI palette object from the color table.         *
 *                                      *
 *  RETURNS    : A handle to the palette.                   *
 *                                      *
 ****************************************************************************/
HPALETTE CreateBIPalette (lpbi)
LPBITMAPINFOHEADER lpbi;
{
    LOGPALETTE          *pPal;
    HPALETTE            hpal = NULL;
    WORD                nNumColors;
    BYTE                red;
    BYTE                green;
    BYTE                blue;
    int                 i;
    RGBQUAD        FAR *pRgb;

    if (!lpbi)
    return NULL;

    if (lpbi->biSize != sizeof(BITMAPINFOHEADER))
    return NULL;

    /* Get a pointer to the color table and the number of colors in it */
    pRgb = (RGBQUAD FAR *)((LPSTR)lpbi + (WORD)lpbi->biSize);
    nNumColors = DibNumColors(lpbi);

    if (nNumColors){
    /* Allocate for the logical palette structure */
        pPal = (LOGPALETTE*)LocalAlloc(LPTR,sizeof(LOGPALETTE) + nNumColors * sizeof(PALETTEENTRY));
    if (!pPal)
        return NULL;

        pPal->palNumEntries = nNumColors;
    pPal->palVersion    = PALVERSION;

    /* Fill in the palette entries from the DIB color table and
     * create a logical color palette.
     */
    for (i = 0; i < nNumColors; i++){
            pPal->palPalEntry[i].peRed   = pRgb[i].rgbRed;
            pPal->palPalEntry[i].peGreen = pRgb[i].rgbGreen;
            pPal->palPalEntry[i].peBlue  = pRgb[i].rgbBlue;
            pPal->palPalEntry[i].peFlags = (BYTE)0;
        }
        hpal = CreatePalette(pPal);
        LocalFree((HANDLE)pPal);
    }
    else if (lpbi->biBitCount == 24){
    /* A 24 bitcount DIB has no color table entries so, set the number of
     * to the maximum value (256).
     */
    nNumColors = MAXPALETTE;
        pPal = (LOGPALETTE*)LocalAlloc(LPTR,sizeof(LOGPALETTE) + nNumColors * sizeof(PALETTEENTRY));
        if (!pPal)
        return NULL;

    pPal->palNumEntries = nNumColors;
    pPal->palVersion    = PALVERSION;

    red = green = blue = 0;

    /* Generate 256 (= 8*8*4) RGB combinations to fill the palette
     * entries.
     */
    for (i = 0; i < pPal->palNumEntries; i++){
            pPal->palPalEntry[i].peRed   = red;
            pPal->palPalEntry[i].peGreen = green;
            pPal->palPalEntry[i].peBlue  = blue;
            pPal->palPalEntry[i].peFlags = (BYTE)0;

        if (!(red += 32))
        if (!(green += 32))
            blue += 64;
        }
        hpal = CreatePalette(pPal);
        LocalFree((HANDLE)pPal);
    }
    return hpal;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : CreateDibPalette(HANDLE hbi)                   *
 *                                      *
 *  PURPOSE    : Given a Global HANDLE to a BITMAPINFO Struct           *
 *       will create a GDI palette object from the color table.     *
 *       (BITMAPINFOHEADER format DIBs only)                     *
 *                                      *
 *  RETURNS    : A handle to the palette.                   *
 *                                      *
 ****************************************************************************/
HPALETTE CreateDibPalette (hbi)
HANDLE hbi;
{
    HPALETTE hpal;

    if (!hbi)
    return NULL;
    hpal = CreateBIPalette((LPBITMAPINFOHEADER)GlobalLock(hbi));
    GlobalUnlock(hbi);
    return hpal;
}

#include <sys/types.h>
#include <sys/stat.h>

/****************************************************************************
 *                                      *
 *  FUNCTION   : ReadDibBitmapInfo(int fh)                  *
 *                                      *
 *  PURPOSE    : Will read a file in DIB format and return a global HANDLE  *
 *       to it's BITMAPINFO.  This function will work with both     *
 *       "old" (BITMAPCOREHEADER) and "new" (BITMAPINFOHEADER)      *
 *       bitmap formats, but will always return a "new" BITMAPINFO  *
 *                                      *
 *  RETURNS    : A handle to the BITMAPINFO of the DIB in the file.     *
 *                                      *
 ****************************************************************************/
char    ppmbuf[1024];

HANDLE ReadDibBitmapInfo (fh)
int fh;
{
    DWORD     off;
    HANDLE    hbi = NULL;
    int       size;
    int       i;
    WORD      nNumColors;

    RGBQUAD FAR       *pRgb;
    BITMAPINFOHEADER   bi;
    BITMAPCOREHEADER   bc;
    LPBITMAPINFOHEADER lpbi;
    BITMAPFILEHEADER   bf;
    DWORD          dwWidth = 0;
    DWORD          dwHeight = 0;
    WORD           wPlanes, wBitCount;

    bPPM = bFakePPM = FALSE;

    if (fh == -1)
        return NULL;

    /* Reset file pointer and read file header */
    off = _llseek(fh, 0L, SEEK_CUR);
    if (sizeof (bf) != _lread (fh, (LPSTR)&bf, sizeof (bf)))
        return FALSE;

    /* Do we have a RC HEADER? */
    if (!ISDIB (bf.bfType)) {
        bf.bfOffBits = 0L;
    _llseek (fh, off, SEEK_SET);
    }
    if (sizeof (bi) != _lread (fh, (LPSTR)&bi, sizeof(bi)))
        return FALSE;

    bi.biClrUsed = 0;
    if ((size = (int)bi.biSize) != sizeof(BITMAPINFOHEADER)) {
        struct _stat        st;
        LPSTR           s = (LPSTR)&bf;
        WORD            width, height, maxcolor;
        LONG            xoff = 0;

        bi.biSize=(long)sizeof(BITMAPINFOHEADER);

        if ((s[0] == 'P' && s[1] == '7')) {
            s[1] = '6';
            bFakePPM = TRUE;
        }
        if ((s[0] == '7' && s[1] == 'P')) {
            s[0] = '6';
            bFakePPM = TRUE;
        }
        if ((s[0] == 'P' && s[1] == '6') || (s[1] == 'P' && s[0] == '6')) {
/* PPM */
            WORD    x;
            DWORD   svoff = _llseek (fh, 0L, SEEK_SET);

            bPPM = TRUE;
            _lread(fh, ppmbuf, sizeof(ppmbuf));
            _llseek(fh, svoff, SEEK_SET);
            s = ppmbuf;

            s += 2, xoff += 2;
            while (isspace(*s)) s++, xoff++;
            x = 0;
            while (*s && isdigit(*s)) {
                x *= 10;
                x += *s - '0';
                s++, xoff++;
            }
            width = x;
            while (*s && !isspace(*s)) s++, xoff++;
            while (*s && isspace(*s)) s++, xoff++;
            x = 0;
            while (*s && isdigit(*s)) {
                x *= 10;
                x += *s - '0';
                s++, xoff++;
            }
            height = x;
            while (!isspace(*s)) s++, xoff++;
            while (isspace(*s)) s++, xoff++;
//          sscanf(s, "%d", &maxcolor);
            while (!isspace(*s)) s++, xoff++;
            s++, xoff++;

            bi.biWidth = (long)width;
            bi.biHeight = (long)height;
            bi.biClrUsed = 256;
            bf.bfOffBits == xoff;
            _llseek(fh, xoff, SEEK_SET);
        } else {
/* Raw RGB. Guess the size */
            _fstat(fh, &st);
            if (st.st_size / (64 * 4) == (96 * 4 * 3)) {
                bi.biWidth = (long)(96 * 4);
                bi.biHeight = (long)(64 * 4);
            } else if (st.st_size / (64 * 2) == (96 * 2 * 3)) {
                bi.biWidth = (long)(96 * 2);
                bi.biHeight = (long)(64 * 2);
            } else /* if (st.st_size / (64 * 1) == (96 * 1 * 3)) */ {
                bi.biWidth = (long)(96 * 1);
                bi.biHeight = (long)(64 * 1);
            }
            _llseek(fh, 0L, SEEK_SET);
            bf.bfOffBits == 0L;
        }
        bi.biPlanes = 1;
        if (bFakePPM) {
            bi.biBitCount = 8;
            bi.biSizeImage = bi.biWidth *  bi.biHeight;
        } else {
            bi.biBitCount = 24;
            bi.biSizeImage = bi.biWidth *  bi.biHeight * 3;
        }
        bi.biCompression = BI_RGB;

        bi.biXPelsPerMeter = 5000;
        bi.biYPelsPerMeter = 5000;
        bi.biClrImportant = 0;
    }
    nNumColors = DibNumColors (&bi);

    /* Check the nature (BITMAPINFO or BITMAPCORE) of the info. block
     * and extract the field information accordingly. If a BITMAPCOREHEADER,
     * transfer it's field information to a BITMAPINFOHEADER-style block
     */
    switch (size = (int)bi.biSize){
    case sizeof (BITMAPINFOHEADER):
            break;

    case sizeof (BITMAPCOREHEADER):

        bc = *(BITMAPCOREHEADER*)&bi;

        dwWidth   = (DWORD)bc.bcWidth;
        dwHeight  = (DWORD)bc.bcHeight;
        wPlanes   = bc.bcPlanes;
        wBitCount = bc.bcBitCount;

            bi.biSize               = sizeof(BITMAPINFOHEADER);
        bi.biWidth          = dwWidth;
        bi.biHeight         = dwHeight;
        bi.biPlanes         = wPlanes;
        bi.biBitCount       = wBitCount;

            bi.biCompression        = BI_RGB;
            bi.biSizeImage          = 0;
            bi.biXPelsPerMeter      = 0;
            bi.biYPelsPerMeter      = 0;
            bi.biClrUsed            = nNumColors;
            bi.biClrImportant       = nNumColors;

        _llseek (fh, (LONG)sizeof (BITMAPCOREHEADER) - sizeof (BITMAPINFOHEADER), SEEK_CUR);
            break;

    default:
        /* Not a DIB! */
        return NULL;
    }

    /*  Fill in some default values if they are zero */
    if (bi.biSizeImage == 0){
    bi.biSizeImage = WIDTHBYTES ((DWORD)bi.biWidth * bi.biBitCount)
             * bi.biHeight;
    }
    if (bi.biClrUsed == 0)
    bi.biClrUsed = DibNumColors(&bi);

    /* Allocate for the BITMAPINFO structure and the color table. */
    hbi = GlobalAlloc (GHND, (LONG)bi.biSize + nNumColors * sizeof(RGBQUAD));
    if (!hbi)
        return NULL;
    lpbi = (VOID FAR *)GlobalLock (hbi);
    *lpbi = bi;

    /* Get a pointer to the color table */
    pRgb = (RGBQUAD FAR *)((LPSTR)lpbi + bi.biSize);
    if (nNumColors && !(bPPM || bFakePPM)){
    if (size == sizeof(BITMAPCOREHEADER)){
        /* Convert a old color table (3 byte RGBTRIPLEs) to a new
         * color table (4 byte RGBQUADs)
             */
        _lread (fh, (LPSTR)pRgb, nNumColors * sizeof(RGBTRIPLE));

        for (i = nNumColors - 1; i >= 0; i--){
                RGBQUAD rgb;

                rgb.rgbRed      = ((RGBTRIPLE FAR *)pRgb)[i].rgbtRed;
                rgb.rgbBlue     = ((RGBTRIPLE FAR *)pRgb)[i].rgbtBlue;
                rgb.rgbGreen    = ((RGBTRIPLE FAR *)pRgb)[i].rgbtGreen;
                rgb.rgbReserved = (BYTE)0;

                pRgb[i] = rgb;
            }
        }
    else
            _lread(fh,(LPSTR)pRgb,nNumColors * sizeof(RGBQUAD));
    }

    if (bf.bfOffBits != 0L)
        _llseek(fh,off + bf.bfOffBits,SEEK_SET);

    GlobalUnlock(hbi);
    return hbi;
}


/****************************************************************************
 *                                      *
 *  FUNCTION   : DibFromBitmap()                        *
 *                                      *
 *  PURPOSE    : Will create a global memory block in DIB format that       *
 *       represents the Device-dependent bitmap (DDB) passed in.    *
 *                                      *
 *  RETURNS    : A handle to the DIB                        *
 *                                      *
 ****************************************************************************/
HANDLE DibFromBitmap (hbm, biStyle, biBits, hpal)
HBITMAP      hbm;
DWORD        biStyle;
WORD         biBits;
HPALETTE     hpal;
{
    BITMAP               bm;
    BITMAPINFOHEADER     bi;
    BITMAPINFOHEADER FAR *lpbi;
    DWORD                dwLen;
    HANDLE               hdib;
    HANDLE               h;
    HDC                  hdc;

    if (!hbm)
    return NULL;

    if (hpal == NULL)
        hpal = GetStockObject(DEFAULT_PALETTE);

    GetObject(hbm,sizeof(bm),(LPSTR)&bm);

    if (biBits == 0)
    biBits =  bm.bmPlanes * bm.bmBitsPixel;

    bi.biSize               = sizeof(BITMAPINFOHEADER);
    bi.biWidth              = bm.bmWidth;
    bi.biHeight             = bm.bmHeight;
    bi.biPlanes             = 1;
    bi.biBitCount           = biBits;
    bi.biCompression        = biStyle;
    bi.biSizeImage          = 0;
    bi.biXPelsPerMeter      = 0;
    bi.biYPelsPerMeter      = 0;
    bi.biClrUsed            = 0;
    bi.biClrImportant       = 0;

    dwLen  = bi.biSize + PaletteSize(&bi);

    hdc = GetDC(NULL);
    hpal = SelectPalette(hdc,hpal,FALSE);
     RealizePalette(hdc);

    hdib = GlobalAlloc(GHND,dwLen);

    if (!hdib){
    SelectPalette(hdc,hpal,FALSE);
    ReleaseDC(NULL,hdc);
    return NULL;
    }

    lpbi = (VOID FAR *)GlobalLock(hdib);

    *lpbi = bi;

    /*  call GetDIBits with a NULL lpBits param, so it will calculate the
     *  biSizeImage field for us
     */
    GetDIBits(hdc, hbm, 0, (WORD)bi.biHeight,
        NULL, (LPBITMAPINFO)lpbi, DIB_RGB_COLORS);

    bi = *lpbi;
    GlobalUnlock(hdib);

    /* If the driver did not fill in the biSizeImage field, make one up */
    if (bi.biSizeImage == 0){
        bi.biSizeImage = WIDTHBYTES((DWORD)bm.bmWidth * biBits) * bm.bmHeight;

        if (biStyle != BI_RGB)
            bi.biSizeImage = (bi.biSizeImage * 3) / 2;
    }

    /*  realloc the buffer big enough to hold all the bits */
    dwLen = bi.biSize + PaletteSize(&bi) + bi.biSizeImage;
    if (h = GlobalReAlloc(hdib,dwLen,0))
        hdib = h;
    else{
        GlobalFree(hdib);
    hdib = NULL;

    SelectPalette(hdc,hpal,FALSE);
    ReleaseDC(NULL,hdc);
    return hdib;
    }

    /*  call GetDIBits with a NON-NULL lpBits param, and actualy get the
     *  bits this time
     */
    lpbi = (VOID FAR *)GlobalLock(hdib);

    if (GetDIBits( hdc,
           hbm,
           0,
           (WORD)bi.biHeight,
           (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize(lpbi),
           (LPBITMAPINFO)lpbi, DIB_RGB_COLORS) == 0){
     GlobalUnlock(hdib);
     hdib = NULL;
     SelectPalette(hdc,hpal,FALSE);
     ReleaseDC(NULL,hdc);
     return NULL;
    }

    bi = *lpbi;
    GlobalUnlock(hdib);

    SelectPalette(hdc,hpal,FALSE);
    ReleaseDC(NULL,hdc);
    return hdib;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : BitmapFromDib(HANDLE hdib, HPALETTE hpal)          *
 *                                      *
 *  PURPOSE    : Will create a DDB (Device Dependent Bitmap) given a global *
 *       handle to a memory block in CF_DIB format          *
 *                                      *
 *  RETURNS    : A handle to the DDB.                       *
 *                                      *
 ****************************************************************************/
HBITMAP BitmapFromDib (hdib, hpal)
HANDLE     hdib;
HPALETTE   hpal;
{
    LPBITMAPINFOHEADER  lpbi;
    HPALETTE        hpalT;
    HDC         hdc;
    HBITMAP     hbm;

    StartWait();

    if (!hdib)
    return NULL;

    lpbi = (VOID FAR *)GlobalLock(hdib);

    if (!lpbi)
    return NULL;

    hdc = GetDC(NULL);

    if (hpal){
        hpalT = SelectPalette(hdc,hpal,FALSE);
        RealizePalette(hdc);     // GDI Bug...????
    }

    hbm = CreateDIBitmap(hdc,
                (LPBITMAPINFOHEADER)lpbi,
                (LONG)CBM_INIT,
                (LPSTR)lpbi + lpbi->biSize + PaletteSize(lpbi),
                (LPBITMAPINFO)lpbi,
                DIB_RGB_COLORS );

    if (hpal)
        SelectPalette(hdc,hpalT,FALSE);

    ReleaseDC(NULL,hdc);
    GlobalUnlock(hdib);

    EndWait();

    return hbm;
}
/****************************************************************************
 *                                      *
 *  FUNCTION   : DrawBitmap(HDC hdc, int x, int y, HBITMAP hbm, DWORD rop)  *
 *                                      *
 *  PURPOSE    : Draws bitmap <hbm> at the specifed position in DC <hdc>    *
 *                                      *
 *  RETURNS    : Return value of BitBlt()                   *
 *                                      *
 ****************************************************************************/
BOOL DrawBitmap (hdc, x, y, hbm, rop)
HDC    hdc;
int    x, y;
HBITMAP    hbm;
DWORD      rop;
{
    HDC       hdcBits;
    BITMAP    bm;
    HPALETTE  hpalT;
    BOOL      f;

    if (!hdc || !hbm)
        return FALSE;

    hdcBits = CreateCompatibleDC(hdc);
    GetObject(hbm,sizeof(BITMAP),(LPSTR)&bm);
    SelectObject(hdcBits,hbm);
    f = BitBlt(hdc,0,0,bm.bmWidth,bm.bmHeight,hdcBits,0,0,rop);
    DeleteDC(hdcBits);

    return f;
}
/****************************************************************************
 *                                      *
 *  FUNCTION   : DibBlt( HDC hdc,                       *
 *           int x0, int y0,                    *
 *           int dx, int dy,                    *
 *           HANDLE hdib,                       *
 *           int x1, int y1,                    *
 *           LONG rop, int palfmt)              *
 *                                      *
 *  PURPOSE    : Draws a bitmap in CF_DIB format, using SetDIBits to device.*
 *       taking the same parameters as BitBlt().            *
 *                                      *
 *  RETURNS    : TRUE  - if function succeeds.                  *
 *       FALSE - otherwise.                     *
 *                                      *
 ****************************************************************************/

/* MSC 6.0 seems to drop the ball optimizing this function */
#pragma optimize("azegc", off)

BOOL DibBlt (hdc, x0, y0, dx, dy, hdib, x1, y1, rop, palfmt)
HDC    hdc;
int    x0, y0, dx, dy;
HANDLE     hdib;
int    x1, y1;
LONG       rop;
int     palfmt;
{
    LPBITMAPINFOHEADER   lpbi;
    HPALETTE         hp,old;
    unsigned char _huge *pBuf;
    HDC          hdcMem;
    HBITMAP      hbm,hbmT;
    int          ret;
    int x, y, xx, rerr, gerr, berr, e1, e2, e3, e4, rowsize;
    unsigned char   r, g, b, r1, g1, b1;
    DWORD cr;
    int widthFudge = 1;
    extern BOOL b24, b24d, bDoYCC;
    extern int columnBytes;

    if (columnBytes > 3)
        widthFudge = columnBytes / 3;

    if (!hdib || !bDoYCC)
    return PatBlt(hdc,x0,y0,dx,dy,rop);

    lpbi = (VOID FAR *)GlobalLock(hdib);

    if (!lpbi)
    return FALSE;

/*XXX*/
lpbi->biWidth *= (long)widthFudge;

    pBuf = (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize(lpbi);

    if (dx == 0) 
        dx = ((LPBITMAPINFO)lpbi)->bmiHeader.biWidth;
    if (dy == 0) 
        dy = ((LPBITMAPINFO)lpbi)->bmiHeader.biHeight;

/*XXX*/
    /* Set up palette if indicated */
    if (lpbi->biBitCount != 24) {
        int nc = 256;

        if ((nc = lpbi->biClrUsed) == 0) {
// if (lpbi->biBitCount == 8)
                nc = 256;
//          else nc = 16;
        }
        hp = paletteFromDib(((LPBITMAPINFO)lpbi)->bmiColors, nc);
    } else 
        hp = paletteFromDib((RGBQUAD FAR *)0, 256);

    old = SelectPalette(hdc, hp, 0);
    RealizePalette(hdc);
/*XXX*/

{
    extern int zoomNum, zoomDenom;

    if (zoomNum && zoomDenom && zoomNum != zoomDenom) {
        long    tmp;
        int     olddx = dx, olddy = dy;

        tmp = ((long)x0 * (long)zoomNum) / (long)zoomDenom;
        x0 = (int)tmp;
        tmp = ((long)y0 * (long)zoomNum) / (long)zoomDenom;
        y0 = (int)tmp;
        tmp = ((long)dx * (long)zoomNum) / (long)zoomDenom;
        dx = (int)tmp;
        tmp = ((long)dy * (long)zoomNum) / (long)zoomDenom;
        dy = (int)tmp;
        StretchDibBlt(hdc, x0, y0, dx, dy, hdib, x1, y1, olddx, olddy, SRCCOPY);
    } else {
        int nStartScan = 0;

        ret = SetDIBitsToDevice (hdc, x0, y0, dx, dy,
                   x1,y1,
                   nStartScan,
                   dy,
                   pBuf, (LPBITMAPINFO)lpbi,
                   DIB_RGB_COLORS );
    }
}
lpbi->biWidth /= (long)widthFudge;

    GlobalUnlock(hdib);

    if (ret)
        return(TRUE);
    return(FALSE);
}

/*XXX*/
PCDYtoR(unsigned char _huge *ptr, long cnt)
{
}

BOOL BlastYCC(hdc, x0, y0, dx, dy, hdib, x1, y1, rop, palfmt)
HDC    hdc;
int    x0, y0, dx, dy;
HANDLE     hdib;
int    x1, y1;
LONG       rop;
int     palfmt;
{
    LPBITMAPINFOHEADER   lpbi;
    HPALETTE         hp,old;
    unsigned char _huge *pBuf;
    HDC          hdcMem;
    HBITMAP      hbm,hbmT;
    int          ret;
    int x, y, xx, rerr, gerr, berr, e1, e2, e3, e4, rowsize;
    unsigned char   r, g, b, r1, g1, b1;
    DWORD cr;
    long size;
    extern BOOL b24, b24d, bDoYCC;

    if (!hdib || !bDoYCC)
        return PatBlt(hdc,x0,y0,dx,dy,rop);

    lpbi = (VOID FAR *)GlobalLock(hdib);

    if (!lpbi)
        return FALSE;

    size = ((LPBITMAPINFO)lpbi)->bmiHeader.biWidth * 
            (((LPBITMAPINFO)lpbi)->bmiHeader.biHeight - 1L); 
    pBuf = (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize(lpbi);
    PCDYtoR(pBuf, size);

    return(DibBlt(hdc, x0, y0, dx, dy, hdib, x1, y1, rop, palfmt));
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : StretchDibBlt( HDC hdc,                    *
 *              int x, int y,                   *
 *              int dx, int dy,                 *
 *              HANDLE hdib,                    *
 *              int x0, int y0,                 *
 *              int dx0, int dy0,               *
 *              LONG rop)                   *
 *                                      *
 *  PURPOSE    : Draws a bitmap in CF_DIB format, using StretchDIBits()     *
 *       taking the same parameters as StretchBlt().            *
 *                                      *
 *  RETURNS    : TRUE  - if function succeeds.                  *
 *       FALSE - otherwise.                     *
 *                                      *
 ****************************************************************************/
BOOL StretchDibBlt (hdc, x, y, dx, dy, hdib, x0, y0, dx0, dy0, rop)
HDC hdc;
int x, y;
int dx, dy;
HANDLE hdib;
int x0, y0;
int dx0, dy0;
LONG rop;

{
    LPBITMAPINFOHEADER lpbi;
    LPSTR        pBuf;
    BOOL         f;

    if (!hdib)
        return PatBlt(hdc,x,y,dx,dy,rop);

    lpbi = (VOID FAR *)GlobalLock(hdib);

    if (!lpbi)
        return FALSE;

    pBuf = (LPSTR)lpbi + (WORD)lpbi->biSize + PaletteSize(lpbi);

    f = StretchDIBits ( hdc,
            x, y,
            dx, dy,
            x0, y0,
            dx0, dy0,
            pBuf, (LPBITMAPINFO)lpbi,
            DIB_RGB_COLORS,
            rop);

    GlobalUnlock(hdib);
    return f;
}

 /************* PRIVATE ROUTINES TO READ/WRITE MORE THAN 64K ***************/
/****************************************************************************
 *                                      *
 *  FUNCTION   : lread(int fh, VOID FAR *pv, DWORD ul)              *
 *                                      *
 *  PURPOSE    : Reads data in steps of 32k till all the data has been read.*
 *                                      *
 *  RETURNS    : 0 - If read did not proceed correctly.             *
 *       number of bytes read otherwise.                *
 *                                      *
 ****************************************************************************/
DWORD PASCAL lread (fh, pv, ul)
int       fh;
VOID far      *pv;
DWORD         ul;
{
    DWORD     ulT = ul;
    BYTE huge *hp = pv;

    while (ul > (DWORD)MAXREAD) {
    if (_lread(fh, (LPSTR)hp, (WORD)MAXREAD) != MAXREAD)
        return 0;
    ul -= MAXREAD;
    hp += MAXREAD;
    }
    if (_lread(fh, (LPSTR)hp, (WORD)ul) != (WORD)ul)
    return 0;
    return ulT;
}

/****************************************************************************
 *                                      *
 *  FUNCTION   : lwrite(int fh, VOID FAR *pv, DWORD ul)             *
 *                                      *
 *  PURPOSE    : Writes data in steps of 32k till all the data is written.  *
 *                                      *
 *  RETURNS    : 0 - If write did not proceed correctly.            *
 *       number of bytes written otherwise.             *
 *                                      *
 ****************************************************************************/
DWORD PASCAL lwrite (fh, pv, ul)
int      fh;
VOID FAR     *pv;
DWORD        ul;
{
    DWORD     ulT = ul;
    BYTE huge *hp = pv;

    while (ul > MAXREAD) {
    if (_lwrite(fh, (LPSTR)hp, (WORD)MAXREAD) != MAXREAD)
        return 0;
    ul -= MAXREAD;
    hp += MAXREAD;
    }
    if (_lwrite(fh, (LPSTR)hp, (WORD)ul) != (WORD)ul)
    return 0;
    return ulT;
}

HANDLE
CopyDib(HANDLE hOld)
{
    HANDLE          hNew;
    LPBITMAPINFO    lpOld, lpNew;
    LONG            dwLen;
    DWORD _huge     *from, _huge *to;

    if ((lpOld = (LPBITMAPINFO)GlobalLock(hOld)) == 0)
        return(0);

    dwLen = lpOld->bmiHeader.biSize + PaletteSize(&lpOld->bmiHeader) + 
            lpOld->bmiHeader.biSizeImage;

    if ((hNew = GlobalAlloc(GMEM_MOVEABLE, dwLen)) == 0) {
        GlobalUnlock(hOld);
        return(0);
    }
    if ((lpNew = (LPBITMAPINFO)GlobalLock(hNew)) == 0) {
        GlobalUnlock(hOld);
        GlobalUnlock(hNew);
        return(0);
    }

    for (from = (DWORD _huge *)lpOld, to = (DWORD _huge *)lpNew;
         dwLen > 0;
         dwLen -= 4, to++, from++)
            *to = *from;

    GlobalUnlock(hOld);
    GlobalUnlock(hNew);
    return(hNew);
}

HPALETTE hCurPal;
HANDLE
Palettize(HANDLE h)
{
    return(h);
}

/***XXX***XXX***XXX***/


/*
 *  RGBto3 - reduce 24-bit RGB to pseudocolor.
 *  This is a quick method for generating an image that can
 *  be displayed on an 8-bit-deep color monitor, though the
 *  resulting image quality is not as good as that produced
 *  by more time-consuming techniques.
 *
 *  For information on the 3/3/2 standard colormap, see vol. 1,
 *  section 7.6.3 of the O'Reilly Xlib Programming Manual.
 */
RGBto3(y, yPlane, yCol, r, count)
    unsigned char HUGE *y, HUGE *r;
    int yPlane, yCol;
    unsigned long count;
{
    int rv, gv, bv;
    
    while (count--) {
        bv = *(y) & 0xff;
        gv = *(y + yPlane) & 0xff;
        rv = *(y + yPlane + yPlane) & 0xff;
        /* XXX - Maybe we could do something with error */
        *r++ = (rv & 0x0e0) | ((gv >> 3) & 0x01c) | ((bv >> 6) & 0x3);
        y += yCol;
    }
    return (0);
}

BOOL
MakeEmptyDIB(long width, long height, PCDformat fmt,
            HANDLE FAR *lph, PCDRAWDATA FAR *lplpdata)
{
    long                size;
    long                depth;
    HANDLE              h = 0;
    PCDRAWDATA          lpdata;
    LPBITMAPINFOHEADER  lpbi = 0;
    LPBITMAPINFO        lpb = 0;

    switch (fmt) {
    case PCD_PALETTE:
    case PCD_SINGLE:
        depth = 1;
        break;
    default:
        depth = 3;
    }

    size = depth * width * height;
    size += (long)sizeof(BITMAPINFOHEADER);
    size += (256L * (long)sizeof(RGBQUAD));

    if ((h = GlobalAlloc(GMEM_ZEROINIT, size)) == 0)
        goto bad;
    if ((lpbi = (LPBITMAPINFOHEADER)GlobalLock(h)) == 0)
        goto bad;

    lpb = (LPBITMAPINFO)lpbi;

    lpbi->biSize = sizeof(BITMAPINFOHEADER);
    lpbi->biWidth = width;
    lpbi->biHeight = height;
    lpbi->biPlanes = 1;
    lpbi->biBitCount = 8 * depth;
    lpbi->biCompression = BI_RGB;
    lpbi->biSizeImage = depth * width * height;
    lpbi->biClrUsed = 256;
    lpbi->biClrImportant = 256;

    if (fmt == PCD_SINGLE) {
        makeGrayPalette(lpb->bmiColors, 256);
    } else
        make332Palette(lpb->bmiColors);
    lpdata = (PCDRAWDATA)(lpb->bmiColors + 256);

    *lplpdata = lpdata;
    *lph = h;

    return(TRUE);
bad:
    if (h) {
        if (lpbi)
            GlobalUnlock(h);
        GlobalFree(h);
    }
    *lplpdata = 0;
    *lph = 0;
    return(FALSE);
}
