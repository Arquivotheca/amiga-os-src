/*
 *  Photo CD Development Toolkit
 *
 *  lut.c
 *  Lookup table color quantization.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#if 0
	#ifdef  IDENT
	#ident  "@(#)lut.c  1.73 - 92/06/03"
	#endif
#endif

#include <assert.h>
#include <windows.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "quant.h"
#include "pal.h"
#define DEFTABLES   1
#include "ycctab.h"


unsigned    rand(void);
int         randthresh = 1, randdiff = 0;
int         threshnoise = 16;
int         maxfserr = 64;

#define     THRESH(v, t) \
    if (v < 0) { \
        if (v < -t) \
            v = -t; \
    } else { \
        if (v > t) \
            v = t; \
    } 

/*
 * Do error diffusion.
 */
void
xerrdiff(int err, int FAR *vec, unsigned int this, unsigned int next, int one)
{

    int     herr1, herr2;

    herr1 = err >> 1;
    herr2 = err - herr1;
    vec[this + one] += herr1;
    vec[next] += herr2;

/* XXX - rounding err */
#define errdiff(err, vec, this, next, one) \
    vec[this + one] += err; \
    vec[next] += err; 

#define FLOYDSHIFT  1
}

/* Shift |c| right by |s|, AND with mask |m| then OR into |v| */
#define APPLYSHIFTANDMASK(v, c, s, m) \
    if ((s) < 0) \
        v |= ((c) << (-(s))) & (m); \
    else if ((s) > 0) \
        v |= ((c) >> (s)) & (m); \
    else \
        v |= (c) & (m);

/*
 * Given three color components, return a palette index.
 *
 * Apply shift and mask to each component to get an index
 * into the PCDpalette's LUT, which in turn gives the
 * palette index.
 */
unsigned char 
LUTquant(PCDpalettePtr p, unsigned char r, unsigned char g, unsigned char b)
{
    long lutix;

    assert(p);
    assert(p->pal);
    assert(p->lut);
    lutix = 0;

    APPLYSHIFTANDMASK(lutix, r, p->rshift, p->rmask);
    APPLYSHIFTANDMASK(lutix, g, p->gshift, p->gmask);
    APPLYSHIFTANDMASK(lutix, b, p->bshift, p->bmask);
    assert(lutix >= 0);
    return(p->lut[lutix]);
}

/*
 * Does PCD_PALETTE color reduction with/without error diffusion.
 * This version *does not* take subsampled chroma.
 */
void FAR PASCAL
doPalette(PCDpalettePtr pp, PCDRAWDATA y, PCDRAWDATA c1, PCDRAWDATA c2, 
    int yCol, PCDRAWDATA p, long rCol,
    int FAR *vec,
    unsigned int thisr, unsigned int thisg, unsigned int thisb, 
    unsigned int nextr, unsigned int nextg, unsigned int nextb, 
    int one, unsigned long count,
    BOOL inputIsYCC)
{
    int rv, gv, bv;
    int rerr, gerr, berr;
    unsigned char r, g, b;
    RGBQUAD FAR *pal = pp->pal;
    BOOL doFloyd = pp->errdiff, 
         RGBquant = pp->RGBquant,
         quick332 = pp->quick332;


    while (count--) {
        if (inputIsYCC && RGBquant) {
            rv = RFROMYCC(*y, *c1, *c2);
            gv = GFROMYCC(*y, *c1, *c2);
            bv = BFROMYCC(*y, *c1, *c2);
/* 			use lut instead; (3-11-93)
            clamp(rv);
            clamp(gv);
            clamp(bv);

            r = (unsigned char)rv;
            g = (unsigned char)gv;
            b = (unsigned char)bv;
*/
			r = MAPTHROUGHLUT(rv);
			g = MAPTHROUGHLUT(gv);
			b = MAPTHROUGHLUT(bv);
        } else {
            r = *y;
            g = *c1; 
            b = *c2;
        }

        if (doFloyd) {
            rv = r + (vec[thisr] >> FLOYDSHIFT); vec[thisr] = 0;
            gv = g + (vec[thisg] >> FLOYDSHIFT); vec[thisg] = 0;
            bv = b + (vec[thisb] >> FLOYDSHIFT); vec[thisb] = 0;
            clamp(rv);
            clamp(gv);
            clamp(bv);
            r = rv;
            g = gv;
            b = bv;
        }
        if (quick332)
            *p = (r & 0xe0) | ((g >> 3) & 0x1c) | ((b >> 6) & 0x3);
        else
            *p = (unsigned char)LUTquant(pp, r, g, b);

        if (doFloyd) {
            RGBQUAD FAR *pv = pal + *p;

            rerr = rv - pv->rgbRed;
            gerr = gv - pv->rgbGreen;
            berr = bv - pv->rgbBlue;
        
            errdiff(rerr, vec, thisr, nextr, one);
            errdiff(gerr, vec, thisg, nextg, one);
            errdiff(berr, vec, thisb, nextb, one);

            thisr += one; thisg += one; thisb += one;
            nextr += one; nextg += one; nextb += one;
        }

        p += rCol;
        y += one * yCol;
        c1 += one * yCol;
        c2 += one * yCol;
    }
}

/*
 * Does PCD_PALETTE color reduction with/without error diffusion.
 * This version takes 2X subsampled chroma.
 */
void 
doXPalette(PCDpalettePtr pp, 
    unsigned char FAR *y, unsigned char FAR *c1, unsigned char FAR *c2, 
    int yCol, PCDRAWDATA p, long rCol,
    int FAR *vec,
    unsigned int thisr, unsigned int thisg, unsigned int thisb, 
    unsigned int nextr, unsigned int nextg, unsigned int nextb, 
    int one, unsigned long count,
    BOOL inputIsYCC,
    BOOL replicateLast)
{
    int rv, gv, bv;
    int rerr, gerr, berr;
    unsigned char r, g, b, yv, c1v, c2v;
    unsigned short accum;
    RGBQUAD FAR *pal = pp->pal;
    BOOL doFloyd = pp->errdiff, 
         RGBquant = pp->RGBquant, 
         quick332 = pp->quick332,
         odd = FALSE;

    if (((unsigned long)y) & 1)
        odd = TRUE;

    c1v = *c1;
    c2v = *c2;
    while (count--) {
        if (odd && (count || !replicateLast)) {
            c1 += one * yCol;
            c2 += one * yCol;
            accum = (c1v + *c1 + 1) >> 1;
            c1v = (unsigned char)accum;
            accum = (c2v + *c2 + 1) >> 1;
            c2v = (unsigned char)accum;
        } else {
            c1v = *c1;
            c2v = *c2;
        }
        if (inputIsYCC && RGBquant) {
            yv = *y;
            rv = RFROMYCC(yv, c1v, c2v);
            gv = GFROMYCC(yv, c1v, c2v);
            bv = BFROMYCC(yv, c1v, c2v);
/*			use lut instead; (3-11-93)
            clamp(rv);
            clamp(gv);
            clamp(bv);

            r = (unsigned char)rv;
            g = (unsigned char)gv;
            b = (unsigned char)bv;
*/
			r = MAPTHROUGHLUT(rv);
			g = MAPTHROUGHLUT(gv);
			b = MAPTHROUGHLUT(bv);

        } else {
            r = *y;
            g = c1v; 
            b = c2v;
        }

        if (doFloyd) {
            rv = r + (vec[thisr] >> FLOYDSHIFT); vec[thisr] = 0;
            gv = g + (vec[thisg] >> FLOYDSHIFT); vec[thisg] = 0;
            bv = b + (vec[thisb] >> FLOYDSHIFT); vec[thisb] = 0;
            clamp(rv);
            clamp(gv);
            clamp(bv);
            r = rv;
            g = gv;
            b = bv;
        }
        if (quick332)
            *p = (r & 0xe0) | ((g >> 3) & 0x1c) | ((b >> 6) & 0x3);
        else
            *p = (unsigned char)LUTquant(pp, r, g, b);
        if (doFloyd) {
            RGBQUAD FAR *pv = pal + *p;

            rerr = rv - pv->rgbRed;
            gerr = gv - pv->rgbGreen;
            berr = bv - pv->rgbBlue;
        
            errdiff(rerr, vec, thisr, nextr, one);
            errdiff(gerr, vec, thisg, nextg, one);
            errdiff(berr, vec, thisb, nextb, one);

            thisr += one; thisg += one; thisb += one;
            nextr += one; nextg += one; nextb += one;
        }

        p += rCol;
        y += one * yCol;
        odd = !odd;
    }
}
