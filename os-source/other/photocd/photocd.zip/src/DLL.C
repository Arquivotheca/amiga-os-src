/*
 *	Photo CD Development Toolkit
 *
 *	dll.c
 *	DLL basics.
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)dll.c	1.101 - 92/06/03"
#endif
#include <windows.h>


int FAR PASCAL LibMain(HANDLE hInstance, WORD wDataSeg, 
						WORD cbHeapSize, LPSTR lpszCmdLine)
{
	if (cbHeapSize)
		UnlockData(0);

	return(1);
}


int FAR PASCAL WEP (int nParam)
{
	return(1);
}
