#include <windows.h>
#include <ctype.h>
#include <assert.h>
#include "pcdlib.h"
#include "pcdpriv.h"

WORD 
DibNumColors (LPBITMAPINFOHEADER lpbi)
{
	if (lpbi->biClrUsed != 0)
		return((WORD)lpbi->biClrUsed);

    switch (lpbi->biBitCount) {
	case 1:
		return(2);
	case 4:
		return(16);
	case 8:
		return(256);
	default:
		return(0);
    }
}

WORD PaletteSize (LPBITMAPINFOHEADER lpbi)
{
    WORD	       NumColors;

    NumColors = DibNumColors(lpbi);
	return(NumColors * sizeof(RGBQUAD));
}

WORD
FAR PASCAL
getHeaderSize(LPBITMAPINFOHEADER lpb)
{
	return(sizeof(BITMAPFILEHEADER) + lpb->biSize + PaletteSize(lpb));
}

WORD
FAR PASCAL
getHeader(LPBITMAPINFOHEADER lpb, LPSTR lpOut)
{
	LPSTR lpIn;
	WORD bmiSize, i;
    LPBITMAPFILEHEADER lpFhdr = (LPBITMAPFILEHEADER)lpOut;

	bmiSize = lpb->biSize + PaletteSize(lpb);

    lpFhdr->bfType = 0x4d42;
    lpFhdr->bfSize = sizeof(BITMAPFILEHEADER) + bmiSize + lpb->biSizeImage ;
    lpFhdr->bfReserved1 = 0;
    lpFhdr->bfReserved2 = 0;
    lpFhdr->bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + bmiSize;

	lpOut += sizeof(BITMAPFILEHEADER);
	lpIn = (LPSTR)lpb; 
	i = 0; 
	while (i++ < bmiSize)
		*lpOut++ = *lpIn++;
	return(bmiSize + sizeof(BITMAPFILEHEADER));
}

WORD
FAR PASCAL
convertImageBytes(LPBITMAPINFOHEADER lpb, LPSTR lpIn, LPSTR lpOut, WORD bufsize)
{
	WORD	i;

	for (i = 0; i < bufsize; i++)
		*lpOut++ = *lpIn++;
	return(bufsize);
}

WORD
FAR PASCAL
getFooterSize(LPBITMAPINFOHEADER lpb)
{
	return(0);
}

WORD
FAR PASCAL
getFooter(LPBITMAPINFOHEADER lpb, LPSTR lpBuf)
{
	return(0);
}
