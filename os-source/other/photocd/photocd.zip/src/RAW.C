/*
 *	Photo CD Development Toolkit
 *
 *	raw.c
 *  Low-level YCC retrieval functions
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)raw.c	1.65 - 92/06/03"
#endif
#include <windows.h>
#include <assert.h>
#include <string.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "pcdovw.h"
#include "util.h"
#include "raw.h"
#include "interp.h"

/*XXX*/
#define	PCD(X)	pcd->X
#define	PCDR(X)	pcdr->X

#define	BUFF_OFF(x)	(short)((x) - PCDR(buf))

/*
 * Set up for retrieval.
 */

/* MSC 6.0 seems to drop the ball optimizing this function */
#pragma	optimize("azegc", off)

PCDrawYCCPtr
openRawYCC(PCDioStatePtr io, PCDresolution step,
			PCDformat format, short version, BOOL ipac)
{
	PCDrawYCCPtr	pcdr;
	unsigned short	bufsize;

	assert(step >= PCD_BASE_OVER_64 && step <= PCD_16BASE);

	if ((pcdr = (PCDrawYCCPtr)PCDmalloc(sizeof(PCDrawYCCRec))) == 0)
		return(0);
	if (step == PCD_BASE_OVER_64)
		bufsize = rowsiz(PCD_BASE_OVER_16);
	else
		bufsize = rowsiz(step);

	PCDR(interpChroma) = TRUE;
	if (step > PCD_BASE) {
		PCDR(smallthumb) = FALSE;
		PCDR(hires) = TRUE;
		PCDR(colsize) = colsiz(PCD_BASE);
		step = PCD_BASE;
		PCDR(linelen) = rowsiz(step);
		PCDR(interpChroma) = FALSE;
	} else {
/*
		if (!PCDR(smallthumb) && format == PCD_PALETTE)
			PCDR(interpChroma) = FALSE;
*/
		PCDR(hires) = FALSE;
		if (step == PCD_BASE_OVER_64) {
			PCDR(smallthumb) = TRUE;
			PCDR(linelen) = rowsiz(PCD_BASE_OVER_16);
			PCDR(colsize) = colsiz(PCD_BASE_OVER_16);
		} else {
			PCDR(smallthumb) = FALSE;
			PCDR(linelen) = rowsiz(step);
			PCDR(colsize) = colsiz(step);
		}
	}

	if ((PCDR(buf) = PCDmalloc(8L * PCDR(linelen))) == 0) {
		goto bad;
	}
	PCDR(y[0])  = PCDR(buf) + (0 * PCDR(linelen));
	PCDR(y[1])  = PCDR(buf) + (1 * PCDR(linelen));
	PCDR(c1[0]) = PCDR(buf) + (2 * PCDR(linelen));
	PCDR(c2[0]) = PCDR(c1[0]) + (PCDR(linelen) / 2);
	PCDR(y[2])  = PCDR(buf) + (3 * PCDR(linelen));
	PCDR(y[3])  = PCDR(buf) + (4 * PCDR(linelen));
	PCDR(c1[2]) = PCDR(buf) + (5 * PCDR(linelen));
	PCDR(c2[2]) = PCDR(c1[2]) + (PCDR(linelen) / 2);
	if (PCDR(interpChroma)) {
		PCDR(c1[1]) = PCDR(buf) + (6 * PCDR(linelen));
		PCDR(c2[1]) = PCDR(c1[1]) + (PCDR(linelen) / 2);
		PCDR(c1[3]) = PCDR(buf) + (7 * PCDR(linelen));
		PCDR(c2[3]) = PCDR(c1[3]) + (PCDR(linelen) / 2);
	} else {
		PCDR(c1[1]) = PCDR(c1[0]);
		PCDR(c2[1]) = PCDR(c2[0]);
		PCDR(c1[3]) = PCDR(c1[2]);
		PCDR(c2[3]) = PCDR(c2[2]);
	}
	if (version == PCD_OLD_VERSION) {
		unsigned char FAR *tmp;
#define PTRSWAP(a, b) tmp = a; a = b; b = tmp
		PTRSWAP(PCDR(c1[0]), PCDR(c2[0]));
		PTRSWAP(PCDR(c1[1]), PCDR(c2[1]));
		PTRSWAP(PCDR(c1[2]), PCDR(c2[2]));
		PTRSWAP(PCDR(c1[3]), PCDR(c2[3]));
	}
	PCDR(ipac) = ipac;
	PCDR(step) = step;
	PCDR(format) = format;
	PCDR(first) = TRUE;
	PCDR(io) = io;
	PCDR(version) = version;
	PCDR(smallthumb) = (step == PCD_BASE_OVER_64);

	PCDR(lastline) = -1;
	return(pcdr);

bad:
	if (PCDR(buf))
		PCDfree(PCDR(buf));
	if (pcdr)
		PCDfree((PCDRAWDATA)pcdr);
}

#pragma	optimize("azegc", on)

void
closeRawYCC(PCDrawYCCPtr pcdr)
{
	assert(pcdr);
	assert(PCDR(buf));
	if (PCDR(buf))
		PCDfree(PCDR(buf));
	if (pcdr)
		PCDfree((PCDRAWDATA)pcdr);
}

/*
 * Read a Y Y C C block. 
 */

/* static */
PCDstatus
getChunk(PCDrawYCCPtr pcdr, short chunkNum)
{
	unsigned char HUGE *ybuf, HUGE *c1buf, HUGE *c2buf;
	PCDstatus	rv = pcdSuccess;
	long		ysize, csize, coff;
	BOOL		single;

	assert(pcdr);
	assert(chunkNum == 0 || chunkNum == 1);

	single = (PCDR(format) == PCD_SINGLE);

	if (chunkNum == 0) {
		ybuf  = PCDR(y[0]);
		c1buf = PCDR(c1[0]);
		c2buf = PCDR(c2[0]);
	} else {
		ybuf  = PCDR(y[2]);
		c1buf = PCDR(c1[2]);
		c2buf = PCDR(c2[2]);
	}
	ysize = 3L * PCDR(linelen);
	if (!single) {
		csize = PCDR(linelen) / 2L;
/*XXX->*/
/*
		if (PCDR(hires) || PCDR(smallthumb) || !PCDR(interpChroma))
			coff = 0;
		else
			coff = csize;
*/
		coff = 0;

if (PCDR(version) == PCD_OLD_VERSION) {
if ((rv = PCDreadSome(PCDR(io), ybuf, ysize)) != pcdSuccess) return(rv);
#if 0
if ((rv = PCDreadSome(PCDR(io), c2buf+coff, csize))!=pcdSuccess) return(rv);
if ((rv = PCDreadSome(PCDR(io), c1buf+coff, csize))!=pcdSuccess) return(rv);
#endif
} else {
		if ((rv = PCDreadSome(PCDR(io), ybuf, ysize)) != pcdSuccess)
			return(rv);
#if 0
		if ((rv = PCDreadSome(PCDR(io), c1buf + coff, csize)) != pcdSuccess)
			return(rv);
		if ((rv = PCDreadSome(PCDR(io), c2buf + coff, csize)) != pcdSuccess)
			return(rv);
#endif
}
/*XXX->*/
#if 0
		if (!PCDR(hires) && !PCDR(smallthumb) && PCDR(interpChroma)) {
			expandchroma(c1buf, PCDR(linelen));
			expandchroma(c2buf, PCDR(linelen));
		} else {
		c1buf[PCDR(linelen) / 2] = c1buf[(PCDR(linelen) / 2) - 1];
		c2buf[PCDR(linelen) / 2] = c2buf[(PCDR(linelen) / 2) - 1];
#endif
	} else {
		if ((rv = PCDreadSome(PCDR(io), ybuf, ysize)) != pcdSuccess)
			return(rv);
#if 0
		if ((rv = PCDsetMark(PCDR(io), PCDR(linelen), 1)) != pcdSuccess)
			return(rv);
#endif
	}
	if (PCDR(smallthumb))
		decimate(ybuf, ysize);
	return(rv);
}

/*
 * When processing the last line of the image, a request
 * will be made for the last + 1th line: replicate the
 * last line.
 */

void
doLastLine(PCDrawYCCPtr pcdr)
{
	if (PCDR(smallthumb)) {
		_fmemcpy(PCDR(y[0]),  PCDR(y[2]),  PCDR(linelen));
		if (PCDR(format) == PCD_SINGLE)
			return;
		_fmemcpy(PCDR(c1[0]), PCDR(c1[2]), PCDR(linelen) / 2);
		_fmemcpy(PCDR(c2[0]), PCDR(c2[2]), PCDR(linelen) / 2);
	} else {
		_fmemcpy(PCDR(y[0]),  PCDR(y[3]),  PCDR(linelen));
		if (PCDR(format) == PCD_SINGLE)
			return;
		_fmemcpy(PCDR(c1[0]), PCDR(c1[3]), PCDR(linelen) / 2);
		_fmemcpy(PCDR(c2[0]), PCDR(c2[3]), PCDR(linelen) / 2);
	}
}

/*
 * Get a line of YCC. Reads a chunk from the disc if need be.
 */
unsigned char FAR *
getRawLine(PCDrawYCCPtr pcdr, short line, PCDcomponent c)
{
	long seekpos;
	short syndrome;
	short chromaLen;
	BOOL single;

	assert(pcdr);
	assert(c == Y || c == C1 || c == C2);

	single = ((PCDR(format)) == PCD_SINGLE);

	if (PCDR(smallthumb))
		line *= 2;
	/* Make sure line is reasonable */
	if (line < 0)
		return(0);
	if (line >= PCDR(colsize))
		return(0);
	syndrome = line % 4;

	if (PCDR(first)) {
		/*
		 *	Determine initial seek offset.
		 */
		if (PCDR(ipac)) {
			switch (PCDR(step)) {
			case PCD_BASE_OVER_16:
				seekpos = PCDS_TV16;
				break;
			case PCD_BASE_OVER_4:
				seekpos = PCDS_TV4;
				break;
			case PCD_BASE:
				seekpos = PCDS_TV;
				break;
			default:
				assert(0 == 1);
			}
/* XXX */
if (PCDR(version) == PCD_OLD_VERSION) seekpos -= stob(1);

			seekpos += (((long)line) >> 1) * (long)PCDR(linelen) * 3L;
		} else {
			seekpos = PCDOS_IMG(PCDR(imgno));
			seekpos += (((long)line) >> 1) * (long)rowsiz(PCD_BASE_OVER_16)*3L;
		}
		PCDsetMark(PCDR(io), seekpos, 0);
		switch (syndrome) {
		case 0:
		case 1:
			if (getChunk(pcdr, 0) != pcdSuccess)
				return(0);
			break;
		case 2:
		case 3:
			if (getChunk(pcdr, 1) != pcdSuccess)
				return(0);
			break;
		}
		PCDR(first) = FALSE;
	}
	if (PCDR(lastline) < line) {
		switch(syndrome) {
		case 0:
			if (!PCDR(smallthumb))
				break;
		case 1:
			if (getChunk(pcdr, 1) != pcdSuccess)
				return(0);
			if (!single && !PCDR(smallthumb) && PCDR(interpChroma)) {
				chromaLen = (PCDR(linelen) / 2);
			   	
				foldchroma(PCDR(buf), BUFF_OFF(PCDR(c1[0])), 
							BUFF_OFF(PCDR(c1[2])), 
							BUFF_OFF(PCDR(c1[1])), chromaLen);
				foldchroma(PCDR(buf), BUFF_OFF(PCDR(c2[0])), 
							BUFF_OFF(PCDR(c2[2])), 
							BUFF_OFF(PCDR(c2[1])), chromaLen);
			  
			}
			break;
		case 2:
			if (!PCDR(smallthumb))
				break;
			else if (line + 2 >= PCDR(colsize)) {
				doLastLine(pcdr);
				break;
			}
		/*FALLTHROUGH*/
		case 3:
			if (line + 1 >= PCDR(colsize))
				doLastLine(pcdr);
			else {
				if (getChunk(pcdr, 0) != pcdSuccess)
					return(0);
				if (!single && !PCDR(smallthumb) && PCDR(interpChroma)) {
					chromaLen = (PCDR(linelen) / 2);
				   
					foldchroma(PCDR(buf), BUFF_OFF(PCDR(c1[0])), 
								BUFF_OFF(PCDR(c1[2])), 
								BUFF_OFF(PCDR(c1[3])), chromaLen);
					foldchroma(PCDR(buf), BUFF_OFF(PCDR(c2[0])), 
								BUFF_OFF(PCDR(c2[2])), 
								BUFF_OFF(PCDR(c2[3])), chromaLen);
					
				}
			}
			break;
		}
	}
	PCDR(lastline) = line;
	switch(c) {
	case Y:
		return(PCDR(y[syndrome]));
	case C1:
		return(PCDR(c1[syndrome]));
	case C2:
		return(PCDR(c2[syndrome]));
	}
/*XXX - "cannot happen"*/
	assert(99 == 100);
	return(0);
}

void
setOviewImgNo(PCDrawYCCPtr pcdr, short imgNo)
{
	assert(pcdr);
	assert(!pcdr->ipac);

	pcdr->imgno = imgNo;
}
