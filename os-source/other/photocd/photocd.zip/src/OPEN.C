/*
 *  Photo CD Development Toolkit
 *
 *  open.c
 *  Open, close, and access methods for variables in a
 *  PCDphotoRec.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
/* LINTLIBRARY */
#ifdef  IDENT
#ident  "@(#)open.c 1.122 - 92/06/03"
#endif
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <windows.h>
#include <string.h>
#include <direct.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "pcdovw.h"
#include "RectCalc.h"
#include "quant.h"
#include "util.h"



/* external version code */
#define PCD_MAJOR_RELEASE   1
#define PCD_MINOR_RELEASE   40

/* internal version code - added for version 1.36 */
static unsigned char CopyrightString[] =
					 "\251 Copyright 1991, 1992, Eastman Kodak Company.";
/*	Internal version number - Change this string for every version of the
 *	toolkit that goes outside of the development group.
 */
static unsigned char InternalVersionString[] = "PCDTK v1.40fc1";

/*	Additional strings that indicate what options a version of the toolkit is
 *	compiled with:
 */
#ifdef ENABLE_CATALOG_CALLS
static unsigned char CatString[] = " cat";
#endif
#ifdef ALLOW_V4_DISKS
static unsigned char V4okString[] = " v4ok";
#endif


#ifdef  NDEBUG
#define STATIC  static
#else
#define STATIC
#endif


#ifdef  ENHANCED_COMPAT
/* XXX - compatibility flag: if TRUE, allow old (<0.4) images to be opened */
BOOL    doCompat = FALSE;
#else
#define doCompat    FALSE
#endif


/**
 **	return the internal version number of the toolkit as a "C" character string
 **
 **	Note: reference to CopyrightString is so that the compiler/linker will
 **		  not leave it out due to being unreferenced!
 **/

PCDstatus FAR PASCAL 
PCDgetInternalVersion(unsigned char FAR *theBuff)  
{
	register unsigned char FAR *cp1, FAR *cp2;

	if (theBuff == NULL)
		return(pcdBadParam);
	*theBuff = CopyrightString[0];
	for (cp1 = theBuff, cp2 = InternalVersionString; *cp2; )
		*cp1++ = *cp2++;
#ifdef ENABLE_CATALOG_CALLS
	for (cp2 = CatString; *cp2; )
		*cp1++ = *cp2++;
#endif
#ifdef ALLOW_V4_DISKS
	for (cp2 = V4okString; *cp2; )
		*cp1++ = *cp2++;
#endif
	*cp1 = '\0';
	return (pcdSuccess);
}


/* Forward declarations */
PCDstatus readImageInfo(PCDphotoPtr pcd);

struct _stat sbuf;

/*
 *  Open an Image Pac for I/O, allocate and fill the
 *  structure pointed to by PCDphotoPtr.
 */
PCDstatus FAR PASCAL PCDopen(path, pcdptr)	  
    LPSTR path;
    PCDphotoHdl FAR *pcdptr;
{
    OFSTRUCT of;
    int fd;
    PCDstatus err;
    PCDphotoPtr pcd;

    if ((fd = OpenFile(path, &of, OF_READ)) < 0) {
        if (!errno) 
            err = ENOENT;
          else
            err = errno;
        if (pcdptr)
            *pcdptr = (PCDphotoHdl) NULL;
        return err;
    }
    if ((err = PCDrefOpen (fd, pcdptr)) != pcdSuccess) /* create pcd struct */
        {
        (void) close(fd);
        return err;
        }
    GetPhotoPtr (*pcdptr, pcd);  
    pcd->iostate.of = of;
    pcd->iostate.flags &= ~(PCD_IO_LEAVE_OPEN); /* we get to close */
    pcd->iostate.flags |= PCD_IO_USE_BUF;       /* use pre-buffer */                                                                                                                                                     
    return pcdSuccess;
} /* end PCDopen */


PCDstatus FAR PASCAL PCDrefOpen(fd, pcdptr)
    int fd;
    PCDphotoHdl FAR *pcdptr;
{
    PCDstatus err = pcdSuccess;
    PCDphotoPtr pcd;
    unsigned char hdrbuf[20];
    unsigned char FAR *hdr = hdrbuf;
    unsigned char ipeclaimed, rotation, maxstep; 
    unsigned char bytes4tv[2], bytes16tv[2], bytesipe[2];
    short end4tv, end16tv, endipe;
    HANDLE hpcd;

    paramck(pcdptr != 0);
    if ((hpcd = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
                            sizeof(PCDphotoRec))) == 0) {
        err = ENOMEM;
        goto botch;
    }
    if ((pcd = (PCDphotoPtr)GlobalLock(hpcd)) == PCDNULL) {
        GlobalFree(hpcd);
        err = ENOMEM;
        goto botch;
    }
    mkphoto(pcd); /* Mark with magic number */
    pcd->hpcd = hpcd;
    pcd->iostate.fd = fd;
    pcd->iostate.throwInError = FALSE;
    if (_fstat(fd, &sbuf) != 0) {
        err = errno;
        goto botch;
    }
    pcd->iostate.filesize = sbuf.st_size;
    
    /* assume user must close file - reset in PCDopen if we opened file */
    pcd->iostate.flags = (PCD_IO_IS_OPEN | PCD_IO_LEAVE_OPEN);
    getVolInfo(&pcd->iostate); /* initialize vol ID info */
	pcd->iostate.hBuff = (HANDLE) NULL; /* avoid pain */
    /*
     *  Setup default state for image access
     *  Resolution = BASE
     *  Format = RGB
     *  Planar configuration = interleaved
     */
    pcd->step = PCD_BASE;
    pcd->format = PCD_RGB;
    pcd->planeBytes = 1;
    pcd->columnBytes = 3;

    /*
     * Get IPI
     */
    if (readImageInfo(pcd) != pcdSuccess) {
        if (!doCompat) {
            err = pcdBadFmt;
            goto botch;
        }
    } else {
        PCDpacInfoPtr lpCachedInfo = 0;

        if (!pcd->pacInfo || 
            (lpCachedInfo = (PCDpacInfoPtr)GlobalLock(pcd->pacInfo)) == 0) {
            err = pcdBadFmt;
            goto botch;
        }
        /* Double check specification version */
        pcd->specVersLo = lpCachedInfo->version & 0xff;
        pcd->specVersHi = (lpCachedInfo->version >> 8) & 0xff;
        GlobalUnlock(pcd->pacInfo);
		if (pcd->specVersHi < SPEC_MAJOR_VERS ||
			(pcd->specVersHi == SPEC_MAJOR_VERS && pcd->specVersLo < SPEC_MINOR_VERS) ) {
	            err = pcdBadFmt;
    	        goto botch;
        }
    }
    /*
     *  Read in Image Pac Header.
     *  Would be nice just to read this into a structure,
     *  but this won't work because of alignment.
     */

    PCDsetMark(&pcd->iostate, 0, 0);
    if (read(pcd->iostate.fd, hdr, 20) != 20) {
/*XXX err = pcdIOerr; */
        goto botch1;
    }

#ifdef  ENHANCED_COMPAT

    /*\
     *      This section of code is for ENHANCED_COMPAT
     *      The section of code that follows is when ENHANCED_COMPAT is not defined
     *      The original source had the #ifdef's intermixed - made for difficult reading
     *      (Barry Kaplan Sep 1992)
    \*/
    
    /* XXX - Newer discs have an IPA, whose
    * first few bytes tend to be 0xFF's.
    * Use this as a clue to determine 
    * how to interpret the header info.
    */
    if ((hdr[11] & 0xb) == 0xb) 
    {
        long    seekloc = stob(1) + 1536;

        pcd->version = PCD_NEW_VERSION;
        _llseek(pcd->iostate.fd, seekloc, 0);
        read(pcd->iostate.fd, hdr, 20);

        pcd->imgno = hdr[1] | (hdr[0] << 8);
        hdr += 2;

        /* XXX - Assume newest disc (Aug 30, 1991 spec). If
        * maxstep != 16BASE, or either hi-res end ptrs is 0, 
        * or IPE appears present and IPE end ptr is 0,
        * guess this is the previous version.
        */

        if ((hdr[0] & 0xc) != 0x8 ||
                (!hdr[1] && !hdr[2]) || (!hdr[3] && !hdr[4]) ||
                ((hdr[0] & 0x10) == 0x10 && !hdr[5] && !hdr[6]))
            hdr -= 2;

        maxstep = hdr[0] & 0xc;
        rotation = hdr[0] & 0x3;
        ipeclaimed = hdr[0] & 0x10;
        bytes4tv[0] = hdr[1];
        bytes4tv[1] = hdr[2];
        bytes16tv[0] = hdr[3];
        bytes16tv[1] = hdr[4];
        bytesipe[0] = hdr[5];
        bytesipe[1] = hdr[6];
    } 
    else {
        pcd->version = PCD_OLD_VERSION;
        rotation = hdr[11] & 0x3;
        maxstep = hdr[11] & 0xc;
        ipeclaimed = hdr[11] & 0x10;
        bytes4tv[0] = hdr[12];
        bytes4tv[1] = hdr[13];
        bytes16tv[0] = hdr[14];
        bytes16tv[1] = hdr[15];
        bytesipe[0] = hdr[16];
        bytesipe[1] = hdr[17];
    }

#else       /* end of ENHANCED_COMPAT defined - start of ENHANCED_COMPAT not defined */
    
    {
        long    seekloc = stob(1) + 1536;

        pcd->version = PCD_NEW_VERSION;
        _llseek(pcd->iostate.fd, seekloc, 0);
        read(pcd->iostate.fd, hdr, 20);

        pcd->imgno = hdr[1] | (hdr[0] << 8);
        hdr += 2;
        maxstep = hdr[0] & 0xc;
        rotation = hdr[0] & 0x3;
        ipeclaimed = hdr[0] & 0x10;
        bytes4tv[0] = hdr[1];
        bytes4tv[1] = hdr[2];
        bytes16tv[0] = hdr[3];
        bytes16tv[1] = hdr[4];
        bytesipe[0] = hdr[5];
        bytesipe[1] = hdr[6];
    }
     
#endif /* ENHANCED_COMPAT */
    
   switch (rotation) {
    case 0:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_0);
        break;
    case 1:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_90);
        break;
    case 2:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_180);
        break;
    case 3:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_270);
        break;
    }
    switch (maxstep) {
    case 0x0:
        pcd->maxstep = PCD_BASE;
        break;
    case 0x4:
        pcd->maxstep = PCD_4BASE;
        break;
    case 0x8:
        pcd->maxstep = PCD_16BASE;
        break;
    default:
        err = pcdBadFmt;
        goto botch;
    }

    /*
     *  Seek pointers to high-resolution images.
     *  Image Pac seek pointers are sector offsets
     *  to the end of image data; we use byte offsets
     *  to the beginning of the data (more useful).
     */
    end4tv = (bytes4tv[0] << 8) | bytes4tv[1];
    end16tv = (bytes16tv[0] << 8) | bytes16tv[1];
    endipe = (bytesipe[0] << 8) | bytesipe[1];
    
    pcd->pos4tv = end4tv ? PCDS_4TV : 0L;
    pcd->pos16tv = end16tv ? stob(end4tv) : 0L; /* Byte offset to 16BASE ICA */
    if (endipe) {
        if (end16tv)
            pcd->posipe = stob(end16tv);
        else if (end4tv)
            pcd->posipe = stob(end4tv);
        else
            pcd->posipe = PCDS_4TVICA;
    } else
        pcd->posipe = 0L;
#ifndef NDEBUG
    if (pcd->maxstep == PCD_BASE)
        assert(!pcd->pos4tv && !pcd->pos16tv);
    if (pcd->maxstep == PCD_4BASE)
        assert(pcd->pos4tv && !pcd->pos16tv);
    if (pcd->maxstep == PCD_16BASE)
        assert(pcd->pos4tv && pcd->pos16tv);
    if (ipeclaimed)
        assert(pcd->posipe);
#endif
    pcd->huffid4 = (int) (hdr[18]);

    if ((err = PCDcloseFile(&pcd->iostate)) != pcdSuccess)
        goto botch;

    /*
     *  Miscellaneous initialization.
     */
    pcd->bounds.top = 0;
    pcd->bounds.left = 0;
    pcd->bounds.right = rowsiz(pcd->step);
    pcd->bounds.bottom = colsiz(pcd->step);

    pcd->check = (FARPROC) NULL;
    pcd->abort = (FARPROC) NULL;
    pcd->cDenominator = 0;

    pcd->palette = 0;

    if ((err = PCDcreatePalette((unsigned char FAR *)0, 0, 0, 256, (HANDLE)0, 
                    3, 3, 2, TRUE, TRUE, TRUE, &pcd->palette)) != pcdSuccess)
        goto botch;

    pcd->autoPalette = FALSE;
    err = pcdSuccess;
    GlobalUnlock(hpcd);
    *pcdptr = hpcd;
    return(0);

botch1:
    err = errno;
botch:
    if (pcdptr)
        *pcdptr = 0;
    if (hpcd && pcd) {
        if (pcd->iostate.fd >= 0 && pcd->iostate.flags & PCD_IO_IS_OPEN)
            (void) close(pcd->iostate.fd);
        if (pcd->pacInfo)
            GlobalFree(pcd->pacInfo);
    }
    if (hpcd) {
        if (pcd)
            GlobalUnlock(hpcd);
        GlobalFree(hpcd);
    }
    return (err);
}

/*
 *  Close an Image Pac and release resources.
 *  Do not close image pac file if user opened it. 
 */
PCDstatus FAR PASCAL PCDclose(hpcd)
    PCDphotoHdl hpcd;
{
    int rv = 0;
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);
    paramck(pcd->iostate.fd >= 0);
    if (!(pcd->iostate.flags & PCD_IO_LEAVE_OPEN))
        if (pcd->iostate.flags & PCD_IO_IS_OPEN) {
            if (close(pcd->iostate.fd) < 0)
                rv = errno ? errno : EIO;
    }

    if (pcd->palette)
        PCDfreePalette(pcd->palette);
    pcd->palette = 0;
    if (pcd->lpt4tv)
        PCDfree((PCDRAWDATA) pcd->lpt4tv);
    if (pcd->lpt16tv)
        PCDfree((PCDRAWDATA) pcd->lpt16tv);
    if (pcd->pacInfo) {
        GlobalFree(pcd->pacInfo);
    }
    GlobalUnlock(hpcd);
    GlobalFree(hpcd);
    return (rv);
} /* end PCDclose */


/*
 *  Close an Image Pac and release resources.
 *  Guarantees that image pac file remains open. 
 */
PCDstatus FAR PASCAL PCDrefClose(hpcd)
    PCDphotoHdl hpcd;
{
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);
    pcd->iostate.flags &= PCD_IO_LEAVE_OPEN;
    return PCDclose(hpcd);
} /* end PCDrefClose */


/*
 *  Return supported resolutions:
 *  bit resolution
 *   1  BASE/16 (note that BASE/64 is special)
 *   2  BASE/4
 *   3  BASE
 *   4  4BASE   (only if pcd->maxstep is 4BASE or 16BASE)
 *   5  16BASE  (only if pcd->maxstep is 16BASE)
 */
PCDstatus FAR PASCAL PCDgetCount(hpcd, res, rescnt)
    PCDphotoHdl hpcd;
    unsigned long FAR *res; 
    short FAR *rescnt;
{
    PCDphotoPtr pcd;

    paramck(res);
    paramck(rescnt);
    GetPhotoPtr(hpcd, pcd);

    if (pcd->maxstep == PCD_16BASE) {
        *res = 0x3e;
        *rescnt = 5;
        return (pcdSuccess);
    }
    if (pcd->maxstep == PCD_4BASE) {
        *res = 0x1e;
        *rescnt = 4;
        return (pcdSuccess);
    }
    assert(pcd->maxstep == PCD_BASE);
    *res = 0xe;
    *rescnt = 3;

    GlobalUnlock(hpcd);

    return (pcdSuccess);
}

/*
 *  Get the size of the image currently selected by
 *  |pcd->step|.
 */

PCDstatus FAR PASCAL PCDgetSize(hpcd, r)
    PCDphotoHdl hpcd;
    LPRECT     r;
{
    int width, height;
    PCDphotoPtr pcd;
    PCDstatus rv = pcdSuccess;

    paramck(r);
    GetPhotoPtr(hpcd, pcd);

    if ((pcd->step >= PCD_BASE_OVER_16) && (pcd->step <= pcd->maxstep)) {
        PCDlistResolution(pcd->step, &width, &height);
        if (pcd->xform & PCD_90_ROTATION) {
            int tmp = width;

            width = height;
            height = tmp;
        }
        SetRectSize(r, 0, 0, width, height);
    } else {
        SetRectSize(r, 0, 0, 0, 0);
        rv = pcdBadParam;
    }
    GlobalUnlock(hpcd);
    return(rv);
}

/*
 *  Set values for plane and column bytes.
 */
PCDstatus FAR PASCAL PCDsetPlaneColumn(hpcd, planeBytes, columnBytes)
    PCDphotoHdl hpcd;
    long planeBytes;
    short columnBytes;
{
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);

    /* XXX - presumably we want to check for reasonable values */
    pcd->planeBytes = planeBytes;
    pcd->columnBytes = columnBytes;
    GlobalUnlock(hpcd);
    return (pcdSuccess);
}

/*
 *  Retrieve values for plane and column bytes.
 */
PCDstatus FAR PASCAL PCDgetPlaneColumn(hpcd, lpPlaneBytes, lpColumnBytes)
    PCDphotoHdl hpcd;
    long FAR *lpPlaneBytes;
    short FAR *lpColumnBytes;
{
    PCDphotoPtr pcd;

    paramck(lpPlaneBytes);
    paramck(lpColumnBytes);

    GetPhotoPtr(hpcd, pcd);
    
    *lpPlaneBytes = pcd->planeBytes;
    *lpColumnBytes = pcd->columnBytes;

    GlobalUnlock(hpcd);
    return(pcdSuccess);
}


/*
 *  Return the number of bytes a row of |width| pixels will
 *  occupy.
 */
PCDstatus FAR PASCAL PCDgetBytesPerRow(hpcd, width, rowbytes)
    PCDphotoHdl hpcd;
    short width;
    long FAR *rowbytes;
{
    PCDphotoPtr pcd;
    int rv;

    paramck(rowbytes != NULL);
    GetPhotoPtr(hpcd, pcd);
    if (pcd->format == PCD_SINGLE || pcd->format == PCD_PALETTE) 
        rv = width;
    else
        rv = (width * pcd->columnBytes);

    GlobalUnlock(hpcd);

    *rowbytes = rv;
    return(pcdSuccess);
}

/*
 *  Provide (x, y) values for the specified resolution step.
 *  Assumes landscape orientation.
 */
PCDstatus FAR PASCAL PCDlistResolution(step, x, y)
    PCDresolution step;
    short FAR *x, FAR *y;
{

    if (step < PCD_BASE_OVER_64 || step > PCD_16BASE) {
        *x = *y = 0;
        return(pcdBadParam);
    }
    *x = rowsiz(step);
    *y = colsiz(step);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDsetProgress(PCDphotoHdl hpcd, FARPROC lpfnCheck, long lData)
{
    PCDphotoPtr pcd; 
    
    GetPhotoPtr(hpcd, pcd);
    pcd->check = lpfnCheck;
    pcd->checkData = lData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDgetProgress(PCDphotoHdl hpcd, FARPROC FAR *lplpfnCheck, long FAR *lplData)
{
    PCDphotoPtr pcd; 
    
    paramck(lplpfnCheck);
    GetPhotoPtr(hpcd, pcd);
    *lplpfnCheck = pcd->check;
    *lplData = pcd->checkData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}


PCDstatus FAR PASCAL 
PCDsetAbort(PCDphotoHdl hpcd, FARPROC lpfnAbort, long lData)
{
    PCDphotoPtr pcd; 
    
    GetPhotoPtr(hpcd, pcd);
    pcd->abort = lpfnAbort;
    pcd->abortData = lData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}


PCDstatus FAR PASCAL 
PCDgetAbort(PCDphotoHdl hpcd, FARPROC FAR *lplpfnAbort, long FAR *lplData)
{
    PCDphotoPtr pcd; 
    
    paramck(lplpfnAbort);
    GetPhotoPtr(hpcd, pcd);
    *lplpfnAbort = pcd->abort;
    *lplData = pcd->abortData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDsetDiscChanged(PCDphotoHdl hpcd, FARPROC lpfnChange, long lData)
{
    PCDphotoPtr pcd; 
    
    GetPhotoPtr(hpcd, pcd);
    pcd->iostate.volChg = lpfnChange;
    pcd->iostate.volChgData = lData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDgetDiscChanged(PCDphotoHdl hpcd, FARPROC FAR *lplpfnChange, 
        long FAR *lplData)
{
    PCDphotoPtr pcd; 
    
    paramck(lplpfnChange);
    GetPhotoPtr(hpcd, pcd);
    *lplpfnChange = pcd->iostate.volChg;
    *lplData = pcd->iostate.volChgData;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDsetTransform(PCDphotoHdl hpcd, PCDtransform op)
{
    PCDphotoPtr pcd; 

    paramck(validTransform(op));
    GetPhotoPtr(hpcd, pcd);

    pcd->xform = EXTERNAL_XFORM(op);
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDgetTransform(PCDphotoHdl hpcd, PCDtransform FAR *lpOp)
{
    PCDphotoPtr pcd; 

    paramck(lpOp);
    GetPhotoPtr(hpcd, pcd);

    *lpOp = EXTERNAL_XFORM(pcd->xform);

    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDgetRotation(PCDphotoHdl hpcd, PCDtransform FAR *lpOp)
{
    PCDphotoPtr pcd; 

    paramck(lpOp);
    GetPhotoPtr(hpcd, pcd);

    *lpOp = EXTERNAL_XFORM(pcd->rotation);

    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDgetAutoPalette(PCDphotoHdl hpcd, BOOL FAR *lpbOn)
{
    return(pcdNotAvailable);
}

PCDstatus FAR PASCAL PCDsetAutoPalette(PCDphotoHdl hpcd, BOOL bOn)
{
    return(pcdLazyHacker);
}

PCDstatus FAR PASCAL 
PCDgetResolution(PCDphotoHdl hpcd, PCDresolution FAR *lpRes)
{
    PCDphotoPtr pcd;

    paramck(lpRes);
    GetPhotoPtr(hpcd, pcd);

    *lpRes = pcd->step;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDsetResolution(PCDphotoHdl hpcd, PCDresolution res)
{
    PCDphotoPtr pcd;
    GetPhotoPtr(hpcd, pcd);

    paramck(res >= PCD_BASE_OVER_16 && res <= PCD_ABSOLUTE);

    pcd->step = res;

/* XXX - Transform here and in setTransform? */
    pcd->bounds.top = 0;
    pcd->bounds.left = 0;
    pcd->bounds.right = rowsiz(res);
    pcd->bounds.bottom = colsiz(res);
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}


PCDstatus FAR PASCAL 
PCDgetFormat(PCDphotoHdl hpcd, PCDformat FAR *lpFmt)
{
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);
    *lpFmt = pcd->format;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDsetFormat(PCDphotoHdl hpcd, PCDformat fmt)
{
    PCDphotoPtr pcd;

    paramck(validFormat(fmt));
    GetPhotoPtr(hpcd, pcd);

    pcd->format = fmt;
    if (fmt == PCD_PALETTE || fmt == PCD_SINGLE) {
        pcd->planeBytes = 1;
        pcd->columnBytes = 1;
    } else if (pcd->columnBytes == 1) {
        pcd->planeBytes = 1;
        pcd->columnBytes = 3;
    }
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL
PCDcoordToAbsolute(LPRECT lpSrc, int res, LPRECT lpDst)
{ 
    paramck(lpSrc);
    paramck(lpDst);
    paramck(res > 0 && res <= PCD_ABSOLUTE);

    lpDst->top = lpSrc->top << (PCD_ABSOLUTE - res); 
    lpDst->left = lpSrc->left << (PCD_ABSOLUTE - res) ; 
    lpDst->bottom = lpSrc->bottom << (PCD_ABSOLUTE - res) ; 
    lpDst->right = lpSrc->right << (PCD_ABSOLUTE - res); 
    return(pcdSuccess);
}

/**
 ** Converts the specified |src| point at resolution |step|
 ** into absolute coordinates, storing the result in |dst|.
 **/
PCDstatus FAR PASCAL
PCDpointToAbsolute(LPPOINT src, PCDresolution step, LPPOINT dst)
{
    int xsign, ysign;

    if ((src == (LPPOINT) 0) || (dst == (LPPOINT) 0))
        return (pcdBadParam);
    if ((step < PCD_BASE_OVER_64) || (step > PCD_16BASE))
        return (pcdBadParam);
    xsign = src->x < 0 ? -1 : 1;
    ysign = src->y < 0 ? -1 : 1;
    dst->x = (src->x * xsign) << (PCD_ABSOLUTE - step);
    dst->y = (src->y * ysign) << (PCD_ABSOLUTE - step);
    dst->x *= xsign;
    dst->y *= ysign;
    return (pcdSuccess);
}

/**
 ** Converts the specified |src| point in absolute coordinates
 ** into the specified step |step|, storing the result in |dst|.
 **/
PCDstatus FAR PASCAL
PCDpointToStep(LPPOINT src, PCDresolution step, LPPOINT dst)
{
    int xsign, ysign;

    if ((src == (LPPOINT) 0) || (dst == (LPPOINT) 0))
        return (pcdBadParam);
    if ((step < PCD_BASE_OVER_64) || (step > PCD_16BASE))
        return (pcdBadParam);
    xsign = src->x < 0 ? -1 : 1;
    ysign = src->y < 0 ? -1 : 1;
    dst->x = (src->x * xsign) >> (PCD_ABSOLUTE - step);
    dst->y = (src->y * ysign) >> (PCD_ABSOLUTE - step);
    dst->x *= xsign;
    dst->y *= ysign;
    return (pcdSuccess);
}
PCDstatus FAR PASCAL
PCDrectToAbsolute(LPRECT lpSrc, int res, LPRECT lpDst)
{ 
    paramck(lpSrc);
    paramck(lpDst);
    paramck(res >= PCD_BASE_OVER_64 && res <= PCD_ABSOLUTE);

    lpDst->top = lpSrc->top << (PCD_ABSOLUTE - res) ; 
    lpDst->left = lpSrc->left << (PCD_ABSOLUTE - res) ; 
    lpDst->bottom = lpSrc->bottom << (PCD_ABSOLUTE - res) ; 
    lpDst->right = lpSrc->right << (PCD_ABSOLUTE - res) ; 
    return(pcdSuccess);
}

/**
 ** Converts the specified |src| rectangle in absolute coordinates
 ** into the specified step |step|, storing the result in |dst|.
 **/
PCDstatus FAR PASCAL
PCDrectToStep(LPRECT src, PCDresolution step, LPRECT dst)
{
    int tsign, lsign, bsign, rsign;

    if ((src == (LPRECT)0) || (dst == ((LPRECT)0)))
        return (pcdBadParam);
    if ((step < PCD_BASE_OVER_64) || (step > PCD_16BASE))
        return (pcdBadParam);
    tsign = src->top < 0 ? -1 : 1;
    lsign = src->left < 0 ? -1 : 1;
    bsign = src->bottom < 0 ? -1 : 1;
    rsign = src->right < 0 ? -1 : 1;
    dst->top = (src->top * tsign) >> (PCD_ABSOLUTE - step);
    dst->left = (src->left * lsign) >> (PCD_ABSOLUTE - step);
    dst->bottom = (src->bottom * bsign) >> (PCD_ABSOLUTE - step);
    dst->right = (src->right * rsign) >> (PCD_ABSOLUTE - step);
    dst->top *= tsign;
    dst->left *= lsign;
    dst->bottom *= bsign;
    dst->right *= rsign;
    return (pcdSuccess);
}

PCDstatus FAR PASCAL
PCDalignCoord(LPRECT lpSrc, int res, LPRECT lpDst)
{ 
    paramck(lpSrc);
    paramck(lpDst);
    paramck(res >= PCD_BASE_OVER_16 && res <= PCD_ABSOLUTE);

    lpDst->top = lpSrc->top >> (PCD_ABSOLUTE - res); 
    lpDst->left = lpSrc->left >> (PCD_ABSOLUTE - res) ; 
    lpDst->bottom = lpSrc->bottom >> (PCD_ABSOLUTE - res) ; 
    lpDst->right = lpSrc->right >> (PCD_ABSOLUTE - res); 
    return(pcdSuccess);
}

PCDstatus FAR PASCAL
PCDalignRect(LPRECT lpSrc, int res, LPRECT lpDst)
{ 
    paramck(lpSrc);
    paramck(lpDst);
    paramck(res >= PCD_BASE_OVER_16 && res <= PCD_ABSOLUTE);

    lpDst->top = lpSrc->top >> (PCD_ABSOLUTE - res) ; 
    lpDst->left = lpSrc->left >> (PCD_ABSOLUTE - res) ; 
    lpDst->bottom = lpSrc->bottom >> (PCD_ABSOLUTE - res) ; 
    lpDst->right = lpSrc->right >> (PCD_ABSOLUTE - res) ; 
    return(pcdSuccess);
}

PCDstatus FAR PASCAL
PCDcoordMult(PCDresolution res, short FAR *lpMult)  
{
    paramck(lpMult);
    paramck(res >= PCD_BASE_OVER_64 && res <= PCD_ABSOLUTE);

    *lpMult = 1 << (PCD_ABSOLUTE - res);
    return(pcdSuccess);
}


PCDstatus FAR PASCAL
PCDgetToolkitVersion(WORD FAR *lpVersion)
{
    paramck(lpVersion);
    *lpVersion = (PCD_MINOR_RELEASE << 8) | (PCD_MAJOR_RELEASE);
    return(pcdSuccess);
}


PCDstatus FAR PASCAL
PCDfreeBitmap(PCDbitmapHdl hBitmap)
{
    paramck(hBitmap);
    GlobalFree(hBitmap);
/* XXX - more error checking? */
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDgetPalette(PCDphotoHdl hpcd, PCDpaletteHdl FAR *lpPal)
{
    PCDphotoPtr pcd;

    paramck(lpPal);
    GetPhotoPtr(hpcd, pcd);

    incPalRef(pcd->palette);
    *lpPal = pcd->palette;
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDsetPalette(PCDphotoHdl hpcd, PCDpaletteHdl pal)
{
    PCDphotoPtr pcd;

    paramck(pal);
    GetPhotoPtr(hpcd, pcd);

    if (pcd->palette)
        PCDfreePalette(pcd->palette);
    pcd->palette = pal;
    incPalRef(pcd->palette);
    GlobalUnlock(hpcd);
    return(pcdSuccess);
}


/* XXX - move these */
#define FORM_LONG(b0, b1, b2, b3) \
    (((unsigned long)(b3) & 0xff) | \
    (((unsigned long)(b2) & 0xff) << 8) | \
    (((unsigned long)(b1) & 0xff) << 16) | \
    (((unsigned long)(b0) & 0xff) << 24))


#define FORM_SHORT(b0, b1)  \
    (((b0) << 8) | (b1))
/*
 * Reads and returns the IPI (image pac information).
 * Internal version.
 */

PCDstatus
readImageInfo(PCDphotoPtr pcd) 
{
    PCDstatus rv = pcdSuccess;
    static unsigned char rawinfo[sizeof(PCDpacInfoRec) + 8];
    static char ipiSignature[] = { 'P', 'C', 'D', '_', 'I', 'P', 'I' };
    HANDLE hBuf = 0;
    PCDpacInfoPtr lpCachedInfo = 0;
    int i;
    BOOL needToClose = FALSE;

    if ((hBuf = GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE, 
                                sizeof(PCDpacInfoRec))) == 0) {
            rv = ENOMEM;
            goto out;
    }
    if ((lpCachedInfo = (PCDpacInfoPtr)GlobalLock(hBuf)) == 0) {
        GlobalFree(hBuf);
        hBuf = 0;
        rv = ENOMEM;
        goto out;
    }
    if (!(pcd->iostate.flags & PCD_IO_IS_OPEN)) {
        rv = PCDopenFile(&pcd->iostate);
        if (rv != pcdSuccess) goto out;
        needToClose = TRUE;
    }

/* IPI at byte offset 2K */
    rv = PCDsetMark(&pcd->iostate, stob(1), 0);
    if (rv != pcdSuccess) goto out;
    PCDreadSome(&pcd->iostate, rawinfo, sizeof(rawinfo));
    if (rv != pcdSuccess) goto out;
if (_fstrncmp(rawinfo, ipiSignature, sizeof(ipiSignature)) != 0 ||
		rawinfo[7] < SPEC_MAJOR_VERS || 
		(rawinfo[7] == SPEC_MAJOR_VERS && rawinfo[8] < SPEC_MINOR_VERS)) {
	        GlobalFree(hBuf);
	        hBuf = 0;
	        rv = pcdBadFmt;
	        goto out;
    }
/* Copy out individual fields */
    lpCachedInfo->version = FORM_SHORT(rawinfo[7], rawinfo[8]);
    lpCachedInfo->piwVersion = FORM_SHORT(rawinfo[9], rawinfo[10]);
    lpCachedInfo->magnification = FORM_SHORT(rawinfo[11], rawinfo[12]);
    lpCachedInfo->scanTime = FORM_LONG(rawinfo[13], rawinfo[14], rawinfo[15], rawinfo[16]);
    lpCachedInfo->modTime = FORM_LONG(rawinfo[17], rawinfo[18], rawinfo[19], rawinfo[20]);
    lpCachedInfo->mediaId = rawinfo[21];
    _fmemcpy(lpCachedInfo->mediaType, &rawinfo[22],
                sizeof(lpCachedInfo->mediaType));
    _fmemcpy(lpCachedInfo->scannerVendor, &rawinfo[42],
                sizeof(lpCachedInfo->scannerVendor));
    _fmemcpy(lpCachedInfo->scannerProdID, &rawinfo[62],
                sizeof(lpCachedInfo->scannerProdID));
    _fmemcpy(lpCachedInfo->scannerFirmRev, &rawinfo[78],
                sizeof(lpCachedInfo->scannerFirmRev));
    _fmemcpy(lpCachedInfo->scannerFirmDate, &rawinfo[82],
                sizeof(lpCachedInfo->scannerFirmDate));
    _fmemcpy(lpCachedInfo->scannerSerial, &rawinfo[90],
                sizeof(lpCachedInfo->scannerSerial));
    lpCachedInfo->scannerSize[0] = rawinfo[110];
    lpCachedInfo->scannerSize[1] = rawinfo[111];
    _fmemcpy(lpCachedInfo->piwEquipment, &rawinfo[112],
                sizeof(lpCachedInfo->piwEquipment));
    lpCachedInfo->nameCharSet = rawinfo[132];
    _fmemcpy(lpCachedInfo->nameEscapes, &rawinfo[133],
                sizeof(lpCachedInfo->nameEscapes));
    _fmemcpy(lpCachedInfo->photofinisher, &rawinfo[165],
                sizeof(lpCachedInfo->photofinisher));
    _fmemcpy(lpCachedInfo->SBAdata, &rawinfo[225],
                sizeof(lpCachedInfo->SBAdata));

    lpCachedInfo->copyright = rawinfo[331];

/* Make sure this field is null-padded */
    for (i = 0; i < sizeof(lpCachedInfo->copyrightFile); i++) {
        if (rawinfo[332 + i] == 0xff || rawinfo[332 + i] == ' ')
            rawinfo[332 + i] = '\0';
    }
    _fmemcpy(lpCachedInfo->copyrightFile, &rawinfo[332],
                sizeof(lpCachedInfo->copyrightFile));
    if (needToClose) {
        rv = PCDcloseFile(&pcd->iostate);
        if (rv != pcdSuccess) goto out;
    }
out:
    if (hBuf) GlobalUnlock(hBuf);
    pcd->pacInfo = hBuf;
    return(rv);
}

/*
 * Reads and returns the IPI (API wrapper).
 */

PCDstatus FAR PASCAL
PCDreadImageInfo(PCDphotoHdl hpcd, PCDpacInfoPtr lpPacInfo)
{
    PCDphotoPtr pcd;
    PCDstatus   rv = pcdSuccess;
    PCDpacInfoPtr lpCachedInfo, lpNewInfo = lpPacInfo;

    paramck(lpPacInfo);
    GetPhotoPtr(hpcd, pcd);

/* Not read yet - get the info */
    if (!pcd->pacInfo)
        readImageInfo(pcd);
    
    if ((lpCachedInfo = (PCDpacInfoPtr)GlobalLock(pcd->pacInfo)) == 0) {
        rv = ENOMEM;
        goto out;
    }

/* Copy data from cache to user buffer */
    _fmemcpy(lpNewInfo, lpCachedInfo, sizeof(PCDpacInfoRec));

    GlobalUnlock(pcd->pacInfo);
out:
    GlobalUnlock(hpcd);
    return(rv);
}

#include <dos.h>

char    rootpath[4];

char    infoFile[_MAX_PATH];
char    infodotpcd[] = "info.pcd";

PCDstatus FAR PASCAL
PCDgetVolume(LPSTR lpszDrive, LPSTR lpszVolInfo)
{
    LPSTR   fullPath = infoFile, fileName = infodotpcd;
    PCDinfoFileRec iff;
    PCDstatus rv;

    paramck(lpszVolInfo);

    paramck(lpszDrive);
    paramck(lpszDrive[1]);
    paramck(lpszDrive[1] == ':' && lpszDrive[2] == '\0');

    wsprintf(fullPath, "%s\\photo_cd\\%s", lpszDrive, fileName);
    if ((rv = PCDreadInfoFile(fullPath, &iff)) != pcdSuccess)
        return(rv);
    wsprintf(lpszVolInfo, "%12.12s %010lu %010lu", 
        (char FAR *)iff.serialNumber, iff.creationTime, iff.modificationTime);
    return(rv);
}

/*
 *  PhotoCD Info function.
 */
PCDstatus FAR PASCAL 
PCDreadInfoFile(LPSTR path, PCDinfoFilePtr PCDinfo)
{
    LPSTR   fullPath = infoFile, fileName = infodotpcd;
    int     fd;
    OFSTRUCT of;
    char FAR *charPun;

    paramck(path);
    paramck(PCDinfo);

    if ((fd = OpenFile(path, &of, OF_READ)) < 0)
        return(ENOENT);

    if (_lread(fd, PCDinfo, sizeof(PCDinfoFileRec)) != sizeof(PCDinfoFileRec)){
        _lclose(fd);
        return(EIO);
    }
    _lclose(fd);

    if (PCDinfo->majorRevision < SPEC_MAJOR_VERS || 
		(PCDinfo->majorRevision == SPEC_MAJOR_VERS && PCDinfo->minorRevision < SPEC_MINOR_VERS))
		return(pcdBadFmt);

    charPun = (char FAR *)&PCDinfo->nImages;
    PCDinfo->nImages = FORM_SHORT(charPun[0], charPun[1]);
    charPun = (char FAR *)&PCDinfo->creationTime;
    PCDinfo->creationTime = FORM_LONG(charPun[0], charPun[1], charPun[2], charPun[3]);
    charPun = (char FAR *)&PCDinfo->modificationTime;
    PCDinfo->modificationTime = FORM_LONG(charPun[0], charPun[1], charPun[2], charPun[3]);
    return(pcdSuccess);
}

/* Allow dusty decks */
PCDstatus FAR PASCAL 
PCDsetCompat()
{
#ifdef  ENHANCED_COMPAT
    doCompat = TRUE;
#endif
    return(pcdSuccess);
}
