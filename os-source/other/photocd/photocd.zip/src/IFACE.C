/*
 *	Photo CD Development Toolkit
 *
 *	iface.c
 *	Exported wrappers for public functions.
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)iface.c	1.75 - 92/06/03"
#endif

#include <windows.h>
#include "pcdlib.h"
#include "pcdpriv.h"

HANDLE	hPCDlib = 0;
HANDLE	toolkitOwner = 0;

#define	INIT_TOOLKIT	/* initToolkit() */

/*
 * Yield control until *whan is zero.
 */

/* static */
PCDstatus 
PCDsleep(HANDLE *wchan)
{
	MSG	msg;

	while(*wchan)  {
		if (*wchan && *wchan == GetCurrentTask()) 
			return(pcdReentry);
		while (PeekMessage(&msg, 0, 0, 0, PM_REMOVE)) 
			if (msg.message == WM_QUIT) { 
				return(pcdUserAbort); 
			} else { 
	            TranslateMessage(&msg); 
	            DispatchMessage(&msg); 
			} 
	} 
	return(pcdSuccess);
}

#define	DO_LOCKED(x) \
	PCDstatus	rv; \
	if ((rv = PCDsleep(&toolkitOwner)) != pcdSuccess) \
		return(rv); \
	toolkitOwner = GetCurrentTask(); \
	rv = (x); \
	toolkitOwner = 0; \
	return(rv);

PCDstatus FAR PASCAL xPCDopen(LPSTR lpPath, PCDphotoHdl FAR *lphPCD)
{
	DO_LOCKED(PCDopen(lpPath, lphPCD));
} 
PCDstatus FAR PASCAL	xPCDrefOpen(int fd, PCDphotoHdl FAR *lphPCD)
{
	DO_LOCKED(PCDrefOpen(fd, lphPCD));
} 
PCDstatus FAR PASCAL xPCDclose(PCDphotoHdl pcd)
{
	DO_LOCKED(PCDclose(pcd));
} 
PCDstatus FAR PASCAL	xPCDrefClose(PCDphotoHdl pcd)
{
	DO_LOCKED(PCDrefClose(pcd));
} 
PCDstatus FAR PASCAL xPCDsetResolution(PCDphotoHdl pcd, PCDresolution res)
{
	return(PCDsetResolution(pcd, res));
} 
PCDstatus FAR PASCAL xPCDgetResolution(PCDphotoHdl pcd, PCDresolution FAR *r)
{
	return(PCDgetResolution(pcd, r));
} 
PCDstatus FAR PASCAL xPCDgetRotation(PCDphotoHdl hPcd, PCDresolution FAR *lpTransform)
{
	return(PCDgetRotation(hPcd, lpTransform));
} 
PCDstatus FAR PASCAL xPCDsetFormat(PCDphotoHdl h, PCDformat f)
{
	return(PCDsetFormat(h, f));
} 
PCDstatus FAR PASCAL xPCDgetFormat(PCDphotoHdl h, PCDformat FAR *f)
{
	return(PCDgetFormat(h, f));
} 
PCDstatus FAR PASCAL xPCDgetCount(PCDphotoHdl pcd, unsigned long FAR *lpRes, short FAR *lpResCount)
{
	return(PCDgetCount(pcd, lpRes, lpResCount));
} 
PCDstatus FAR PASCAL xPCDgetSize(PCDphotoHdl pcd, LPRECT lpBoundRect)
{
	return(PCDgetSize(pcd, lpBoundRect));
} 
PCDstatus FAR PASCAL xPCDgetPlaneColumn(PCDphotoHdl h, long FAR *p, short FAR *c)
{
	return(PCDgetPlaneColumn(h, p, c));
} 
PCDstatus FAR PASCAL xPCDsetPlaneColumn(PCDphotoHdl pcd, long lPlaneBytes, short nColumnBytes)
{
	return(PCDsetPlaneColumn(pcd, lPlaneBytes, nColumnBytes));
} 
PCDstatus FAR PASCAL xPCDsetPalette(PCDphotoHdl pcd, PCDpaletteHdl hPal)
{
	return(PCDsetPalette(pcd, hPal));
} 
PCDstatus FAR PASCAL xPCDgetPalette(PCDphotoHdl pcd, PCDpaletteHdl FAR *lphPal)
{
	return(PCDgetPalette(pcd, lphPal));
} 
PCDstatus FAR PASCAL xPCDOsetPalette(PCDoviewHdl pcd, PCDpaletteHdl hPal)
{
	return(PCDOsetPalette(pcd, hPal));
} 
PCDstatus FAR PASCAL xPCDOgetPalette(PCDoviewHdl pcd, PCDpaletteHdl FAR *lphPal)
{
	return(PCDOgetPalette(pcd, lphPal));
} 
PCDstatus FAR PASCAL xPCDsetTransform(PCDphotoHdl pcd, PCDtransform op)
{
	return(PCDsetTransform(pcd, op));
} 
PCDstatus FAR PASCAL xPCDgetTransform(PCDphotoHdl pcd, PCDtransform FAR*lpOp)
{
	return(PCDgetTransform(pcd, lpOp));
} 
PCDstatus FAR PASCAL xPCDgetBytesPerRow(PCDphotoHdl pcd, short width, long FAR *lpdwRowBytes)
{
	return(PCDgetBytesPerRow(pcd, width, lpdwRowBytes));
} 
PCDstatus FAR PASCAL xPCDgetBlock(PCDphotoHdl pcd, LPRECT lpBoundRect, PCDRAWDATA hpBuffer, long lStride)
{
	DO_LOCKED(PCDgetBlock(pcd, lpBoundRect, hpBuffer, lStride));
} 
PCDstatus FAR PASCAL xPCDloadImage(PCDphotoHdl pcd, LPRECT lpBoundRect, PCDbitmapHdl FAR *lphPCDbitmap)
{
	DO_LOCKED(PCDloadImage(pcd, lpBoundRect, lphPCDbitmap));
} 
#ifdef notyet
PCDstatus FAR PASCAL xPCDconvertBitmap(PCDbitmapHdl hPCDbitmap, HDC hDisplayContext, HBITMAP FAR *lphBitmap)
{
	return(PCDconvertBitmap(hPCDbitmap, hDisplayContext, lphBitmap));
} 
#endif
PCDstatus FAR PASCAL xPCDfreeBitmap(PCDbitmapHdl hPCDbitmap)
{
	return(PCDfreeBitmap(hPCDbitmap));
} 
PCDstatus FAR PASCAL xPCDsetProgress(PCDphotoHdl hPcd, FARPROC lpfnCheckProc, long lData)
{
	return(PCDsetProgress(hPcd, lpfnCheckProc, lData));
} 
PCDstatus FAR PASCAL xPCDgetProgress(PCDphotoHdl hPcd, FARPROC FAR *lplpfnCheckProc, long FAR *lplData)
{
	return(PCDgetProgress(hPcd, lplpfnCheckProc, lplData));
} 
PCDstatus FAR PASCAL xPCDsetAbort(PCDphotoHdl hPcd, FARPROC lpfnAbortProc, long lData)
{
	return(PCDsetAbort(hPcd, lpfnAbortProc, lData));
} 
PCDstatus FAR PASCAL xPCDgetAbort(PCDphotoHdl hPcd, FARPROC FAR *lplpfnAbortProc, long FAR *lplData)
{
	return(PCDgetAbort(hPcd, lplpfnAbortProc, lplData));
} 
PCDstatus FAR PASCAL xPCDsetDiscChanged(PCDphotoHdl hPcd, FARPROC lpfnChangeProc, long lData)
{
	return(PCDsetDiscChanged(hPcd, lpfnChangeProc, lData));
} 
PCDstatus FAR PASCAL xPCDgetDiscChanged(PCDphotoHdl hPcd, FARPROC FAR *lplpfnChangeProc, long FAR *lplData)
{
	return(PCDgetDiscChanged(hPcd, lplpfnChangeProc, lplData));
} 
PCDstatus FAR PASCAL xPCDapplyTransform(PCDbitmapHdl hBmap, PCDtransform op, BOOL inplace, FARPROC lpAbort, long lAbortData, FARPROC lpProgress, long lProgressData, PCDbitmapHdl FAR *lphResult)
{
	DO_LOCKED(PCDapplyTransform(hBmap, op, inplace, lpAbort, lAbortData, lpProgress, lProgressData, lphResult));
} 
PCDstatus FAR PASCAL xPCDYCCtoRGB(PCDRAWDATA hpYCCdata, long yPlane, short yCol, PCDRAWDATA hpRGBdata, long rPlane, short rCol, long count)
{
	return(PCDYCCtoRGB(hpYCCdata, yPlane, yCol, hpRGBdata, rPlane, rCol, count));
} 
PCDstatus FAR PASCAL xPCDYCCtoPalette(PCDRAWDATA hpYCCdata, long yPlane, short yCol, PCDRAWDATA hpRGBdata, long count, PCDpaletteHdl hPal)
{
	return(PCDYCCtoPalette(hpYCCdata, yPlane, yCol, hpRGBdata, count, hPal));
} 
PCDstatus FAR PASCAL xPCDRGBtoPalette(PCDRAWDATA hpRGBdata, long rPlane, short rCol, PCDRAWDATA hpPalData, long count, PCDpaletteHdl hPal)
{
	return(PCDRGBtoPalette(hpRGBdata, rPlane, rCol, hpPalData, count, hPal));
}
PCDstatus FAR PASCAL xPCDlistResolution(PCDresolution pcd, short FAR *lpX, short FAR *lpY)
{
	return(PCDlistResolution(pcd, lpX, lpY));
} 
PCDstatus FAR PASCAL xPCDexport(PCDphotoHdl pcd, LPRECT lpBoundRect, LPSTR lpszExport, LPSTR lpszOutputFile)
{
	return(PCDexport(pcd, lpBoundRect, lpszExport, lpszOutputFile));
} 
PCDstatus FAR PASCAL xPCDcreatePalette(unsigned char FAR *lpPal, long lPlaneBytes, int nColumnBytes, int nColors, HANDLE hLUT, short nC1bits, short nC2bits, short nC3bits, BOOL bRGBquant, BOOL bRGBpalette, BOOL bDoErrDiff, PCDpaletteHdl FAR *lphPal)
{
	DO_LOCKED(PCDcreatePalette(lpPal, lPlaneBytes, nColumnBytes, nColors, hLUT, nC1bits, nC2bits, nC3bits, bRGBquant, bRGBpalette, bDoErrDiff, lphPal));
} 
PCDstatus FAR PASCAL xPCDfreePalette(PCDpaletteHdl h)
{
	return(PCDfreePalette(h));
} 
PCDstatus FAR PASCAL xPCDpointToAbsolute(LPPOINT lpSrc, int res, LPPOINT lpDst)
{
	return(PCDpointToAbsolute(lpSrc, res, lpDst));
} 
PCDstatus FAR PASCAL xPCDpointToStep(LPPOINT lpSrc, int res, LPPOINT lpDst)
{
	return(PCDpointToStep(lpSrc, res, lpDst));
} 
PCDstatus FAR PASCAL xPCDrectToAbsolute(LPRECT lpSrc, int res, LPRECT lpDst)
{
	return(PCDrectToAbsolute(lpSrc, res, lpDst));
} 
PCDstatus FAR PASCAL xPCDrectToStep(LPRECT lpSrc, int res, LPRECT lpDst)
{
	return(PCDrectToStep(lpSrc, res, lpDst));
} 
PCDstatus FAR PASCAL xPCDcoordMult(PCDresolution res, short FAR *lpMult)
{
	return(PCDcoordMult(res, lpMult));
} 
PCDstatus FAR PASCAL xPCDgetToolkitVersion(WORD FAR *vp)
{
	return(PCDgetToolkitVersion(vp));
} 
PCDstatus FAR PASCAL xPCDOclose(PCDoviewHdl hPcdo)
{
	DO_LOCKED(PCDOclose(hPcdo));
} 
PCDstatus FAR PASCAL xPCDOrefClose(PCDoviewHdl hPcdo)
{
	DO_LOCKED(PCDOrefClose(hPcdo));
} 
PCDstatus FAR PASCAL xPCDOgetFriend(PCDoviewHdl hPcdo, LPSTR lpPath)
{
	return(PCDOgetFriend(hPcdo, lpPath));
} 
PCDstatus FAR PASCAL xPCDOgetBytesPerRow(PCDoviewHdl pcd, short width, long FAR *lplRowBytes)
{
	return(PCDOgetBytesPerRow(pcd, width, lplRowBytes));
} 
PCDstatus FAR PASCAL xPCDOgetCount(PCDoviewHdl hPcdo, short FAR *lpImgCount)
{
	return(PCDOgetCount(hPcdo, lpImgCount));
} 
PCDstatus FAR PASCAL xPCDOgetFormat(PCDoviewHdl hPcdo, PCDformat FAR *lpFormat)
{
	return(PCDOgetFormat(hPcdo, lpFormat));
} 
PCDstatus FAR PASCAL xPCDOgetBlock(PCDoviewHdl pcd, PCDRAWDATA buf, long lStride)
{
	DO_LOCKED(PCDOgetBlock(pcd, buf, lStride));
} 
PCDstatus FAR PASCAL xPCDOloadImage(PCDphotoHdl pcd, PCDbitmapHdl FAR *lphPCDbitmap)
{
	DO_LOCKED(PCDOloadImage(pcd, lphPCDbitmap));
} 
PCDstatus FAR PASCAL xPCDOgetPlaneColumn(PCDoviewHdl hPcdo, long FAR *lpPlane, short FAR *lpColumn)
{
	return(PCDOgetPlaneColumn(hPcdo, lpPlane, lpColumn));
} 
PCDstatus FAR PASCAL xPCDOgetResolution(PCDoviewHdl hPcdo, PCDresolution FAR *lpResolution)
{
	return(PCDOgetResolution(hPcdo, lpResolution));
} 
PCDstatus FAR PASCAL xPCDOgetRotation(PCDoviewHdl hPcdo, PCDresolution FAR *lpTransform)
{
	return(PCDOgetRotation(hPcdo, lpTransform));
} 
#ifdef notyet
PCDstatus FAR PASCAL xPCDOgetSelect(PCDoviewHdl hPcdo, WORD FAR *lpwImgNo)
{
	return(PCDOgetSelect(hPcdo, lpwImgNo));
} 
#endif
PCDstatus FAR PASCAL xPCDOgetSize(PCDoviewHdl hPcdo, LPRECT lpRect)
{
	return(PCDOgetSize(hPcdo, lpRect));
} 
PCDstatus FAR PASCAL xPCDOgetTransform(PCDoviewHdl hPcdo, PCDresolution FAR *lpTransform)
{
	return(PCDOgetTransform(hPcdo, lpTransform));
} 
#ifdef notyet
PCDstatus FAR PASCAL xPCDOgetVolume(PCDoviewHdl hPcdo, LPSTR lpVolName)
{
	return(PCDOgetVolume(hPcdo, lpVolName));
} 
#endif
PCDstatus FAR PASCAL xPCDOopen(LPSTR lpPath, PCDoviewHdl FAR *lphPcdo)
{
	DO_LOCKED(PCDOopen(lpPath, lphPcdo));
} 
PCDstatus FAR PASCAL xPCDOrefOpen(int fd, PCDoviewHdl FAR *lphPcdo)
{
	DO_LOCKED(PCDOrefOpen(fd, lphPcdo));
} 
PCDstatus FAR PASCAL xPCDOsetSelect(PCDoviewHdl hPcdo, short wImgNo)
{
	return(PCDOsetSelect(hPcdo, wImgNo));
} 
PCDstatus FAR PASCAL xPCDOgetSelect(PCDoviewHdl hPcdo, short FAR *lpwImgNo)
{
	return(PCDOgetSelect(hPcdo, lpwImgNo));
} 
PCDstatus FAR PASCAL xPCDOsetFormat(PCDoviewHdl hPcdo, PCDformat format)
{
	return(PCDOsetFormat(hPcdo, format));
} 
PCDstatus FAR PASCAL xPCDOsetPlaneColumn(PCDoviewHdl hPcdo, long planeBytes, short columnBytes)
{
	return(PCDOsetPlaneColumn(hPcdo, planeBytes, columnBytes));
} 
PCDstatus FAR PASCAL xPCDOsetResolution(PCDoviewHdl hPcdo, PCDresolution resolution)
{
	return(PCDOsetResolution(hPcdo, resolution));
} 
PCDstatus FAR PASCAL xPCDOsetTransform(PCDoviewHdl hPcdo, PCDtransform transform)
{
	return(PCDOsetTransform(hPcdo, transform));
} 
PCDstatus FAR PASCAL xPCDOsetDiscChanged(PCDoviewHdl hPcd, FARPROC lpfnChangeProc, long lData)
{
	return(PCDOsetDiscChanged(hPcd, lpfnChangeProc, lData));
} 
PCDstatus FAR PASCAL xPCDOgetDiscChanged(PCDoviewHdl hPcd, FARPROC FAR *lplpfnChangeProc, long FAR *lplData)
{
	return(PCDOgetDiscChanged(hPcd, lplpfnChangeProc, lplData));
} 
PCDstatus FAR PASCAL xPCDconvertBitmap(PCDbitmapHdl hPCDbitmap, HDC hDisplayContext, HBITMAP FAR *lphBitmap)
{
	return(PCDconvertBitmap(hPCDbitmap, hDisplayContext, lphBitmap));
}
PCDstatus FAR PASCAL xPCDreadImageInfo(PCDphotoHdl hpcd, PCDpacInfoPtr lpinfo)
{
	DO_LOCKED(PCDreadImageInfo(hpcd, lpinfo));
}
PCDstatus FAR PASCAL xPCDgetVolume(LPSTR lpszDrive, LPSTR lpszVolInfo)
{
	DO_LOCKED(PCDgetVolume(lpszDrive, lpszVolInfo));
}
PCDstatus FAR PASCAL xPCDreadInfoFile(LPSTR lpszPath, PCDinfoFilePtr lpInfo)
{
	DO_LOCKED(PCDreadInfoFile(lpszPath, lpInfo));
}
PCDstatus FAR PASCAL xPCDgetAllowance(long FAR *lplMaxBytes)
{
	return(PCDgetAllowance(lplMaxBytes));
}
PCDstatus FAR PASCAL xPCDsetAllowance(long lMaxBytes)
{
	return(PCDsetAllowance(lMaxBytes));
}
/* XXX - placeholder: not expected to be implemented */
PCDstatus FAR PASCAL xPCDnoAllowance(void)
{
	return(pcdSuccess);
}

/* XXX - unpublicized hacks for extra speed? */
PCDstatus FAR PASCAL PCDYtoR(unsigned char _huge *, long);

PCDstatus FAR PASCAL xPCDYtoR(unsigned char _huge *b, long c)
{
	return(PCDYtoR(b, c));
}

PCDstatus FAR PASCAL PCDget4BaseResiduals(PCDphotoHdl hPcd, PCDRAWDATA buffer);

PCDstatus FAR PASCAL
xPCDget4BaseResiduals(PCDphotoHdl hPcd, PCDRAWDATA buffer)
{
	DO_LOCKED(PCDget4BaseResiduals(hPcd, buffer));
}

PCDstatus FAR PASCAL PCDsetCompat();
PCDstatus FAR PASCAL
xPCDsetCompat(void)
{
	return(PCDsetCompat());
}



#ifdef  ENABLE_CATALOG_CALLS
PCDstatus FAR PASCAL xPCDOloadImageR (PCDoviewHdl hPcd, LPRECT lpRect, 												PCDbitmapHdl FAR *lphPCDbitmap)
{
	DO_LOCKED(PCDOloadImageR (hPcd, lpRect, lphPCDbitmap));
}


PCDstatus FAR PASCAL xPCDOgetQuadRect(PCDoviewHdl pcdo, int quadrant, LPRECT theRectPtr){
	return PCDOgetQuadRect (pcdo, quadrant, theRectPtr);	
}

PCDstatus FAR PASCAL xPCDOgetBlockR(PCDoviewHdl hpcd, LPRECT lprect, PCDRAWDATA buffer, long stride)
{
	DO_LOCKED(PCDOgetBlockR(hpcd, lprect, buffer, stride));
}
#endif

PCDstatus FAR PASCAL xPCDgetInternalVersion(unsigned char FAR *theBuff)
{
	return PCDgetInternalVersion(theBuff);
}


