/*
 *  Photo CD Development Toolkit
 *
 *  color.c
 *  Color space routines.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)color.c    1.123 - 92/06/03"
#endif
#include <assert.h>
#include <windows.h>
#include <dos.h>
#include <errno.h>
#include <memory.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "quant.h"
#include "pal.h"
#include "pcdovw.h"
#include "util.h"
#include "interp.h"
#include "ycctab.h"

/*
 * Converts YCC to RGB. Optimized for data 
 * being converted in place, all within one segment
 */
void NEAR _fastcall 
cvtytor(    const _segment             bseg,
            unsigned char _based(void) *boff1,
            unsigned char _based(void) *boff2,
            unsigned char _based(void) *boff3,
            int                        segpix )
{
    unsigned char   yv, c1v, c2v;
    int             gv, bv;

#define y   (bseg:>boff1)
#define c1  (bseg:>boff2)
#define c2  (bseg:>boff3)
#define r   (bseg:>boff3)
#define g   (bseg:>boff2)
#define b   (bseg:>boff1)
        /* Convert intrasegment pixels */
        while (segpix--) {
            register long rv;

            yv = *y;
            c1v = *c1;
            c2v = *c2;

            RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*			use lut 
            *r = clamped(rv);
            *g = clamped(gv);
            *b = clamped(bv);
*/
			*r = MAPTHROUGHLUT(rv); 
	        *g = MAPTHROUGHLUT(gv); 
	        *b = MAPTHROUGHLUT(bv);
            boff1 += 3;
            boff2 += 3;
            boff3 += 3;
        }
#undef  y
#undef  c1
#undef  c2
#undef  r
#undef  g
#undef  b
}


/* 
 * Like above, but output is not same segment as input and chroma 
 * is interpolated on the fly.
 */
void NEAR 
cvtytor2(   
        const _segment              iseg,
        unsigned short _based(void) *y,
        unsigned char _based(void)  *c1,
        unsigned char _based(void)  *c2,
        const _segment              oseg,
        unsigned char _based(void)  *r,
        unsigned char _based(void)  *g,
        unsigned char _based(void)  *b,
        long                        rCol,
        long                        count,
        BOOL                        odd,
        BOOL                        replicateLast )
{
    short   yv, c1v, nc1v, c2v, nc2v, iv, rv, gv, bv;
    unsigned short yx;

    nc1v = c1v = *(iseg:>c1);
    nc2v = c2v = *(iseg:>c2);
    if (odd) {
        yx = *(iseg:>y);
        yx >>= 8;
        goto odd_start;
    }

    for (;;) {
        yx = *(iseg:>y);
        yv = yx & 0xff;
        yx >>= 8;

        c1v = nc1v;
        c2v = nc2v;

        RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*		use lut
        *(oseg:>r) = clamped(rv);
        *(oseg:>g) = clamped(gv);
        *(oseg:>b) = clamped(bv);
*/
		*(oseg:>r) = MAPTHROUGHLUT(rv); 
        *(oseg:>g) = MAPTHROUGHLUT(gv); 
        *(oseg:>b) = MAPTHROUGHLUT(bv);

        if (--count == 0) break;

        r += rCol;
        g += rCol;
        b += rCol;

odd_start:
        yv = yx & 0xff;

        if (--count || !replicateLast) {
            c1++;
            c2++;
            nc1v = *(iseg:>c1);
            nc2v = *(iseg:>c2);
            /* Interpolate, rounding up */
            if ((iv = c1v + nc1v) & 1)
                iv++;
            c1v = iv >> 1;
            if ((iv = c2v + nc2v) & 1)
                iv++;
            c2v = iv >> 1;
        } else {
            c1v = nc1v;
            c2v = nc2v;
        }

        RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*		use lut
        *(oseg:>r) = clamped(rv);
        *(oseg:>g) = clamped(gv);
        *(oseg:>b) = clamped(bv);
*/
		*(oseg:>r) = MAPTHROUGHLUT(rv); 
        *(oseg:>g) = MAPTHROUGHLUT(gv); 
        *(oseg:>b) = MAPTHROUGHLUT(bv);

        if (count == 0) break;

        r += rCol;
        g += rCol;
        b += rCol;
        y++;
    }
}

/*
 * Specialized version for BASE/64.
 */
void FAR PASCAL 
PCDziYCCtoRGB(  const _segment              seg,
                unsigned char _based(void)  *y,
                unsigned char _based(void)  *c1,
                unsigned char _based(void)  *c2,
                unsigned char _based(void)  *r,
                unsigned char _based(void)  *g,
                unsigned char _based(void)  *b,
                long                        rCol,
                long                        count )
{
    unsigned char   yv, c1v, c2v;
    int             rv, gv, bv;

    while (count--) {
        yv = *(seg:>y);
        c1v = *(seg:>c1);
        c2v = *(seg:>c2);
        RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/* 		use lut
        *(seg:>r) = clamped(rv);
        *(seg:>g) = clamped(gv);
        *(seg:>b) = clamped(bv);
*/
		*(seg:>r) = MAPTHROUGHLUT(rv); 
        *(seg:>g) = MAPTHROUGHLUT(gv); 
        *(seg:>b) = MAPTHROUGHLUT(bv);

        y += 2;
        c1++;
        c2++;
        r += rCol;
        g += rCol;
        b += rCol;
    }
}

/*
 * Specialized for BASE/64. Converts YCC to 332 RGB palette indices.
 * Limited to single segment.
 */
void FAR PASCAL 
PCDziYCCto332(  const _segment              seg,
                unsigned char _based(void)  *y,
                unsigned char _based(void)  *c1,
                unsigned char _based(void)  *c2,
                unsigned char _based(void)  *p,
                long                        rCol,
                long                        count )
{
    unsigned char   yv, c1v, c2v, r, g, b;
    int             rv, gv, bv;

    while (count--) {
        yv = *(seg:>y);
        c1v = *(seg:>c1);
        c2v = *(seg:>c2);
        RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/* 		use lut
        r = clamped(rv);
        g = clamped(gv);
        b = clamped(bv);
*/
		r = MAPTHROUGHLUT(rv); 
        g = MAPTHROUGHLUT(gv); 
        b = MAPTHROUGHLUT(bv);

        *(seg:>p) = (r & 0xe0) | ((g >> 3) & 0x1c) | ((b >> 6) & 0x3);

        y += 2;
        c1++;
        c2++;
        p += rCol;
    }
}

#define SIXTYFOUR_K (0x10000L)

/*
 * Fast YCC to RGB: in-place, column bytes = 3.
 */
PCDstatus 
FAR PASCAL PCDYtoR( PCDRAWDATA  buf, 
                    long        count )
{
    unsigned char   yv, c1v, c2v;
    int             rv, gv, bv;
    BOOL            oddpixel;

    while (count) {
        register const _segment bseg = _FP_SEG(buf);
        unsigned char _based(void) *boff1;
        unsigned char _based(void) *boff2;
        unsigned char _based(void) *boff3;
        long segbytes;        /* # of whole pixels fitting in current segment */
        short segpix;
        
        boff1 = (unsigned char _based(void) *) _FP_OFF(buf);
        boff2 = (unsigned char _based(void) *) _FP_OFF(buf) + 1;
        boff3 = (unsigned char _based(void) *) _FP_OFF(buf) + 2;
        
        segbytes = SIXTYFOUR_K;
        segbytes -= (long)_FP_OFF(buf) & 0xffff;
        segpix = (short) (segbytes / 3L);
        oddpixel = (segbytes % 3L) != 0;

        if (segpix > count)
            segpix = (short) count;
        buf += 3L * (unsigned long)segpix;
        count -= segpix;

        cvtytor(bseg, boff1, boff2, boff3, segpix);

        /* Do straddling pixel, if any */
        if (oddpixel && count) {
            count--;
            yv = buf[0];
            c1v = buf[1];
            c2v = buf[2];
            RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*			use lut
            buf[2] = clamped(rv);
            buf[1] = clamped(gv);
            buf[0] = clamped(bv);
*/
			buf[2] = MAPTHROUGHLUT(rv); 
	        buf[1] = MAPTHROUGHLUT(gv); 
	        buf[0] = MAPTHROUGHLUT(bv);
            buf += 3;
        }
    }
    return(pcdSuccess);
}

/*
 *  Photo YCC to ideal gamma-corrected RGB.
 */
PCDstatus FAR PASCAL  
PCDYCCtoRGB(    PCDRAWDATA  y, 
                long        yPlane, 
                short       yCol, 
                PCDRAWDATA  r, 
                long        rPlane, 
                short       rCol, 
                long        count )
{
    unsigned char HUGE *c1, HUGE *c2;
    unsigned char HUGE *g, HUGE *b;
    int rv, gv, bv;

    paramck(y);
    paramck(r);
    if (y == r) {
        /*
         *  Conversion is being done in-place.
         */
        if ((yPlane != rPlane) || (yCol != rCol))
            return (pcdBadParam);
        c1 = y + yPlane;
        c2 = c1 + yPlane;
        while (count--) {
            rv = RFROMYCC(*y, *c1, *c2);    /* R */
            gv = GFROMYCC(*y, *c1, *c2);    /* G */
            bv = BFROMYCC(*y, *c1, *c2);    /* B */
/*          use lut instead; (3-11-93; k.s.)
			*c2 = clamped(rv);
            *c1 = clamped(gv);
            *y = clamped(bv);
*/
            *c2 = MAPTHROUGHLUT(rv);
			*c1 = MAPTHROUGHLUT(gv);
			*y = MAPTHROUGHLUT(bv);
            y += yCol;
            c1 += yCol;
            c2 += yCol;
        }
        return (0);
    }
    g = r + rPlane;
    b = g + rPlane;
 
    /* FOR WINDOWS: BGR rather then RGB */
    {
        unsigned char HUGE *tmp;

        tmp = r;
        r = b;
        b = tmp;
    }
 
    c1 = y + yPlane;
    c2 = c1 + yPlane;
    while (count--) {
        rv = RFROMYCC(*y, *c1, *c2);
        gv = GFROMYCC(*y, *c1, *c2);
        bv = BFROMYCC(*y, *c1, *c2);
/*		use lut instead; (3-11-93)
        *r = clamped(rv);
        *g = clamped(gv);
        *b = clamped(bv);
*/
        *r = MAPTHROUGHLUT(rv);
		*g = MAPTHROUGHLUT(gv);
		*b = MAPTHROUGHLUT(bv);
		r += rCol;
        g += rCol;
        b += rCol;
        y += yCol;
        c1 += yCol;
        c2 += yCol;
    }
    return (0);
}

/*
 *  Internal version of the above.
 */
PCDstatus PCDiYCCtoRGB( PCDRAWDATA  y, 
                        PCDRAWDATA  c1, 
                        PCDRAWDATA  c2, 
                        int         yCol, 
                        PCDRAWDATA  r, 
                        long        rPlane, 
                        long        rCol, 
                        long        count )
{
    unsigned char HUGE *g, HUGE *b;
    unsigned long rx, gx, bx;
    unsigned char FAR *obase;
    int rv, gv, bv;

    if (rCol == 3 && yCol == 3 && c1 == y + 1 && c2 == c1 + 1 && y == r)
        return(PCDYtoR(y, count));

    if (!fitsInSegment(r, count, rCol)) {
        g = r + rPlane;
        b = g + rPlane;
    
        /* FOR WINDOWS: BGR rather then RGB */
        {
           unsigned char HUGE *tmp;

            tmp = r;
            r = b;
            b = tmp;
        }
        while (count--) {
            register unsigned char  yv = *y, c1v = *c1, c2v = *c2;

            RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*			use lut
            *r = clamped(rv);
            *g = clamped(gv);
            *b = clamped(bv);
*/
			*r = MAPTHROUGHLUT(rv); 
	        *g = MAPTHROUGHLUT(gv); 
	        *b = MAPTHROUGHLUT(bv);
            r += rCol;
            g += rCol;
            b += rCol;
            y += yCol;
            c1+= yCol;
            c2+= yCol;
        }
    } else {
        obase = r;
        rx = 0;
        gx =  rx + rPlane;
        bx =  gx + rPlane;
 
        /* FOR WINDOWS: BGR rather then RGB */
        {
            unsigned long tmp;

            tmp = rx;
            rx = bx;
            bx = tmp;
        }
 
        if (fitsInSegment(y, count, yCol) && 
            fitsInSegment(c2, count, yCol) &&
            fitsInSegment(c2, count, yCol) && 
            _FP_SEG(y) == _FP_SEG(c1) && _FP_SEG(c1) == _FP_SEG(c2)) {
            unsigned char FAR *ibase;
            unsigned short yx, c1x, c2x;

            yx = _FP_OFF(y);
            c1x = _FP_OFF(c1);
            c2x = _FP_OFF(c2);
            ibase = y - yx;

            while (count--) {
                register unsigned char  yv, c1v, c2v;

                yv = ibase[yx];
                c1v = ibase[c1x];
                c2v = ibase[c2x];
                RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
 /* 			use lut
                obase[rx] = clamped(rv);
                obase[gx] = clamped(gv);
                obase[bx] = clamped(bv);
*/
				obase[rx] = MAPTHROUGHLUT(rv); 
		        obase[gx] = MAPTHROUGHLUT(gv); 
		        obase[bx] = MAPTHROUGHLUT(bv);
                rx += rCol;
                gx += rCol;
                bx += rCol;
                yx += yCol;
                c1x+= yCol;
                c2x+= yCol;
            }
        } else {
            while (count--) {
                register unsigned char  yv = *y, c1v = *c1, c2v = *c2;

                RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*				use lut
                obase[rx] = clamped(rv);
                obase[gx] = clamped(gv);
                obase[bx] = clamped(bv);
*/
				obase[rx] = MAPTHROUGHLUT(rv); 
		        obase[gx] = MAPTHROUGHLUT(gv); 
		        obase[bx] = MAPTHROUGHLUT(bv);
                rx += rCol;
                gx += rCol;
                bx += rCol;
                y  += yCol;
                c1 += yCol;
                c2 += yCol;
            }
        }
    } 
    return(0);
}

/*
 * YCC to RGB convertor which
 * expects uninterpolated chroma.
 */
PCDstatus 
PCDxiYCCtoRGB(  PCDRAWDATA  ybase,
                PCDRAWDATA  c1base,  
                PCDRAWDATA  c2base, 
                int         yCol,
                PCDRAWDATA  obase, 
                long        rPlane, 
                long        rCol, 
                long        count, 
                BOOL        replicateLast )
{
    long                        r, g, b;
    int                         rv, gv, bv;
    unsigned char               yv, c1v, c2v;
    unsigned char               nc1v, nc2v;
    unsigned short              iv;
    long                        yAsLong = (long)ybase;
    BOOL                        odd     = (BOOL) (yAsLong & 1);
    const _segment              oseg    = _FP_SEG(obase);
    const _segment              iseg    = _FP_SEG(ybase);
    unsigned char _based(void)  *y      = 0;
    unsigned char _based(void)  *c1     = 0;
    unsigned char _based(void)  *c2     = 0;

    y += _FP_OFF(ybase);
    c1 += _FP_OFF(c1base);
    c2 += _FP_OFF(c2base);

    r = 0;
    g = rPlane;
    b = g + rPlane;
 
    /* FOR WINDOWS: BGR rather then RGB */
    {
        long tmp;

        tmp = r;
        r = b;
        b = tmp;
    }
 

    if (odd) {
        c1v = *(iseg:>c1);;
        c2v = *(iseg:>c2);
    } else {
        nc1v = *(iseg:>c1);
        nc2v = *(iseg:>c2);
    }

    if (!odd && fitsInSegment(obase, count, rCol)) {
        unsigned char _based(void) *rp = 0;
        unsigned char _based(void) *gp = 0;
        unsigned char _based(void) *bp = 0;

        rp += r + _FP_OFF(obase);
        gp += g + _FP_OFF(obase);
        bp += b + _FP_OFF(obase);

        cvtytor2(iseg, (unsigned short _based(void) *) y, c1, c2, oseg, rp, 
                            gp, bp, rCol, count, odd, replicateLast);
    } else {
        while (count--) {
            yv = *(iseg:>y);

            if (odd && (count || !replicateLast)) {
                c1 += yCol;
                c2 += yCol;
                nc1v = *(iseg:>c1);
                nc2v = *(iseg:>c2);
                /* Interpolate, rounding up */
                if ((iv = c1v + nc1v) & 1)
                    iv++;
                c1v = iv >> 1;
                if ((iv = c2v + nc2v) & 1)
                    iv++;
                c2v = iv >> 1;
            } else {
                c1v = nc1v;
                c2v = nc2v;
            }
            odd = !odd;

            RGBFROMYCC(rv, gv, bv, yv, c1v, c2v);
/*			use lut
            obase[r] = clamped(rv);
            obase[g] = clamped(gv);
            obase[b] = clamped(bv);
*/
            obase[r] = MAPTHROUGHLUT(rv); 
		    obase[g] = MAPTHROUGHLUT(gv); 
		    obase[b] = MAPTHROUGHLUT(bv);
			r += rCol;
            g += rCol;
            b += rCol;
            y += yCol;
        }
    }
    return (0);
}

/* 
 * Copies YCC in raw form (unexpanded chroma) to user buffer.
 */
PCDstatus PCDxiYCCtoYCC(PCDRAWDATA  y, 
                        PCDRAWDATA  c1,
                        PCDRAWDATA  c2, 
                        int         yCol, 
                        PCDRAWDATA  yo, 
                        long        yoPlane, 
                        long        yoCol, 
                        long        count,
                        BOOL        replicateLast )
{
    unsigned char HUGE *c1o, HUGE *c2o;
    long yAsLong = (long)y;
    BOOL odd = (BOOL) (yAsLong & 1);
    unsigned short c1sv, c2sv;

    c1o = yo + yoPlane;
    c2o = c1o + yoPlane;

    if (odd) {
        c1sv = *(unsigned short FAR *)c1;
        c2sv = *(unsigned short FAR *)c2;
        goto oddStart;
    }

    for (;;) {
        *yo = *y;

        c1sv = *(unsigned short FAR *)c1;
        *c1o = c1sv & 0xff;
        c2sv = *(unsigned short FAR *)c2;
        *c2o = c2sv & 0xff;

        if (--count == 0)
            break;
        yo += yoCol;
        c1o += yoCol;
        c2o += yoCol;
        y += yCol;

oddStart:
        *yo = *y;

/* last time? replicate */
        if (--count != 0 || !replicateLast) {
            register unsigned short iv;

            iv = c1sv & 0xff;
            iv += c1sv >> 8;
            if (iv & 1) iv++;
            *c1o = (unsigned char)(iv >> 1);

            iv = c2sv & 0xff;
            iv += c2sv >> 8;
            if (iv & 1) iv++;
            *c2o = (unsigned char)(iv >> 1);
        } else {
            *c1o = c1sv & 0xff;
            *c2o = c2sv & 0xff;
        }
        if (count == 0)
            break;

        yo += yoCol;
        c1o += yoCol;
        c2o += yoCol;
        y += yCol;
        c1 += yCol;
        c2 += yCol;
    }
    return (0);
}

/*
 * Converts YCC to palette indices (internal version)
 */
PCDstatus 
PCDiYCCtoPalette(   PCDRAWDATA      y, 
                    PCDRAWDATA      c1, 
                    PCDRAWDATA      c2, 
                    int             yCol, 
                    long            rCol, 
                    PCDRAWDATA      p, 
                    long            lcount, 
                    PCDpaletteHdl   hPal )
{
    PCDpalettePtr pp;
    static int one = 1;
    unsigned int thisr;
    unsigned int thisg;
    unsigned int thisb;
    unsigned int nextr;
    unsigned int nextg;
    unsigned int nextb;
    unsigned int count = (unsigned int) lcount;
    int FAR *vec;
    BOOL doFloyd = FALSE;

    paramck(hPal);
    HANDLETOPOINTER(hPal, pp, PCDpalettePtr);
    paramck(pp);
    if (pp->type == LUT_PAL && pp->hLUT) {
        pp->lut = GlobalLock(pp->hLUT);
        paramck(pp->lut); /*XXX - ENOMEM?*/
    }
    if (!pp->errdiff) {
        one = 1;
        goto nofloyd;
    }

    doFloyd = TRUE;
    if (pp->lineLength != (int) count) {
        long    size = 3L * (count * 12L + 128);

        one = 1;
        pp->lineLength = (int) count;
        if (pp->hErrDiff) {
            GlobalUnlock(pp->hErrDiff);
            GlobalFree(pp->hErrDiff);
        }
        pp->hErrDiff = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, size);
    }
    paramck(pp->hErrDiff); /*XXX*/
    if (one > 0) {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        thisr = 0;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        nextr = thisb + count + 2;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;
    } else {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        nextr = 0;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;

        thisr = nextb + count + 2;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        thisr += count - 1; thisg += count - 1; thisb += count - 1;
        nextr += count - 1; nextg += count - 1; nextb += count - 1;

        y  += yCol * (count - 1); 
        c1 += yCol * (count - 1);
        c2 += yCol * (count - 1);
        p += rCol * (count - 1);
        rCol = -rCol;
    }
nofloyd:
    
    doPalette(pp, y, c1, c2, yCol, p, rCol, 
            vec,
            thisr, thisg, thisb, 
            nextr, nextg, nextb, 
            one, lcount, TRUE);

    if (pp->type == LUT_PAL && pp->hLUT) {
        GlobalUnlock(pp->hLUT);
        pp->lut = 0;
    }
    if (doFloyd) {
        if (pp->hErrDiff) 
            GlobalUnlock(pp->hErrDiff);
        one = -one;
    }
    return (pcdSuccess);
}

/*
 * Takes uninterpolated chroma.
 */

PCDstatus 
PCDxiYCCtoPalette(  PCDRAWDATA      y, 
                    PCDRAWDATA      c1, 
                    PCDRAWDATA      c2, 
                    int             yCol, 
                    long            rCol, 
                    PCDRAWDATA      p, 
                    long            lcount, 
                    PCDpaletteHdl   hPal, 
                    BOOL            replicateLast )
{
    PCDpalettePtr pp;
    static int one = 1;
    unsigned int thisr;
    unsigned int thisg;
    unsigned int thisb;
    unsigned int nextr;
    unsigned int nextg;
    unsigned int nextb;
    unsigned int count = (unsigned int) lcount;
    int FAR *vec;
    BOOL doFloyd = FALSE;

    paramck(hPal);
    HANDLETOPOINTER(hPal, pp, PCDpalettePtr);
    paramck(pp);
    if (pp->type == LUT_PAL && pp->hLUT) {
        pp->lut = GlobalLock(pp->hLUT);
        paramck(pp->lut); /*XXX - ENOMEM?*/
    }
    if (!pp->errdiff) {
        one = 1;
        goto nofloyd;
    }

    doFloyd = TRUE;
    if (pp->lineLength != (int) count) {
        WORD    size = (WORD) (3L * ((long) count * 12L + 128));

        one = 1;
        pp->lineLength = (int) count;
        if (pp->hErrDiff) {
            GlobalUnlock(pp->hErrDiff);
            GlobalFree(pp->hErrDiff);
        }
        pp->hErrDiff = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, size);
    }
    paramck(pp->hErrDiff); /*XXX*/
    if (one > 0) {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        thisr = 0;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        nextr = thisb + count + 2;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;
    } else {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        nextr = 0;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;

        thisr = nextb + count + 2;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        thisr += count - 1; thisg += count - 1; thisb += count - 1;
        nextr += count - 1; nextg += count - 1; nextb += count - 1;

        y  += yCol * (count - 1); 
        c1 += yCol * (count / 2);
        c2 += yCol * (count / 2);
        p += rCol * (count - 1);
        rCol = -rCol;
    }
nofloyd:
    
    if (pp->type == OCTREE_PAL) {
        HANDLE hCtab; /*XXX - never freed*/
        if (!pp->colorTable) {
            if (ALLOCCOLORTABLE(pp->colorTable, hCtab) == 0)
                return(ENOMEM);
             oqInitColorTable(pp, pp->base, 0);
        }
    }
    doXPalette(pp, y, c1, c2, yCol, p, rCol, 
            vec,
            thisr, thisg, thisb, 
            nextr, nextg, nextb, 
            one, lcount, TRUE, replicateLast);

    if (pp->type == LUT_PAL && pp->hLUT) {
        GlobalUnlock(pp->hLUT);
        pp->lut = 0;
    }
    if (doFloyd) {
        if (pp->hErrDiff) 
            GlobalUnlock(pp->hErrDiff);
        one = -one;
    }
    return (pcdSuccess);
}

/*
 *  Photo YCC to palette indices
 */
PCDstatus 
FAR PASCAL PCDYCCtoPalette( PCDRAWDATA      y, 
                            long            yPlane, 
                            short           yCol, 
                            PCDRAWDATA      r, 
                            long            count, 
                            PCDpaletteHdl   hPal )
{
    unsigned char HUGE *c1, HUGE *c2;

    paramck(y);
    paramck(r);
    paramck(yPlane);
    paramck(yCol);
    c1 = y  + yPlane;
    c2 = c1 + yPlane;
    return(PCDiYCCtoPalette(y, c1, c2, (int) yCol, (long) 1, r, count, hPal));
}

/*
 * Internal version: converts RGB to palette indices.
 */
PCDstatus 
PCDiRGBtoPalette(   PCDRAWDATA      r, 
                    PCDRAWDATA      g, 
                    PCDRAWDATA      b, 
                    int             yCol, 
                    long            rCol, 
                    PCDRAWDATA      p, 
                    long            lcount, 
                    PCDpaletteHdl   hPal )
{
    PCDpalettePtr pp;
    static int one = 1;
    unsigned int thisr;
    unsigned int thisg;
    unsigned int thisb;
    unsigned int nextr;
    unsigned int nextg;
    unsigned int nextb;
	unsigned int count = (unsigned int) lcount;
    int FAR *vec;
    BOOL doFloyd = FALSE;

    paramck(hPal);
    HANDLETOPOINTER(hPal, pp, PCDpalettePtr);
    paramck(pp);
    if (pp->type == LUT_PAL && pp->hLUT) {
        pp->lut = GlobalLock(pp->hLUT);
        paramck(pp->lut); /*XXX - ENOMEM?*/
    }
    if (!pp->errdiff) {
        one = 1;
        goto nofloyd;
    }

    doFloyd = TRUE;
    if (pp->lineLength !=  (int) count) {
        long    size = 3L * (count * 12L + 128);

        one = 1;
        pp->lineLength = (int) count;
        if (pp->hErrDiff) {
            GlobalUnlock(pp->hErrDiff);
            GlobalFree(pp->hErrDiff);
        }
        pp->hErrDiff = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, size);
    }
    paramck(pp->hErrDiff); /*XXX*/
    if (one > 0) {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        thisr = 0;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        nextr = thisb + count + 2;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;
    } else {
        vec = (int FAR *)(GlobalLock(pp->hErrDiff) + 4);
        paramck(vec); /*XXX*/
        nextr = 0;
        nextg = nextr + count + 2;
        nextb = nextg + count + 2;

        thisr = nextb + count + 2;
        thisg = thisr + count + 2;
        thisb = thisg + count + 2;

        thisr += count - 1; thisg += count - 1; thisb += count - 1;
        nextr += count - 1; nextg += count - 1; nextb += count - 1;

        r += yCol * (count - 1); 
        g += yCol * (count - 1);
        b += yCol * (count - 1);
        p += rCol * (count - 1);
        rCol = -rCol;
    }
nofloyd:
    
    doPalette(pp, r, g, b, yCol, p, rCol, 
            vec,
            thisr, thisg, thisb, 
            nextr, nextg, nextb, 
            one, lcount, FALSE);

    if (pp->type == LUT_PAL && pp->hLUT) {
        GlobalUnlock(pp->hLUT);
        pp->lut = 0;
    }
    if (doFloyd) {
        if (pp->hErrDiff) 
            GlobalUnlock(pp->hErrDiff);
        one = -one;
    }
    return (pcdSuccess);
}

/*
 * External version: converts RGB to palette indices.
 */
PCDstatus FAR PASCAL
PCDRGBtoPalette(    PCDRAWDATA      r, 
                    long            rPlane, 
                    short           rCol, 
                    PCDRAWDATA      p, 
                    long            count, 
                    PCDpaletteHdl   hPal )

{
    unsigned char HUGE *g, HUGE *b;

    paramck(r);
    paramck(p);
    paramck(rPlane);
    paramck(rCol);
    g = r + rPlane;
    b = g + rPlane;
 
    /* FOR WINDOWS: BGR rather then RGB */
    {
        unsigned char HUGE *tmp;

        tmp = r;
        r = b;
        b = tmp;
    }
 
    return(PCDiRGBtoPalette(r, g, b, (int) rCol, (long) 1, p, count, hPal));
}


/* Compute DIB header color table */
void
setUpPalette(PCDformat fmt, PCDpaletteHdl hpal, RGBQUAD FAR *pal)
{
    if (fmt == PCD_RGB) {
        make332Palette(pal);
    } else if (fmt == PCD_SINGLE) {
        makeGrayPalette(pal, 256);
    } else if (fmt == PCD_PALETTE) {
        WORD            ncolors = 256;
        PCDpalettePtr   pp;

        if (hpal && HANDLETOPOINTER(hpal, pp, PCDpalettePtr) &&
                pp->type == OCTREE_PAL) {
            pp->colorTable = pal;
            oqInitColorTable(pp, pp->base, 0);
        } else if (pp && pp->type == LUT_PAL) {
            int i;

/* Copy palette info to DIB, converting to RGB if need be */
            for (i = 0; i < pp->ncolors; i++) {
                if (pp->RGBpalette) {
                    pal[i] = pp->pal[i];
                } else {
                    int rv, gv, bv;
                    unsigned char   y = pp->pal[i].rgbRed,
                                    c1 = pp->pal[i].rgbGreen,
                                    c2 = pp->pal[i].rgbBlue;

                    rv = RFROMYCC(y, c1, c2);
                    gv = GFROMYCC(y, c1, c2);
                    bv = BFROMYCC(y, c1, c2);
                   	/* use lut instead; (3-11-93)
                    clamp(rv);
                    clamp(gv);
                    clamp(bv);
                    pal[i].rgbRed = rv;
                    pal[i].rgbGreen = gv;
                    pal[i].rgbBlue = bv;
					*/
					pal[i].rgbRed = MAPTHROUGHLUT(rv);
					pal[i].rgbGreen = MAPTHROUGHLUT(gv);
					pal[i].rgbBlue = MAPTHROUGHLUT(bv);

                    pal[i].rgbReserved = 0;
                }
            }
        } else
            make332Palette(pal);

        if (pp && hpal)
            RELEASEHANDLE(hpal);
    }
}

/* 
 * Internal function used to set up a PCDpalette.
 * Called by PCDcreatePalette().
 */
PCDstatus
buildpal(   PCDpalettePtr    p, 
            PCDRAWDATA      pal, 
            long            planeBytes, 
            short           colBytes,
            HANDLE          hLUT, 
            int             ncolors, 
            BOOL            RGBquant, 
            BOOL            RGBpalette, 
            BOOL            errdiff,
            short           rbits, 
            short           gbits, 
            short           bbits )
{
    PCDstatus   rv = pcdSuccess;

    if (rbits < 0 || gbits < 0 || bbits < 0) 
        return(pcdBadParam);
    if (rbits == 0 && gbits == 0 && bbits == 0)
        return(pcdBadParam);

    p->quick332 = FALSE;
    p->ncolors = ncolors;
    p->RGBquant = RGBquant;
    p->RGBpalette = RGBpalette;
    if (p->errdiff = errdiff) {
        if (ncolors <= 16) {
            p->randdiff = FALSE;
            p->randthresh = FALSE;
        } else {
            p->randdiff = FALSE;
            p->randthresh = FALSE;
        }
    }

    if (!hLUT) {
        p->ownLUT = TRUE;
        if ((p->hLUT = GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
                                    1 << (rbits + gbits + bbits))) == 0) {
            rv = ENOMEM;
            goto bad;
        }
    } else {
        p->ownLUT = FALSE;
        p->hLUT = hLUT;
    }
    if ((p->lut = GlobalLock(p->hLUT)) == 0) {
        rv = ENOMEM;
        goto bad;
    }


    p->rshift = 8 - rbits - gbits - bbits;
    p->gshift = 8 - gbits - bbits;
    p->bshift = 8 - bbits;

    p->rmask = ((1 << rbits) - 1) << (gbits + bbits);
    p->gmask = ((1 << gbits) - 1) << bbits;
    p->bmask = (1 << bbits) - 1;

    if (pal) {
/* Copy in palette data from user */
        PCDRAWDATA  r, g, b;
        int         i;

        r = pal;
        g = r + planeBytes;
        b = g + planeBytes;

        for (i = 0; i < ncolors; i++) {
            p->pal[i].rgbReserved = 0;
            p->pal[i].rgbRed = *r;
            p->pal[i].rgbGreen = *g;
            p->pal[i].rgbBlue = *b;
            r += colBytes;
            g += colBytes;
            b += colBytes;
        }
    } else {
/* Compute palette data */
        make332Palette(p->pal);
/* Override defaulting args */
        p->ncolors = ncolors = 256;
        p->RGBpalette = RGBpalette = TRUE;

        if (rbits == 3 && gbits == 3 && bbits == 2)
            p->quick332 = TRUE;
    }
 
    if (p->ownLUT) {
/* No user-supplied lookup table: compute nearest matches */
        unsigned long 
            mindiff, thisdiff;
        long    rd, gd, bd; 
        int bestfit;
        int x = 0;
        int r, g, b;
        int nr, ng, nb;
        int rstep, gstep, bstep;
        int rlim, glim, blim;

        if (rbits > 0) {
            rlim = 1 << rbits; 
            rstep = rlim - 1;
        } else
            rlim = rstep = 1;
        if (gbits > 0) {
            glim = 1 << gbits; 
            gstep = glim - 1;
        } else
            glim = gstep = 1;
        if (bbits > 0) {
            blim = 1 << bbits; 
            bstep = blim - 1;
        } else
            blim = bstep = 1;

        for (nr = 0; nr < rlim; nr++) {
            r = (255 * nr) / rstep;
            for (ng = 0; ng < glim; ng++) {
                if (gbits > 0)
                    g = (255 * ng) / gstep;
                else
                    g = r;
                for (nb = 0; nb < blim; nb++) {
                    int i;

                    if (p->quick332) {
                        bestfit = x;
                        goto fill_lut;
                    }
                    if (bbits > 0)
                        b = (255 * nb) / bstep;
                    else
                        b = r;

                    bestfit = 0;
                    mindiff = (unsigned long) ~0;
                    for (i = 0; i < p->ncolors; i++) {
                        rd = p->pal[i].rgbRed - r;
                        gd = p->pal[i].rgbGreen - g;
                        bd = p->pal[i].rgbBlue - b;
                        thisdiff = rd * rd + gd * gd + bd * bd;
                        
                        if (thisdiff < mindiff) {
                            mindiff = thisdiff;
                            bestfit = i;
                            if (thisdiff == 0)
                                break;
                        }
                    }
fill_lut:
                    p->lut[x++] = bestfit;
                }
            }
        }
    }
 
    return(pcdSuccess);

bad:
    if (p) {
        if (p->ownLUT && p->hLUT) {
            if (p->lut)
                GlobalUnlock(p->hLUT);
            GlobalFree(p->hLUT);
        }
    }
    return(rv);
}


/*
 * Create a data structure (PCDpalette) describing 
 * a method of color reduction.
 */
PCDstatus FAR PASCAL 
PCDcreatePalette(   
    /*\
     *  These 4 parameters define the target colors for reduction. lpPal
     *  points to the first component of the first color; lPlaneBytes and
     *  nColumnBytes define how to find the rest. If lpPal is NULL, 
     *  the list of colors is computed by the toolkit.
    \*/
        unsigned char FAR   *lpPal, 
        long        lPlaneBytes,
        short       nColumnBytes, 
        short       nColors,    

    /*\
     *  Handle to optional lookup table of indices into above
     *  palette, indexed by bits of color components.
     *  Calculated by default from target colors and component bits.
    \*/
        HANDLE      hLUT, 

        short       nComp1bits,     /* Number of bits of each color component */                
        short       nComp2bits,     /* ... used to form index into LUT */
        short       nComp3bits,
        BOOL        bRGBquant,      /* Use RGB components for indexing LUT - else YCC */
        BOOL        bRGBpalette,    /* Interpret palette as RGB values - otherwise YCC */
        BOOL        bDoErrDiff,     /* Perform Floyd-Steinberg error diffusion */
        PCDpaletteHdl FAR *lphPal ) /* Handle to resulting "PCD palette" */
{
    PCDpalettePtr p = 0;
    PCDstatus   rv;

    paramck(lphPal);
    *lphPal = GlobalAlloc(GMEM_ZEROINIT, sizeof(PCDpalette));
    if (!*lphPal) 
        return(ENOMEM);
    if (!HANDLETOPOINTER(*lphPal, p, PCDpalettePtr)) {
        GlobalFree(*lphPal);
        return(ENOMEM);
    }
    p->type = LUT_PAL;
    p->refCnt = 1;
    p->lineLength = 0;
    p->hErrDiff = 0;
    p->hDLL = 0;

    rv = buildpal(p, lpPal, lPlaneBytes, nColumnBytes, hLUT, nColors, 
                    bRGBquant, bRGBpalette, bDoErrDiff, 
                    nComp1bits, nComp2bits, nComp3bits);

    RELEASEHANDLE(*lphPal);
    return(rv);
}

/*
 * Deallocate resources associated with a PCDpalette.
 */
PCDstatus FAR PASCAL
PCDfreePalette(PCDpaletteHdl hPal)
{
    PCDpalettePtr   pp;

    paramck(hPal);
    HANDLETOPOINTER(hPal, pp, PCDpalettePtr);
    paramck(pp);

    if (pp->type == OCTREE_PAL) {
/*XXX - incomplete*/
        RELEASEHANDLE(hPal);
        oqFree(hPal);
        return(pcdSuccess);
    }
    if (--pp->refCnt > 0) {
        RELEASEHANDLE(hPal);
        return(pcdSuccess);
    }
    if (pp->hDLL >= 32)
        FreeLibrary(pp->hDLL);
    if (pp->hLUT && pp->ownLUT) 
        FREEHANDLE(pp->hLUT);
	if (pp->hErrDiff) 
	{
	    GlobalUnlock(pp->hErrDiff);
	    GlobalFree(pp->hErrDiff);
	}
	RELEASEHANDLE(hPal);
	FREEHANDLE(hPal);
	return(pcdSuccess);
}

/*
 * Increment the reference count on a PCDpalette.
 */
void incPalRef(PCDpaletteHdl hPal)
{
    PCDpalettePtr   pp;

    if (!hPal)
        return;
    HANDLETOPOINTER(hPal, pp, PCDpalettePtr);
    if (!pp)
        return;

    pp->refCnt++;
    RELEASEHANDLE(hPal);
}
