/*
 * �TS4,8,12,16,20,24,28,32�
 *      Photo CD Development Toolkit
 *
 *      Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *      All rights reserved.
 */
/* replace me before releasing source */
#define PCD(X)  pcd->X
#define PCDH(X) pcdh->X

#ifdef  IDENT
#ident  "@(#)huff.c     1.90 - 92/06/03"
#endif

#include <windows.h>
#include <errno.h>
#include <assert.h>
#include <dos.h>
#include <string.h>

#define PCDFILE_PRIVATE
#include "pcdlib.h"
#include "pcdpriv.h"
#include "rectcalc.h"
#include "pcdovw.h"
#include "util.h"
#include "secbuf.h"
#include "pcdcbf.h"

#define GET_SECBUF      seccnt = pcd->seccnt; secptr = pcd->secptr
#define SAVE_SECBUF     pcd->seccnt = seccnt; pcd->secptr = secptr
#define GETABYTE(cnt, ptr, p)   getabyte(cnt, ptr, p)

void PCDnewColorFormat(PCDphotoPtr pcd, LPRECT r, unsigned char HUGE *ybuf,
        unsigned char HUGE *c1buf, unsigned char HUGE *c2buf,
        unsigned char HUGE *buffer, short colbytes);
/*
 *      Decoding of Huffman-compressed residuals.  The routines beginning with
 *      PCDH implement a generic interface to the encoding scheme.  Higher-level
 *      routines are responsible for positioning the file pointer at the
 *      beginning of line data (as necessary).
 */

/* #define      HUFFDEBUG       1 */

/*
 * Entry in lookup decode table. Indexed by 12-bit, left justified
 * code (likely with portions of next code in low order bits).
 */

struct hufftab {
	    signed char     value;
        unsigned char   length;
#ifdef HUFFDEBUG
        unsigned char   valid;
        unsigned char   fill; /* length of huge arrays must be even power of 2 */
#endif
};

static short Masks[17] = {
        0x0,    0x1,    0x3,    0x7,
        0xf,    0x1f,   0x3f,   0x7f,
        0xff,   0x1ff,  0x3ff,  0x7ff,
        0xfff,  0x1fff, 0x3fff, 0x7fff,
        0xffff
};

/* Max length of the on-disk codebook */
#define DCODELEN                1024
/* Largest valid code length */
/* #define      MAX_CODE_LENGTH 16  not a constant; replaced by max_huff_length */
/* 2 to the MAX_CODE_LENGTH */
/* #define MAX_CODES       65536L */

/* State variables for huffman decoding */
#define HUFFVARS \
        unsigned short  s0, s1; \
        unsigned short  decodeIndex; \
        short           codeLength; \
        short           leftBits; \
        BOOL            gotNext


/*
 * Encapsulation of huffman decoding state.
 */
typedef struct {
        PCDphotoPtr    pcd;
        PCDphotoHdl    hpcd;
        HUFFVARS;
        short max_huff_length; /* max no bits in huff code */ 
        struct hufftab HUGE *htabPtr;
        long nfails; /*XXX*/
} PCDHstateRec, FAR *PCDHstatePtr;
typedef HANDLE PCDHstateHdl;

#define PCDHASSIGN(dst, src) \
        dst->s0 = src->s0; \
        dst->s1 = src->s1; \
        dst->decodeIndex = src->decodeIndex; \
        dst->codeLength = src->decodeIndex; \
        dst->leftBits = src->leftBits; \
        dst->gotNext = src->gotNext

#define LOAD_HUFFVARS \
        s0 = PCDH(s0); \
        s1 = PCDH(s1); \
        decodeIndex = PCDH(decodeIndex); \
        codeLength = PCDH(codeLength); \
        leftBits = PCDH(leftBits); \
        gotNext = PCDH(gotNext)

#define STORE_HUFFVARS \
        PCDH(s0) = s0; \
        PCDH(s1) = s1; \
        PCDH(decodeIndex) = decodeIndex; \
        PCDH(codeLength) = codeLength; \
        PCDH(leftBits) = leftBits; \
        PCDH(gotNext) = gotNext


/*
 * Moves past current code in input stream. After this macro is invoked,
 * the next code is left justified in low order 12 bits of decodeIndex.
 */
#ifndef SERIOUS_HUFFDEBUG
#define SKIP_TO_NEXT_BITSTRING() \
{ \
        leftBits += codeLength; \
        if (leftBits >= 16) { \
                leftBits -= 16; \
                if (gotNext) { \
                        gotNext = FALSE; \
                        s0 = s1; \
                } else { \
                        s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff); \
                        s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s0 << 8); \
                } \
        } \
        if (leftBits <= rump) { \
                decodeIndex = (s0 >> (4 - leftBits)) & Masks[16 - rump]; \
        } else { \
                decodeIndex = (s0 & Masks[16 - leftBits]) << (leftBits - rump); \
                if (!gotNext) { \
                        s1 = (GETABYTE(seccnt,secptr,pcd) & 0xff); \
                        s1 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s1 << 8); \
                        gotNext = TRUE; \
                } \
                decodeIndex |= (s1 >> (16 + rump -leftBits)) & Masks[leftBits-rump]; \
        } \
}
#else
#define SKIP_TO_NEXT_BITSTRING() \
STORE_HUFFVARS; \
snb(pcdh, pcd); \
LOAD_HUFFVARS

void
snb(PCDHstatePtr pcdh, PCDphotoPtr pcd)
{
        short rump = 16 - pcdh->max_huff_length;

        HUFFVARS;

        LOAD_HUFFVARS;
        leftBits += codeLength;
        if (leftBits >= 16) {
                leftBits -= 16;
                if (gotNext) {
                        gotNext = FALSE;
                        s0 = s1;
                } else { 
                        s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff);
                        s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s0 << 8);
                }
        }
        if (leftBits <= rump) {
                decodeIndex = (s0 >> (rump - leftBits)) & 0xfff;
        } else {
                decodeIndex = (s0 & Masks[16 - leftBits]) << (leftBits - rump);
                if (!gotNext) {
                        s1 = (GETABYTE(seccnt,secptr,pcd) & 0xff);
                        s1 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s1 << 8);
                        gotNext = TRUE;
                }
                decodeIndex |= (s1 >> (16 + rump - leftBits)) & Masks[leftBits -rump];
        }
        STORE_HUFFVARS;
}
#endif

PCDHstatePtr PCDHopenCompressor(PCDphotoPtr);
void PCDHcloseCompressor(PCDHstatePtr);
void PCDHpreDecode(PCDHstatePtr);
long PCDHdecode(PCDHstatePtr, signed char FAR *, long);
long PCDHskip(PCDHstatePtr, long);
/* Line Sequence number Type.
 * These definitions match
 * the raw on-disk values.
 */
typedef enum {
        LSTYPE_Y    = 0,
        LSTYPE_C1   = 2,
        LSTYPE_C2   = 3,
        LSTYPE_DNC = -1 /* impossible value: accept any of the above */
}       PCDlstype;

BOOL eateolline(PCDHstatePtr pcdh, short line, PCDlstype lstype);

void apply2(short syndrome, signed char FAR *src, signed char FAR *next, 
        unsigned char HUGE *dst, short srcRight, short dstLeft, short dstRight, 
        long colBytes);
/*
 *      Initialize a Huffman decoder.  The file pointer should be
 *      positioned at the beginning of the code table.
 */
PCDHstatePtr PCDHopenCompressor(PCDphotoPtr pcd)
{
	long i;
	unsigned short j;
    PCDHstatePtr pcdh;
    unsigned char HUGE *ibuf, HUGE *ip, HUGE *ip_temp;
    unsigned char length /* , decode */;
    unsigned short symbol, symbollim;
    signed char value;
    int nentries;
    short len, max_huff_length = 0;
    short rump; /* no. of bits left over in word */
    long max_codes; /* 2 raised to the |max_huff_length| power */
	
    pcdh = (PCDHstatePtr) PCDmalloc(sizeof (PCDHstateRec));
    if (pcdh == (PCDHstatePtr) 0)
        return ((PCDHstatePtr) 0);
    pcdh->htabPtr = NULL; /* init */
    PCDH(pcd) = pcd;
    PCDH(hpcd) = pcd->hpcd;
    ibuf = (unsigned char HUGE *) PCDmalloc(DCODELEN);
    if (ibuf == (unsigned char *) 0)
        goto botch;
        
    PCDreadSome(&pcd->iostate, ibuf, DCODELEN);
    
    ip = ibuf;
    nentries = *ip++ + 1;
    
    /* Set seek postion for reading next HQT */
    PCDsetMark(&pcd->iostate, -DCODELEN, 1); /* undo above read */
    PCDsetMark(&pcd->iostate, 1 + 4 * nentries, 1); /* just after this HQT */
    
    /* find actual max codelength for this table */
    for (ip_temp = ip, i = 0; i < nentries; i++, ip_temp += 4) {
         len = ip_temp[0] + 1;
         max_huff_length = (max_huff_length > len) ? max_huff_length : len;
    }
    pcdh->max_huff_length = max_huff_length;
    rump = 16 - max_huff_length; /* no. of bits left over in word */
    max_codes = 1L << max_huff_length;
    
    /* allocate table */
    pcdh->htabPtr = (struct hufftab HUGE *) 
    PCDmalloc(sizeof(struct hufftab) * max_codes);
    if (pcdh->htabPtr == (struct hufftab *) 0)
        goto botch;
    
    /*      Initialize table */
    for (i = 0; i < max_codes; i++) {
         PCDH(htabPtr[i].value) = 0;
         PCDH(htabPtr[i].length) = 1; /* Flag as invalid, prevent harm */
#ifdef  HUFFDEBUG
         PCDH(htabPtr[i].valid) = 0; /* Flag as invalid */
#endif
     }
     for (i = 0; i < nentries; i++) {
          length = ip[0] + 1;
          if (!length)
              break;
          /* Symbol is right justified in |max_huff_length| bits */
          symbol = ((((ip[1] & 0xff) << 8) | (ip[2] & 0xff)) >> 
	     		(rump + max_huff_length - length)) & Masks[length];
          value = ((signed char FAR *)ip)[3];  
          ip += 4;
#ifdef  HUFFDEBUG
          PCDH(htabPtr[symbol].valid) = 1;
#endif
          /* Make symbol left justified in |max_huff_length| bits. */
          symbol <<= max_huff_length - length;
           
           /* Numerically largest |max_huff_length|-bit value having |symbol|
              as its first |length| bits. */
          symbollim = symbol | ((1 << (max_huff_length - length)) - 1);
             
          for (j = 0; symbol + j <= symbollim; j++) {
              PCDH(htabPtr[symbol + j].length) = length;
              PCDH(htabPtr[symbol + j].value) = value;
          }
     } /* end for each huff code entry */
     PCDfree(ibuf);
         return (pcdh);
botch:
     if (ibuf != NULL)
         PCDfree(ibuf);
     if (pcdh->htabPtr != NULL)
         PCDfree( (unsigned char _huge *) pcdh->htabPtr);
     PCDfree((unsigned char _huge *) pcdh);
     return ((PCDHstatePtr) 0);
} /* end PCDHopenCompressor */

void PCDHcloseCompressor(PCDHstatePtr pcdh)
{
        if (pcdh->htabPtr != NULL)
                PCDfree((unsigned char _huge *) pcdh->htabPtr);
        RELEASEHANDLE(pcdh->hpcd);
        PCDfree((unsigned char _huge *) pcdh);
}

/*
 *      Setup state to begin decoding a run of residuals.
 */
void PCDHpreDecode(PCDHstatePtr pcdh)
{
        PCDH(s0) = 0;
        PCDH(s1) = 0;
        PCDH(decodeIndex) = 0;
        PCDH(codeLength) = 0;
        PCDH(leftBits) = 0;
        PCDH(gotNext) = FALSE; 
        PCDH(nfails) = 0; /*XXX*/
}

/* Turn up the optimization */
#pragma loop_opt(on)
#pragma optimize("z", on)
/*
 *      Decode residuals and apply to data
 *      in buf. Column bytes are respected.
 */
long PCDHapply(PCDHstatePtr pcdh, unsigned char HUGE* buf, 
        long colbytes, long count)
{
        int bufval;
        long xcount = 0;
        PCDphotoPtr pcd;
        int seccnt;
        unsigned char FAR *secptr;
        struct hufftab HUGE *htab;
        HUFFVARS;
        unsigned short huffmasks[17];
        int i;
        short rump, max_huff_length = pcdh->max_huff_length;
        long max_codes = 1L << max_huff_length;
        
        for (i = 0; i < 17; i++) huffmasks[i] = Masks[i];

        pcd = PCDH(pcd);
        LOAD_HUFFVARS;
        htab = pcdh->htabPtr;
        rump = 16 - max_huff_length; /* bits left over */
        GET_SECBUF;

#ifndef HUFFDEBUG
        /* use optimizations on (4096) old size tables */
        if ((fitsInSegment(buf, count, colbytes)) && (max_huff_length<=12)){
                static void FAR *dsptr = (void FAR *)&dsptr;
                unsigned char NEAR *nbuf = 0;
                unsigned short bufoff = _FP_OFF(buf), bufseg = _FP_SEG(buf);
                unsigned short dataseg = _FP_SEG(dsptr);

                nbuf += bufoff;

                _asm mov ds, bufseg
                while (xcount < count) {
                        codeLength = htab[decodeIndex].length;
                        bufval = *nbuf + htab[decodeIndex].value;
                        *nbuf = clamped(bufval);
                        nbuf += colbytes;
                        xcount++;
//                      SKIP_TO_NEXT_BITSTRING();
/* Code is in line to use huffmasks from stack, as data seg is not avail. */
{
        leftBits += codeLength; 
        if (leftBits >= 16) { 
                leftBits -= 16; 
                if (gotNext) { 
                        gotNext = FALSE; 
                        s0 = s1; 
                } else { 
                        s0 = GETABYTE(seccnt,secptr,pcd);
                        s0 = GETABYTE(seccnt,secptr,pcd) | (s0 << 8); 
                } 
        } 
        if (leftBits <= rump) { 
                decodeIndex = (s0 >> (rump - leftBits)) & huffmasks[16 - rump]; 
        } else { 
                decodeIndex = (s0 & huffmasks[16 - leftBits]) << (leftBits - rump); 
                if (!gotNext) { 
                        s1 = GETABYTE(seccnt,secptr,pcd); 
                        s1 = GETABYTE(seccnt,secptr,pcd) | (s1 << 8); 
                        gotNext = TRUE; 
                } 
                decodeIndex |= (s1 >> (16 + rump - leftBits)) & 
                        huffmasks[leftBits - rump]; 
        } 
}
                }
                _asm mov ds, dataseg
        } else 
#endif /* HUFFDEBUG */
        {
                while (xcount < count) {
                        codeLength = htab[decodeIndex].length;
#ifdef  HUFFDEBUG
		    	{
         			unsigned short  code = decodeIndex >> (max_huff_length - codeLength);

        			if (decodeIndex > max_codes)
                		goto botch;
        			if (code > max_codes)
                		goto botch;
        			if (htab[code].valid != 1)
               			goto botch;
        			if (codeLength < 1 || codeLength > max_huff_length) 
                		goto botch;
				}
#endif /* HUFFDEBUG */
                	bufval = *buf + htab[decodeIndex].value;
                	*buf = clamped(bufval);
               	 	buf += colbytes;
                	xcount++;
                	SKIP_TO_NEXT_BITSTRING();
                }
        }
        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (xcount);

botch:

        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (-1);
} /* end PCDHapply */

/*
 *      Decode a line of huffman-compressed residuals.
 */
long PCDHdecode(PCDHstatePtr pcdh, signed char FAR* buf, long count)
{
        long xcount = 0;
        PCDphotoPtr pcd;
        int seccnt;
        unsigned char FAR *secptr;
        struct hufftab HUGE *htab;
        short max_huff_length = pcdh->max_huff_length;
        short rump = 16 - max_huff_length;
        HUFFVARS;
        
        pcd = PCDH(pcd);
        LOAD_HUFFVARS;
        htab = pcdh->htabPtr;
        GET_SECBUF;

        while (xcount < count) {
                codeLength = htab[decodeIndex].length;
#ifdef  HUFFDEBUG
			{
       			unsigned short  code = decodeIndex >> (max_huff_length - codeLength);

        		if (code > max_codes)
                	goto botch;
        		if (htab[code].valid != 1)
                	goto botch;
        		if (codeLength < 1 || codeLength > max_huff_length) 
                	goto botch;
			}
#endif /* HUFFDEBUG */
                *buf++ = htab[decodeIndex].value;
                xcount++;
                SKIP_TO_NEXT_BITSTRING();
        }
        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (xcount);

botch:
        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (-1);
}                  

/*
 *      Skip over count bytes in the current row.
 */
long PCDHskip(PCDHstatePtr pcdh, long count)
{
        long xcount = 0;
        PCDphotoPtr pcd;
        int seccnt;
        unsigned char FAR *secptr;
        struct hufftab HUGE *htab;
        HUFFVARS;
        short max_huff_length = pcdh->max_huff_length;
        short rump = 16 - max_huff_length;
        long max_codes = 1L << max_huff_length;
        
        pcd = PCDH(pcd);
        LOAD_HUFFVARS;
        htab = pcdh->htabPtr;
        GET_SECBUF;

        while (xcount < count) {
                codeLength = htab[decodeIndex].length;
#ifdef  HUFFDEBUG
			{
        		unsigned short  code = decodeIndex >> (max_huff_length - codeLength);

        		if (code > max_codes)
                	goto botch;
        		if (htab[code].valid != 1)
                	goto botch;
        		if (codeLength < 1 || codeLength > max_huff_length) 
                	goto botch;
			}
#endif /* HUFFDEBUG */
                xcount++;
                SKIP_TO_NEXT_BITSTRING();
        }
        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (xcount);

botch:
        STORE_HUFFVARS;
        SAVE_SECBUF;
        return (-1);
} /* end PCDHskip  */


/* Reads and discards all data up to and including the
 * delimiter for the specified line.
 */
BOOL
eateolline(PCDHstatePtr pcdh, short line, PCDlstype lstype)
{
        PCDphotoPtr pcd;
        unsigned short  bit;
        unsigned short  s0, s1;
        unsigned short  code;
        short           ones;
        short           found;
        unsigned short  typeval;
        unsigned char codeLength;
        short   leftBits;
        unsigned short  decodeIndex;
        BOOL gotNext;
        BOOL rv = TRUE;
        long maxtries = 3072L * 3L; /* Generous maximum loop count */
        int seccnt;
		int i;
        unsigned char FAR *secptr;
        struct hufftab HUGE *htab = pcdh->htabPtr;
        short max_huff_length = pcdh->max_huff_length;
        short rump = 16 - max_huff_length;

        bit = ((unsigned short)1) << (15 - PCDH(leftBits));
        s0 = PCDH(s0);
        gotNext = PCDH(gotNext);
        s1 = PCDH(s1);
        pcd = PCDH(pcd);

        GET_SECBUF;
top:    
        if (--maxtries <= 0)
                return(FALSE);

        ones = 0;
        found = 0;

/* Look for line delimiter: 0xfffffe (23 1's followed by a 0) */
        while (!found) {
                if (bit == 0) {
                        if (gotNext) {
                                s0 = s1;
                                gotNext = !gotNext;
                        } else {
                                s0 = GETABYTE(seccnt,secptr,pcd) & 0xff;
                                s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s0 << 8);
                        }
                        bit = 0x8000;
                }
                if (s0 & bit) {
                /* Got a 1; no need to count higher than 23 */
                        if (ones < 23)
                                ones++;
                } else {
                /* Got a 0; if preceeded by 23 (or more) 1's, got a delimiter */
                        if (ones >= 23)
                                found++;
                        else
                                ones = 0;
                }
                bit >>= 1;
        }
/* Calculate line number: 
 * 4BASE:       15-bit line # followed by 1 zero bit
 * 16BASE:      2 type bits, 1 zero bit, 12-bit line #, zero bit
 */
        code = 0;
        typeval = 0;
        for (i = 0; i < 16; i++) {
                if (!bit) {
                        s0 = GETABYTE(seccnt,secptr,pcd) & 0xff;
                        s0 = (GETABYTE(seccnt,secptr,pcd) & 0xff) | (s0 << 8);
                        bit = 0x8000;
                }
                if (i == 0 || i == 1) {
                        typeval <<= 1;
                        if (s0 & bit)
                                typeval++;
                } else if (i > 2 && i < 15) {
                        code <<= 1;
                        if (s0 & bit)
                                code++;
                }
                bit >>= 1;
        }

/*
 * Repeat search if the line delimiter refers to a line
 * expected to appear before the desired one.
 */
        if (code < (unsigned short) line)
                goto top;
        if (code == (unsigned short) line && (lstype != LSTYPE_DNC && lstype != (PCDlstype) typeval))
                goto top;
/* This can happen for first few lines of chroma residuals:
 * LPT may point to a sector which contains the last Y line
 * in addition to the first C1 line.
 */
        if (code > (unsigned short) line && typeval == LSTYPE_Y && 
                        (lstype == LSTYPE_C1 || lstype == LSTYPE_C2))
                goto top;
        if (code == (unsigned short) line)
                rv = TRUE;
        else {
/* Should not happen */
                rv = FALSE; /* most heinous error here */
        }

        switch (bit) {
        case 0x8000:    leftBits =  0; break;
        case 0x4000:    leftBits =  1; break;
        case 0x2000:    leftBits =  2; break;
        case 0x1000:    leftBits =  3; break;
        case 0x0800:    leftBits =  4; break;
        case 0x0400:    leftBits =  5; break;
        case 0x0200:    leftBits =  6; break;
        case 0x0100:    leftBits =  7; break;
        case 0x0080:    leftBits =  8; break;
        case 0x0040:    leftBits =  9; break;
        case 0x0020:    leftBits = 10; break;
        case 0x0010:    leftBits = 11; break;
        case 0x0008:    leftBits = 12; break;
        case 0x0004:    leftBits = 13; break;
        case 0x0002:    leftBits = 14; break;
        case 0x0001:    leftBits = 15; break;
        case 0x0000:    leftBits = 16; break;
        }
        codeLength = 0;

        SKIP_TO_NEXT_BITSTRING();

        STORE_HUFFVARS;
        SAVE_SECBUF;

        return(rv);
} /* end eateolline */

/*
 *      Load a line pointer table for the given resolution.
 */
BOOL PCDloadLpt(PCDphotoPtr pcd, PCDresolution step)
{

        assert(step == PCD_4BASE || step == PCD_16BASE);
        if (step == PCD_4BASE) {
                /* XXX - shd use ipac offsets */
                PCDsetMark(&pcd->iostate, stob(387), 0);
                PCD(lpt4tv) = (short FAR *) PCDmalloc(512);
                if (PCD(lpt4tv) == (short FAR *) 0)
                        return (FALSE);
                PCDreadSome(&pcd->iostate, (char FAR *) PCD(lpt4tv), 512);
                swapshorts((unsigned char FAR *)PCD(lpt4tv), 512);
        } else {
                PCD(lpt16tv) = (short FAR *) PCDmalloc(4096);
                if (PCD(lpt16tv) == (short FAR *) 0)
                        return (FALSE);
                /* 1 ICA, 9 LPT-MRS */
                PCDsetMark(&pcd->iostate, PCD(pos16tv) + stob(10), 0); 
                PCDreadSome(&pcd->iostate, (char FAR *) PCD(lpt16tv), 4096);
                swapshorts((unsigned char FAR *)PCD(lpt16tv), 4096);
        }
        return (TRUE);
}

void
swapshorts(buf, count)
        unsigned char FAR *buf;
        int count;
{
        unsigned char tmp;

        assert(!(count % 2));
        while (count > 0) {
                tmp = *buf;
                *buf = *(buf + 1);
                *(buf + 1) = tmp;
                buf += 2;
                count -= 2;
        }
}

#define CHECK(X)        { if (X < 0) { theErr = pcdBadFmt; goto scram; } }

/*
 *      Apply 4BASE residuals to the luminance channel of the
 *      image stored in |buffer|.  |r| specifies the source
 *      crop region in the units of the final desired resolution
 *      step (4BASE or 16BASE).  If this step is 16BASE, the
 *      residuals are biliearly interpolated 2x onto the image.
 *
 */
PCDstatus PCDapply4TV(PCDphotoPtr pcd, LPRECT r, unsigned char HUGE *buffer,
  long colBytes, long stride)
{
        PCDHstatePtr pcdh = 0;
        long targsect;
        signed char FAR *residbuf, FAR *nresidbuf, FAR *tmpresidbuf;
        PCDstatus theErr;
        int line;       
        int first = 0;
        abortFuncPtr abortFunction = pcd->abort;
        progFuncPtr progFunction = pcd->check;

        if (PCD(lpt4tv) == (short FAR *) 0)
                PCDloadLpt(pcd, PCD_4BASE);
        /* XXX - shd use ipac offsets */
/* HQT (ICD ???) */
        PCDsetMark(&pcd->iostate, stob(388), 0);
        pcdh = PCDHopenCompressor(pcd);
        if (pcdh == (PCDHstatePtr) 0) {
                theErr = pcdBadFmt;
                goto scram;
        }
        if (PCDnewsecbuf(pcd) != pcdSuccess) {
                theErr = errno ? errno : ENOMEM;
                PCDHcloseCompressor(pcdh);
                goto scram;
        }
        pcd->iostate.throwInError = TRUE;
        if (Catch((LPCATCHBUF)pcd->iostate.catchbuf)) {
                theErr = EIO;
                goto scram;
        }
        if (PCD(step) == PCD_4BASE) {
                line = TopPixelInRect(r) & ~03;

                targsect = 384 + pcd->lpt4tv[line / 4];
                PCDflushbuf(pcd, stob(targsect));
                PCDHpreDecode(pcdh);

                for (; line <= BottomPixelInRect(r); line++) 
                {
                        if (PCDdoCallbacks(pcd))
							return (pcdUserAbort);			/*XXX - free resources*/
                        if (progFunction && line >= TopPixelInRect(r))
                                ++pcd->cNumerator;
                        if (!eateolline(pcdh, line, LSTYPE_DNC))
                                continue;
                        if (line < TopPixelInRect(r)) {
                                CHECK(PCDHskip(pcdh, rowsiz(PCD_4BASE)));
                        } else {
                                if (LeftPixelInRect(r) != 0)
                                        CHECK(PCDHskip(pcdh, (long) LeftPixelInRect(r)));
                                CHECK(PCDHapply(pcdh, buffer, colBytes, RectWidth(r)));
                                buffer += stride;
                        }
                }
        } else {
                assert(PCD(step) == PCD_16BASE);
                residbuf = PCDmalloc(2 * rowsiz(PCD_4BASE));
                nresidbuf = PCDmalloc(rowsiz(PCD_4BASE));
                if (nresidbuf == (char *) 0) {
                        theErr = errno;
                        if (residbuf != (char *) 0)
                                PCDfree(residbuf);
                        goto scram;
                }
                line = TopPixelInRect(r) & ~07;

                targsect = 384 + pcd->lpt4tv[line / 8];
                PCDflushbuf(pcd, stob(targsect));
                PCDHpreDecode(pcdh);

                for (; line <= BottomPixelInRect(r); line++) 
                {
						if( PCDdoCallbacks(pcd) )
                        	return (pcdUserAbort);/*XXX - free resources*/
                        if (progFunction && line >= TopPixelInRect(r))
                                ++pcd->cNumerator;
                        if (!(line & 01)) {
                                if (!first++) {
                                        if (!eateolline(pcdh, line / 2, LSTYPE_DNC))
                                                continue;
                                        CHECK(PCDHdecode(pcdh, residbuf, rowsiz(PCD_4BASE)));
                                        eateolline(pcdh, (line / 2) + 1, LSTYPE_DNC);
                                        CHECK(PCDHdecode(pcdh, nresidbuf, rowsiz(PCD_4BASE)));
                                } else {
                                        tmpresidbuf = residbuf;
                                        residbuf = nresidbuf;
                                        nresidbuf = tmpresidbuf;

                                        if (!eateolline(pcdh, (line / 2) + 1, LSTYPE_DNC))
                                                continue;
                                        CHECK(PCDHdecode(pcdh, nresidbuf, rowsiz(PCD_4BASE)));
                                }
                        }
                        if (line < TopPixelInRect(r))
                                continue;
                        else {
                                apply2(line & 01, residbuf, nresidbuf, buffer,
                                  rowsiz(PCD_BASE), LeftPixelInRect(r),
                                  RightPixelInRect(r) + 1, colBytes);
                                buffer += stride;
                        }
                }
                PCDfree(residbuf);
                PCDfree(nresidbuf);
        }
        PCDrelsesecbuf(pcd);
        PCDHcloseCompressor(pcdh);
        return (pcdSuccess);
scram:
        if (pcd) PCDrelsesecbuf(pcd);
        if (pcd) pcd->iostate.throwInError = FALSE;
        if (pcdh) PCDHcloseCompressor(pcdh);
        return (theErr);
}

PCDstatus PCDapply16TV(PCDphotoPtr pcd, LPRECT r, unsigned char HUGE *buffer, 
        long colBytes, long stride)
{
        PCDHstatePtr pcdhy, pcdhc1, pcdhc2;
        unsigned char HUGE *buffer2, HUGE *buffer3;
        int first = 0, single, line; 
        long targsect;
        long currsect = -1;
        PCDstatus theErr = pcdSuccess;
        signed char FAR *c1residbuf, FAR *c1nresidbuf; 
        signed char FAR *c2residbuf, FAR *c2nresidbuf;
        signed char FAR *tmpresidbuf;
        signed char FAR *b1 = 0, FAR *b2 = 0, FAR *b3 = 0, FAR *b4 = 0;
        abortFuncPtr abortFunction = pcd->abort;
        progFuncPtr progFunction = pcd->check;

        single = PCD(format) == PCD_SINGLE;
        if (!single) {
                if ((b1 = c1residbuf = PCDmalloc(rowsiz(PCD_16BASE) / 2)) == 0 ||
                    (b2 = c1nresidbuf = PCDmalloc(rowsiz(PCD_16BASE) / 2)) == 0 ||
                    (b3 = c2residbuf = PCDmalloc(rowsiz(PCD_16BASE) / 2)) == 0 ||
                    (b4 = c2nresidbuf = PCDmalloc(rowsiz(PCD_16BASE) / 2)) == 0) {
                        theErr = errno ? errno : ENOMEM; 
                        goto scram;
                }
        }
        if (PCD(lpt16tv) == (short FAR *) 0)
                PCDloadLpt(pcd, PCD_16BASE);
        PCDsetMark(&pcd->iostate, PCD(pos16tv) + stob(12), 0);
        pcdhy = PCDHopenCompressor(pcd);
        if (pcdhy == (PCDHstatePtr) 0) {
                theErr = pcdBadFmt;
                goto scram;
        }
        if (!single) {
                pcdhc1 = PCDHopenCompressor(pcd);
                pcdhc2 = PCDHopenCompressor(pcd);
                if (pcdhc2 == (PCDHstatePtr) 0) {
                        theErr = pcdBadFmt;
                        if (pcdhc1 != (PCDHstatePtr) 0)
                                PCDHcloseCompressor(pcdhc1);
                        PCDHcloseCompressor(pcdhy);
                        goto scram;
                }
                buffer2 = buffer + PCD(planeBytes);
                buffer3 = buffer2 + PCD(planeBytes);
        }
        if (PCDnewsecbuf(pcd) != pcdSuccess) {
                theErr = errno ? errno : ENOMEM; 
                PCDHcloseCompressor(pcdhy);
                if (!single) {
                        PCDHcloseCompressor(pcdhc1);
                        PCDHcloseCompressor(pcdhc2);
                }
                goto scram;
        }
        pcd->iostate.throwInError = TRUE;
        if (Catch((LPCATCHBUF)pcd->iostate.catchbuf)) {
                theErr = EIO;
                goto scram;
        }
        line = TopPixelInRect(r) & ~01;

        targsect = (PCD(pos16tv) / stob(1))  + pcd->lpt16tv[line];
        PCDflushbuf(pcd, stob(targsect));
        PCDHpreDecode(pcdhy);

        for (; line <= BottomPixelInRect(r); line++) 
        {
                if ( PCDdoCallbacks(pcd) )
                	return (pcdUserAbort);			/*XXX - free resources*/
                if (progFunction && line >= TopPixelInRect(r))
                        ++pcd->cNumerator;

                if (!eateolline(pcdhy, line, LSTYPE_Y))
                        continue;
                if (line < TopPixelInRect(r)) {
                        CHECK(PCDHskip(pcdhy, rowsiz(PCD_16BASE)));
                } else {
                        if (LeftPixelInRect(r) != 0)
                                CHECK(PCDHskip(pcdhy, (long) LeftPixelInRect(r)));
                        CHECK(PCDHapply(pcdhy, buffer, colBytes, RectWidth(r)));
                        buffer += stride;
                }
        }
        
#define synch(l) \
{ \
        targsect = (PCD(pos16tv) / stob(1)) + pcd->lpt16tv[(l) | 1]; \
        PCDflushbuf(pcd, stob(targsect)); \
        PCDHpreDecode(pcdhc1); \
        PCDHpreDecode(pcdhc2); \
}
        if (!single) {
                line = TopPixelInRect(r) & ~01;

                synch(line);

                for (; line <= BottomPixelInRect(r); line++) 
                {
                        if ( PCDdoCallbacks(pcd) )
						{
							theErr = pcdUserAbort;
							goto scram;
						}
                        if (progFunction && line >= TopPixelInRect(r))
                                ++pcd->cNumerator;

                        if (!(line & 01)) {
                                if (!first++) {
                                        eateolline(pcdhc1, line, LSTYPE_C1);
                                        CHECK(PCDHdecode(pcdhc1, c1residbuf,
                                          (rowsiz(PCD_16BASE) / 2)));

                                        PCDHASSIGN(pcdhc2, pcdhc1);

                                        eateolline(pcdhc2, line, LSTYPE_C2);
                                        CHECK(PCDHdecode(pcdhc2, c2residbuf,
                                          (rowsiz(PCD_16BASE) / 2)));

                                        PCDHASSIGN(pcdhc1, pcdhc2);

                                        if (line + 2 < colsiz(PCD_16BASE)) {
                                                eateolline(pcdhc1, line + 2, LSTYPE_C1);
                                                CHECK(PCDHdecode(pcdhc1, c1nresidbuf,
                                                  (rowsiz(PCD_16BASE) / 2)));

                                                PCDHASSIGN(pcdhc2, pcdhc1);

                                                eateolline(pcdhc2, line + 2, LSTYPE_C2);
                                                CHECK(PCDHdecode(pcdhc2, c2nresidbuf,
                                                  (rowsiz(PCD_16BASE) / 2)));

                                                PCDHASSIGN(pcdhc1, pcdhc2);
                                        }
                                } else {
                                        if (line + 2 < colsiz(PCD_16BASE)) {
                                                tmpresidbuf = c1residbuf;
                                                c1residbuf = c1nresidbuf;
                                                c1nresidbuf = tmpresidbuf;

                                                if (!eateolline(pcdhc1, line + 2, LSTYPE_C1)) {
                                                        BOOL rv;
                                                        synch(line + 2);
                                                        rv = eateolline(pcdhc1, line + 2, LSTYPE_C1);
                                                        assert(rv);
                                                }

                                                CHECK(PCDHdecode(pcdhc1, c1nresidbuf,
                                                  (rowsiz(PCD_16BASE) / 2)));

                                                PCDHASSIGN(pcdhc2, pcdhc1);

                                                tmpresidbuf = c2residbuf;
                                                c2residbuf = c2nresidbuf;
                                                c2nresidbuf = tmpresidbuf;

                                                if (!eateolline(pcdhc2, line + 2, LSTYPE_C2)) {
                                                        BOOL rv;
                                                        synch(line + 2);
                                                        rv = eateolline(pcdhc2, line + 2, LSTYPE_C2);
                                                        assert(rv);
                                                }

                                                CHECK(PCDHdecode(pcdhc2, c2nresidbuf,
                                                  (rowsiz(PCD_16BASE) / 2)));

                                                PCDHASSIGN(pcdhc1, pcdhc2);
                                        } else {
                                                c1residbuf = c1nresidbuf;
                                                c2residbuf = c2nresidbuf;
                                        }
                                }
                        }
                        if (line < TopPixelInRect(r))
                                continue;
                        else {
                                apply2(line & 01, c1residbuf, c1nresidbuf, buffer2,
                                  rowsiz(PCD_16BASE) / 2, LeftPixelInRect(r),
                                  RightPixelInRect(r) + 1, colBytes);
                                apply2(line & 01, c2residbuf, c2nresidbuf, buffer3,
                                  rowsiz(PCD_16BASE) / 2, LeftPixelInRect(r),
                                  RightPixelInRect(r) + 1, colBytes);
                        }
                        buffer2 += stride;
                        buffer3 += stride;
                }
        }
        PCDrelsesecbuf(pcd);
        PCDHcloseCompressor(pcdhy);
        if (!single) {
                PCDHcloseCompressor(pcdhc1);
                PCDHcloseCompressor(pcdhc2);
        }

scram:
        if (b1) PCDfree(b1); /* original c1residbuf */
        if (b2) PCDfree(b2); /* original c1nresidbuf */
        if (b3) PCDfree(b3); /* original c2residbuf */
        if (b4) PCDfree(b4); /* original c2nresidbuf */
        if (pcd) pcd->iostate.throwInError = FALSE;
        return (theErr);
}


/*
 *      Same as linear2, but src and next are residuals.
 */
void apply2(syndrome, src, next, dst, srcRight, dstLeft, dstRight, colBytes)
        short syndrome;
        signed char FAR *src, FAR *next; 
        unsigned char HUGE *dst;
        short srcRight, dstLeft, dstRight;
        long colBytes;
{
        short value, dstval;

        assert(syndrome == 0 || syndrome == 1);
        assert(src != (unsigned char *) 0);
        assert(next != (unsigned char *) 0);
        assert(dst != (unsigned char *) 0);
        assert(dstLeft < dstRight);
/*      XXX - srcRight / 2 ??? assert(dstRight <= srcRight); */
        if (syndrome == 0) {
                /*
                 *      Output row falls on input grid.
                 *      Interpolate in 1 dimension.
                 */
                src += dstLeft / 2;
                do {
                        if (dstLeft & 01) {
                                value = (short) ((src[0] + src[1]) / 2);
                                src++;
                        } else {
                                value = (short) *src;
                        }
                        dstval = *dst + value;
                        *dst = clamped(dstval);
                        dst += colBytes;
                } while (++dstLeft < (dstRight - 1));
                if (dstLeft >= dstRight) return;
                /*
                 *      Replicate rightmost pixel in image row.
                 */
                if (dstLeft == srcRight || !(dstLeft & 01)) {
                        value = (short) *src;
                } else {
                        value = (short) ((src[0] + src[1]) / 2);
                }
                dstval = *dst + value;
                *dst = clamped(dstval);
        } else {
                /*
                 *      Output row falls between two input rows.
                 */
                src += dstLeft / 2;
                next += dstLeft / 2;
                do {
                        if (dstLeft & 01) {
                                value = (short) ((src[0] + next[0] + src[1] + next[1]) / 4); 
                                src++;
                                next++;
                        } else {
                                value =  (short) ((src[0] + next[0]) / 2);
                        }
                        dstval = *dst + value;
                        *dst = clamped(dstval);
                        dst += colBytes;
                } while (++dstLeft < (dstRight - 1));
                if (dstLeft >= dstRight) return;
                /*
                 *      Handle rightmost pixel in image row.
                 */
                if (dstLeft == srcRight || !(dstLeft & 01)) {
                        value = (short) ((src[0] + next[0]) / 2);
                } else {
                        value = (short) ((src[0] + next[0] + src[1] + next[1]) / 4);
                }
                dstval = *dst + value;
                *dst = clamped(dstval);
        }
} /* end apply2 */

#if 0 /* no longer used? */
/*XXXX - do it the old way */
PCDHstatePtr PCDHopenOldCompressor(PCDphotoPtr pcd)
{
        unsigned short i, j;
        PCDHstatePtr pcdh;
        unsigned char HUGE *ibuf, HUGE *ip;
        unsigned char length, decode;
        unsigned short symbol, symbollim;
        short value;
        int nentries;
        short max_huff_length = pcdh->max_huff_length;
        short rump = 16 - max_huff_length;
        
        pcdh = (PCDHstatePtr) PCDmalloc(sizeof (PCDHstateRec));
        if (pcdh == (PCDHstatePtr) 0)
                return ((PCDHstatePtr) 0);
        PCDH(pcd) = pcd;
        PCDH(hpcd) = pcd->hpcd;
        ibuf = (unsigned char HUGE *) PCDmalloc(DCODELEN);
        if (ibuf == (unsigned char *) 0)
                goto botch;
        
        /*
         *      Initialize table.
         */
        for (i = 0; i < MAX_CODES; i++) {
                PCDH(htabPtr[i].value) = 0;
                PCDH(htabPtr[i].length) = 1; /* Flag as invalid, prevent harm */
#ifdef  HUFFDEBUG
                PCDH(htabPtr[i].valid) = 0; /* Flag as invalid */
#endif
        }

        PCDreadSome(&pcd->iostate, ibuf, DCODELEN);

        ip = ibuf;
        nentries = *ip++;

        /* Set seek postion for reading next HQT */
        PCDsetMark(&pcd->iostate, -DCODELEN, 1); /* undo above read */
        PCDsetMark(&pcd->iostate, 1 + 4 * nentries, 1); /* just after this HQT */

        for (i = 0; i < nentries; i++) {
                length = ip[0];
                if (!length)
                        break;

                symbol = (((ip[1] & 0xff) << 8) | (ip[2] & 0xff)) & Masks[length];
                value = ((signed char FAR *)ip)[3];
                ip += 4;

#ifdef  HUFFDEBUG
                PCDH(htabPtr[symbol].valid) = 1;
#endif
                /* Make symbol left justified in 12 bits. */
                symbol <<= max_huff_length - length;

                /* 
                 * Numerically largest 12-bit value having |symbol|
                 * as its first |length| bits.
                 */
                symbollim = symbol | ((1 << (max_huff_length - length)) - 1);

                for (j = 0; symbol + j <= symbollim; j++) {
                        PCDH(htabPtr[symbol + j].length) = length;
                        PCDH(htabPtr[symbol + j].value) = value;
                }
        }
        PCDfree(ibuf);
        return (pcdh);
botch:
        PCDfree(pcdh);
        return ((PCDHstatePtr) 0);
}
#endif /* oldcompressor; no longer used? */

/*
 * Undocumented raw interface.
 */
PCDstatus FAR PASCAL
PCDget4BaseResiduals(PCDphotoHdl hPcd, PCDRAWDATA buffer)
{
        PCDHstatePtr pcdh = 0;
        long targsect;
        PCDstatus theErr;
        int line;       
        abortFuncPtr abortFunction = 0;
        progFuncPtr progFunction = 0;
        PCDphotoPtr pcd = 0;

        GetPhotoPtr(hPcd, pcd);

        pcd->cNumerator = 0;
        pcd->cDenominator = 1024 * 2;
                
        abortFunction = pcd->abort;
        progFunction = pcd->check;
        if (PCD(lpt4tv) == (short FAR *) 0)
                PCDloadLpt(pcd, PCD_4BASE);
        PCDsetMark(&pcd->iostate, stob(388), 0);
        pcdh = PCDHopenCompressor(pcd);
//      pcdh = PCDHopenOldCompressor(pcd);
        if (pcdh == (PCDHstatePtr) 0) {
                theErr = pcdBadFmt;
                goto scram;
        }
        if (PCDnewsecbuf(pcd) != pcdSuccess) {
                theErr = errno ? errno : ENOMEM;
                PCDHcloseCompressor(pcdh);
                goto scram;
        }
        pcd->iostate.throwInError = TRUE;
        if (Catch((LPCATCHBUF)pcd->iostate.catchbuf)) {
                theErr = EIO;
                goto scram;
        }
        line = 0;

        targsect = 384 + pcd->lpt4tv[line / 4];
        PCDflushbuf(pcd, stob(targsect));
        PCDHpreDecode(pcdh);

        for (; line < 1024; line++) 
        {
                if ( PCDdoCallbacks(pcd) )
					return (pcdUserAbort);				/*XXX - free resources*/
				++pcd->cNumerator;

                if (eateolline(pcdh, line, LSTYPE_DNC))
                        PCDHdecode(pcdh, buffer, 1536L);
                buffer += 1536;
        }
        PCDrelsesecbuf(pcd);
        PCDHcloseCompressor(pcdh);
        return (pcdSuccess);
scram:
        if (pcd && progFunction) {
//              (*progFunction)(pcd->cDenominator, pcd->cDenominator,
//                                                              pcd->checkData);
                pcd->cNumerator = 0;
                pcd->cDenominator = 0;
        }
        if (pcd) PCDrelsesecbuf(pcd);
        if (pcd) pcd->iostate.throwInError = FALSE;
        if (pcdh) PCDHcloseCompressor(pcdh);
        return (theErr);
}
