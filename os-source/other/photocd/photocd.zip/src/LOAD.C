/*
 *  Photo CD Development Toolkit
 *
 *  load.c
 *  Read functions.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)load.c 1.122 - 92/06/03"
#endif

#include <assert.h>
#include <errno.h>
#include <windows.h>
#include <memory.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "rectcalc.h"
#include "quant.h"
#include "pcdovw.h"
#include "util.h"
#include "pcdcbf.h"
#include "image.h"
#include "interp.h"

/*\
 *	PCDdoCallbacks function global variables
\*/
static BOOL		bFirstProgress;				/* used to distinguish first call to PCDdoCallbacks */
static WORD		wLastNumerator;				/* used to track when to issue Progress callback */
static DWORD	dLastTime;					/* used to track when to issue Abort callback */


/* Forward declarations */
PCDstatus PCDgetSimpleBlock(PCDphotoPtr , LPRECT, unsigned char HUGE *,
            long , long );
PCDstatus PCDgetInterpBlock(PCDphotoPtr, LPRECT, unsigned char HUGE*, 
            long, long);
PCDstatus PCDapply4TV(PCDphotoPtr pcd, LPRECT r, unsigned char HUGE *buffer,
            long colbytes, long stride);
PCDstatus PCDapply16TV(PCDphotoPtr pcd, LPRECT r, unsigned char HUGE *buffer, 
            long colbytes, long stride);

/* Rotate a bounding rectangle if need be */
#define ADJUSTBOUNDS(br, xform) \
{   short tmp; \
    if (((xform & PCD_90_ROTATION) != 0) == (br.right > br.bottom)) { \
        tmp = br.right; \
        br.right = br.bottom; \
        br.bottom = tmp; \
    } \
}

/* #define  PCD(X)  pcd->X */

void PCDnewColorFormat(PCDphotoPtr pcd, long count, unsigned char HUGE *ybuf,
    unsigned char HUGE *c1buf, unsigned char HUGE *c2buf, int yCol,
    unsigned char HUGE *buffer, long colbytes);

/**
 ** Get a block of image data from the open image pac
 ** associated with |pcd|.  The entire image is retrieved
 ** if |r| is null, otherwise the image is clipped to the
 ** rectangle |r| in the destination (transformed) coordinate
 ** space.  The image data is stored in |buffer| and the
 ** beginnings of successive rows are separated by |stride|
 ** bytes.
 **
 ** Return values in case of error:
 **     (Memory manager and file manager errors)
 **     pcdBadParam - bad input parameter
 **     pcdUserAbort - user aborted operation
 **/
PCDstatus FAR PASCAL 
PCDgetBlock(PCDphotoHdl hpcd, LPRECT r, unsigned char HUGE* buffer, long stride)
{
    unsigned char HUGE *userbuffer = buffer; /* Where user wants data */
    unsigned char HUGE *tkbuffer = buffer; /* Where toolkit reads it */
    PCDstatus theErr;
    PCDphotoPtr pcd = 0;
    long effstride;              /* effective stride */
    long effcolbytes;            /* effective column bytes */
    long startoff;
    abortFuncPtr abortFunction;
    progFuncPtr progFunction;
    BOOL ownTkBuffer = FALSE;

    /*
     *  Check parameters and set up the crop rectangle
     *  if NULL (meaning read the whole image).
     */
    if (!HANDLETOPOINTER(hpcd, pcd, PCDphotoPtr))
        return(pcdBadParam);

    paramck(pcd);

	if (pcd->step > pcd->maxstep)
	   return(pcdBadParam);	

    if (!buffer) {
        RELEASEHANDLE(hpcd);
        return (pcdBadParam);
    }
    ADJUSTBOUNDS(pcd->bounds, pcd->xform);
    if (!r) {
        r = &pcd->xfCropRect;
        r->left = pcd->bounds.left;
        r->right = pcd->bounds.right;
        r->top = pcd->bounds.top;
        r->bottom = pcd->bounds.bottom;
    } else {
        if (!RectContains(&pcd->bounds, r)) {
            RELEASEHANDLE(hpcd);
            return (pcdBadParam);
        }
        pcd->xfCropRect = *r;
        r = &pcd->xfCropRect;
    }

    /*
     * Make sure IO stream is ready for reading.
     */
    if ((theErr = PCDopenFile(&pcd->iostate)) != pcdSuccess) {
        RELEASEHANDLE(hpcd);
        return(theErr);
    }

    /*
     * For CD-based image pacs, make sure disk hasn't been swapped.
     */
    if (!checkVolume(&pcd->iostate)) {
        RELEASEHANDLE(hpcd);
        return(pcdWrongVolume);
    }
    /*
     * Calculate input transform parameters.
     */
    if (pcd->step <= PCD_BASE || 
        (pcd->format == PCD_RGB || pcd->format == PCD_YCC ||
         pcd->format == PCD_SINGLE)) {
        calcInputXform(pcd->xform, pcd->format, pcd->step,
                        pcd->columnBytes, r, stride, 
                        &startoff, &effcolbytes, &effstride);
    } else {
        if ((tkbuffer = PCDmalloc(3L * stride * (long)RectHeight(r))) == 0) {
            RELEASEHANDLE(hpcd);
            return(ENOMEM);
        }
        ownTkBuffer = TRUE;
        buffer = tkbuffer;
/* Hi-Res case with color reduction */
        calcInputXform(pcd->xform, PCD_YCC, pcd->step,
                        3, r, 3 * stride, 
                        &startoff, &effcolbytes, &effstride);
    }
    buffer += startoff;

    pcd->cNumerator = 0;
    pcd->cDenominator = r->bottom - r->top;

 	bFirstProgress = TRUE;							/* init callback controls */
 	dLastTime = 0;

    abortFunction = pcd->abort;
    progFunction = pcd->check;

    switch (pcd->step) {
    case PCD_BASE_OVER_16:
    case PCD_BASE_OVER_4:
    case PCD_BASE:
        theErr = PCDgetSimpleBlock(pcd, r, buffer, effcolbytes, effstride);
        break;
    case PCD_4BASE:
        if (pcd->cNumerator == 0) {
            if (pcd->format == PCD_RGB || pcd->format == PCD_PALETTE)
                pcd->cDenominator *= 3;
            else
                pcd->cDenominator *= 2;
        }

        theErr = PCDgetInterpBlock(pcd, r, buffer, effcolbytes, effstride);
        if (theErr != pcdSuccess) {
            goto out;
        }
        if (pcd->version == PCD_NEW_VERSION && pcd->maxstep >= PCD_4BASE)
            theErr = PCDapply4TV(pcd, r, buffer, effcolbytes, effstride);
        if (theErr != pcdSuccess) {
            goto out;
        }
        goto doColor;

    case PCD_16BASE:
        if (pcd->cNumerator == 0) {
            if (pcd->format == PCD_RGB || pcd->format == PCD_PALETTE)
                pcd->cDenominator *= 5;
            else if (pcd->format == PCD_YCC)
                pcd->cDenominator *= 4;
            else
                pcd->cDenominator *= 3;
        }

        theErr = PCDgetInterpBlock(pcd, r, buffer, effcolbytes, effstride);
        if (theErr != pcdSuccess) {
            goto out;
        }
        if (pcd->version != PCD_NEW_VERSION)
            goto doColor;
        if (pcd->maxstep >= PCD_4BASE) {
                theErr = PCDapply4TV(pcd, r, buffer, effcolbytes, effstride);
                if (theErr != pcdSuccess) {
                    goto out;
                }
        }
        if (pcd->maxstep >= PCD_16BASE) {
                theErr = PCDapply16TV(pcd, r, buffer, effcolbytes, effstride);
                if (theErr != pcdSuccess) {
                    goto out;
                }
        }
doColor: 
        if (pcd->format != PCD_SINGLE && pcd->format != PCD_YCC) {
            unsigned char HUGE *y, HUGE *c1, HUGE *c2, HUGE *outbuf;
            long yccstride;
            int line, lstart, lend, lsize;

            if (pcd->format == PCD_RGB)
                yccstride = stride;
            else
                yccstride = 3 * stride;

            outbuf = userbuffer;
            y = tkbuffer;
            c1 = y + pcd->planeBytes;
            c2 = c1 + pcd->planeBytes;

            if (pcd->xform & PCD_90_ROTATION) {
                lstart = r->left;
                lend = r->right;
                lsize = RectHeight(r);
            } else {
                lstart = r->top;
                lend = r->bottom;
                lsize = RectWidth(r);
            }

            for (line = lstart; line < lend; line++) 
            {
				if( PCDdoCallbacks(pcd) )
				{
					theErr = pcdUserAbort;
					goto out;
				}
                if (pcd->cNumerator < pcd->cDenominator - 1) 
                    pcd->cNumerator++;

                PCDnewColorFormat(pcd, lsize, y, c1, c2, 3,
                                    outbuf, (long) pcd->columnBytes);
                y += yccstride;
                c1 += yccstride;
                c2 += yccstride;
                outbuf += stride;
            }
        }
        break;
    default:
        theErr = pcdBadParam;
    }
out:
    if (progFunction && pcd->cDenominator)
	{
		pcd->cNumerator = pcd->cDenominator;
		if (PCDdoCallbacks(pcd) )
		{
			theErr = pcdUserAbort;
		}
	}
    pcd->cNumerator = 0;
    pcd->cDenominator = 0;

    if (ownTkBuffer) PCDfree(tkbuffer);
    if (pcd) (void)PCDcloseFile(&pcd->iostate);
    if (pcd) RELEASEHANDLE(hpcd);
    return(theErr);
}

/*XXX*/
int skipCopy = 0;

void
PCDnewColorFormat(PCDphotoPtr pcd, long count, unsigned char HUGE *ybuf,
    unsigned char HUGE *c1buf, unsigned char HUGE *c2buf,
    int yCol,
    unsigned char HUGE *buffer, long colbytes)
{
if (skipCopy) return;

    switch (pcd->format) {
    case PCD_RGB:
        PCDiYCCtoRGB(ybuf, c1buf, c2buf, yCol,
              buffer, pcd->planeBytes, colbytes, count);
        break;
    case PCD_PALETTE:
        PCDiYCCtoPalette(ybuf, c1buf, c2buf, yCol,
              colbytes, buffer, count, 
              pcd->palette);
        break;
    case PCD_YCC:
        /* N.B.: Since this won't be called in the tail step
         * of a hi-res image load, can assume planar YCC input.
         */
        memcpyg(buffer, ybuf, count, colbytes);
        memcpyg(buffer + pcd->planeBytes, c1buf, count, colbytes);
        memcpyg(buffer + 2 * pcd->planeBytes, c2buf, count, colbytes);
        break;
    case PCD_SINGLE:
        /* N.B.: (See YCC) */
        memcpyg(buffer, ybuf, count, colbytes);
        break;
    }
}

#include "raw.h"
PCDstatus PCDxiYCCtoYCC4 (PCDRAWDATA  y, 
                        PCDRAWDATA  c1t, /* row above */
                        PCDRAWDATA  c2t, 
                        PCDRAWDATA  c1b, /* row below */
                        PCDRAWDATA  c2b, 
						int         yCol, 
                        PCDRAWDATA  yo, 
                        long        yoPlane, 
                        long        yoCol, 
                        long        count,
                        BOOL        replicateLast );


/*
 *  Get a block of image data.  This function depends on the
 *  following:
 *
 *  variable    set by      purpose
 *  pcd->step   PCDselect() resolution of data
 *  pcd->format PCDselect() pixel type of data
 *  pcd->planeBytes PCDsetPlanar()  planar configuration
 *  pcd->columnBytes PCDsetPlanar() planar configuration
 *  pcd->xform PCDsetTransform()    mirror/rotate input
 *  r               clip rectangle
 *
 *  Output data is placed into |buffer|; each line is
 *  separated by |stride| bytes.
 */

PCDstatus PCDgetSimpleBlock(pcd, r, buffer, colbytes, stride)
     PCDphotoPtr pcd;
     LPRECT r;
     unsigned char HUGE *buffer;
     long colbytes;
     long stride;
 {
     PCDstatus theErr = pcdSuccess;
     register short line;
     unsigned char FAR *ybuf = 0, FAR *c1buf, FAR *c2buf;
     abortFuncPtr abortFunction = pcd->abort;
     progFuncPtr progFunction = pcd->check;
     PCDrawYCCPtr pcdr = 0;
     short width;
     int   yoff, coff;
     BOOL replicateLast;
 
     /*
      *  Check parameters.
      */
     paramck(pcd != PCDNULL);
     if (pcd->format == PCD_PALETTE)
         paramck(pcd->palette != 0);
     assert(r);
 
     width = RectWidth(r);
     yoff = LeftPixelInRect(r);
     coff = LeftPixelInRect(r);
 /*  if (pcd->format == PCD_RGB || pcd->format == PCD_PALETTE) */
     coff /= 2;
     replicateLast = (width + yoff == rowsiz(pcd->step));
 
     line = TopPixelInRect(r);
 
     if ((pcdr = openRawYCC(&pcd->iostate, pcd->step, 
                             pcd->format, pcd->version, TRUE)) == 0) {
         theErr = ENOMEM;
         goto out;
     }
    for (; line <= BottomPixelInRect(r); line++) 
    {
		if( PCDdoCallbacks(pcd) )
		{
			theErr = pcdUserAbort;
			goto out;
		}
 		++pcd->cNumerator;
 
         if ((ybuf  = getRawLine(pcdr, line, Y)) == 0) {
             theErr = EIO;
             goto out;
         }
         if (pcd->format != PCD_SINGLE) {
             if ((c1buf = getRawLine(pcdr, line, C1)) == 0 ||
                 (c2buf = getRawLine(pcdr, line, C2)) == 0) {
                 theErr = EIO;
                 goto out;
             }
         }
	if (!skipCopy){
		unsigned char _huge * bufc1 = buffer + pcd->planeBytes;
		unsigned char _huge * bufc2 = bufc1 + pcd->planeBytes;
	        switch (pcd->format) {
		        case PCD_RGB:
		            PCDxiYCCtoRGB(ybuf + yoff, c1buf + coff, c2buf + coff, 1,
		                  buffer, (int) pcd->planeBytes, colbytes, (long) width,
		                  replicateLast);
		            break;
		        case PCD_PALETTE:
		            PCDxiYCCtoPalette(ybuf + yoff, c1buf + coff, c2buf + coff, 1,
		                  colbytes, buffer, (long) width, 
		                  pcd->palette,
		                  replicateLast);
		            break;
		        case PCD_YCC:

		            /* if (!(line & 1))*/  /* 2-way left-right interp */
		            	PCDxiYCCtoYCC(ybuf + yoff, c1buf + coff, c2buf + coff, 1,
							buffer, pcd->planeBytes, colbytes, (long) width,
							replicateLast);
#if 0
					else  /* 2 & 4 way top-bottom interp */
						PCDxiYCCtoYCC4 (ybuf + yoff, pcdr->c1[0] + coff, pcdr->c2[0] + coff, 
							pcdr->c1[2] + coff, pcdr->c2[2] + coff, 1, buffer, 
							pcd->planeBytes, colbytes, (long) width, replicateLast );
#endif		
		            break;
		        case PCD_SINGLE:
		            memcpyg(buffer, ybuf + yoff, (long) width, colbytes);
		            break;
		       }
	 	}
         buffer += stride;
     }
 out:
     if (pcdr)
         closeRawYCC(pcdr);
     return (theErr);
 }

/*
 *  Get the BASE image from an open image pac, using bilinear
 *  interpolation to generate the resolution step specified
 *  in |pcd|.  |r| refers to the crop rectangle in this
 *  resolution step; odd coordinates are handled correctly.
 */
PCDstatus PCDgetInterpBlock(PCDphotoPtr pcd, LPRECT r, 
    unsigned char HUGE *buffer, long colbytes, long stride)
{
    short line, srcline;
    short lastImageLine;
    short firstEasyLine, lastEasyLine;
    short ysyndrome, csyndrome;
    short ygrid, cgrid;
    short first = 0;
    BOOL single;
    PCDstatus theErr = pcdSuccess;
    unsigned char HUGE *thisy, HUGE *nexty;
    unsigned char HUGE *thisc1, HUGE *thisc2, HUGE *nextc1, HUGE *nextc2;
    unsigned char HUGE *outbuf1, HUGE *outbuf2, HUGE *outbuf3;
    PCDrawYCCPtr pcdr;
    abortFuncPtr abortFunction = pcd->abort;
    progFuncPtr progFunction = pcd->check;

    if ((pcdr = openRawYCC(&pcd->iostate, pcd->step, 
                            pcd->format, pcd->version, TRUE)) == 0)
        return(ENOMEM);

    single = pcd->format == PCD_SINGLE;
    /*
     *  Set up output data pointers.
     */
    outbuf1 = buffer;
    if (!single) {
        outbuf2 = outbuf1 + pcd->planeBytes;
        outbuf3 = outbuf2 + pcd->planeBytes;
    }

    if (pcd->step == PCD_4BASE) {
        ygrid = 2;
        cgrid = 4;
    } else {
        assert(pcd->step == PCD_16BASE);
        ygrid = 4;
        cgrid = 8;
    }

    line = TopPixelInRect(r);
    line -= line % cgrid;

/* Fake out mechanism to use interp() intstead of interp1d() */
    lastEasyLine = ((BottomPixelInRect(r) + 1) & ~(cgrid - 1)) - cgrid;
    firstEasyLine = lastEasyLine + 1;
    lastImageLine = colsiz(PCD_BASE) - 1;

/*
 * First pass: do the hard lines - grid lines, and
 * lines within a grid width of the top and bottom.
 */
    for (; line <= BottomPixelInRect(r); line++) 
    {
        if ( PCDdoCallbacks(pcd) )
        {
			theErr = pcdUserAbort;
			goto out;
        }

        ysyndrome = line % ygrid;
        csyndrome = line % cgrid;

        srcline = line / ygrid;
/* Read the data */
        if (ysyndrome == 0) 
        {
            if ((thisy = getRawLine(pcdr, srcline, Y)) == 0) {
                theErr = EIO; goto out;
            }
            if (!single && csyndrome == 0) 
            {
                if ((thisc1 = getRawLine(pcdr, srcline, C1)) == 0) {
                    theErr = EIO; goto out;
                }
                if ((thisc2 = getRawLine(pcdr, srcline, C2)) == 0) {
                    theErr = EIO; goto out;
                }
            }
            if (srcline < lastImageLine) srcline++;
            if ((nexty = getRawLine(pcdr, srcline, Y)) == 0) {
                theErr = EIO; goto out;
            }
            if (srcline < lastImageLine) srcline++;
            if (!single && csyndrome == 0) 
            {
                if ((nextc1 = getRawLine(pcdr, srcline, C1)) == 0) {
                    theErr = EIO; goto out;
                }
                if ((nextc2 = getRawLine(pcdr, srcline, C2)) == 0) {
                    theErr = EIO; goto out;
                }
            }
        }
        if (line < TopPixelInRect(r))
            continue;

/* Interpolate out the lines */
        if (line < firstEasyLine || line > lastEasyLine || ysyndrome == 0) 
        {
            ++pcd->cNumerator;
			CHECK_CORRUPT();
            linear(ygrid, ysyndrome, thisy, nexty, outbuf1, rowsiz(pcd->step),
              r->left, r->right, colbytes);
			CHECK_CORRUPT();
        } 
        outbuf1 += stride;
        if (!single) 
        {
            if (line < firstEasyLine || line > lastEasyLine || csyndrome == 0)
            {
				CHECK_CORRUPT();
                linear(cgrid, csyndrome, thisc1, nextc1, outbuf2,
                  rowsiz(pcd->step), r->left, r->right, colbytes);
				CHECK_CORRUPT();
                linear(cgrid, csyndrome, thisc2, nextc2, outbuf3,
                  rowsiz(pcd->step), r->left, r->right, colbytes);
				CHECK_CORRUPT();
            }
            outbuf2 += stride;
            outbuf3 += stride;
        }
    }
out:
    if (pcdr)
        closeRawYCC(pcdr);
    return (theErr);
}

/***************************************************************************/

#include "pal.h"

/*
 * Set up DIB header for an image.
 */

void bmiCalc(PCDformat fmt, LPBITMAPINFO lpbi, 
             WORD width, WORD height, short columnBytes, PCDpaletteHdl hpal)
{
    BITMAPINFOHEADER    bi;

    bi.biWidth = width;
    bi.biHeight = height;

    bi.biSize = sizeof(BITMAPINFOHEADER);
    bi.biPlanes = 1;
    bi.biCompression = BI_RGB;
    if (fmt == PCD_YCC || fmt == PCD_RGB) {
        bi.biBitCount = 24; 
        bi.biSizeImage = bi.biWidth *  bi.biHeight * columnBytes;
    } else {
        bi.biBitCount = 8;
        bi.biSizeImage = bi.biWidth *  bi.biHeight;
    }

/* XXX - is there a useful value to put here? */
    bi.biXPelsPerMeter = 0;
    bi.biYPelsPerMeter = 0;

    if (fmt != PCD_RGB)
        bi.biClrUsed = 0;
    else
        bi.biClrUsed = 256;
    bi.biClrImportant = 0;
    
    *(LPBITMAPINFOHEADER)lpbi = bi;

    setUpPalette(fmt, hpal, lpbi->bmiColors);
}


PCDstatus FAR PASCAL
PCDloadImage(PCDphotoHdl hPcd, LPRECT lpRect,
             PCDbitmapHdl FAR *lphPCDbitmap)
{
    PCDphotoPtr     pcd;
    HANDLE          hbytes = 0; /* Handle to image data */
    RECT            r;          /* Bounding rectangle */
    char _huge      *ibuf;      /* Image buffer space */
    int             width, height, 
                    hdrsize;    /* Size of platform-dependent image header */
    unsigned long   stride;
    unsigned long   imgsize;    /* Size of entire image, not including header */
    PCDstatus       res;
    PCDformat       format;

    /* Disallow rectangles which are not multiples of 4 */ 
    if (lpRect) {
        if ((RectWidth(lpRect) % 4) != 0)
            return(pcdBadParam);
        if ((RectHeight(lpRect) % 4) != 0)
            return(pcdBadParam);
    }

    paramck(lphPCDbitmap);
    *lphPCDbitmap = 0;

    GetPhotoPtr(hPcd, pcd);

	if (pcd->step > pcd->maxstep)
	   return(pcdBadParam);	

    format = pcd->format;

    PCDlistResolution(pcd->step, &width, &height);

    if ((pcd->xform & PCD_90_ROTATION) == 0) {
        if (lpRect) {
            width = RectWidth(lpRect);
            height = RectHeight(lpRect);
        }
    } else {
        /* Odd 90 degree rotates exchange width and height */
        if (lpRect) {
            width = RectWidth(lpRect);
            height = RectHeight(lpRect);
        } else {
            int tmp = width;

            width = height;
            height = tmp;
        }
    }

    if (lpRect)
        r = *lpRect;
    else
        SetRectSize(&r, 0, 0, width, height);

    hdrsize = sizeof(BITMAPINFOHEADER);
    if (format == PCD_SINGLE || format == PCD_PALETTE) {
/* XXX - delete these? */
        pcd->planeBytes = 1;
        pcd->columnBytes = 1;
        imgsize = (long)RectWidth(&r) * (long)RectHeight(&r);

        hdrsize += 256 * sizeof(RGBQUAD);
    } else {
        imgsize = 3L * (unsigned long)RectWidth(&r) * 
                    (unsigned long)RectHeight(&r);
        if (format == PCD_RGB)
            hdrsize += 256 * sizeof(RGBQUAD);
    }
    PCDgetBytesPerRow(hPcd, (WORD)RectWidth(&r), &stride);

/*XXX - max size retrieval is 16M */
    if ((imgsize + hdrsize + PCDBMEXTRABYTES) >= (16L * 1024L * 1024L)) {
        *lphPCDbitmap = 0;
        GlobalUnlock(hPcd);
        return(ENOMEM);
    }
    if ((hbytes = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT,
                              imgsize + hdrsize + PCDBMEXTRABYTES)) == 0) {
        *lphPCDbitmap = 0;
        GlobalUnlock(hPcd);
        return(ENOMEM);
    }
    if ((ibuf = (char _huge *)GlobalLock(hbytes)) == 0) {
        GlobalFree(hbytes);
        *lphPCDbitmap = 0;
        return(ENOMEM);
    }


    bmiCalc(format, (LPBITMAPINFO)ibuf, RectWidth(&r), RectHeight(&r),
                pcd->columnBytes, pcd->palette);

    /* Store plane and column bytes in extra space after image data */
    setPlaneCol(hbytes, pcd->planeBytes, pcd->columnBytes);

    *lphPCDbitmap = hbytes;

    if (RectWidth(&r) > 0 && RectHeight(&r) > 0) {
        /* The meat is here - read the data */
        res = PCDgetBlock(hPcd, &r, ibuf + hdrsize, stride);
        /* hi-res PCD_PALETTE wipes these out - need to reset */
        if (res == pcdSuccess)
            setPlaneCol(hbytes, pcd->planeBytes, pcd->columnBytes);
    } else if (RectWidth(&r) >= 0 && RectWidth(&r) >= 0) {
        /* Zero-sized rect: read nothing, successfully */
        res = pcdSuccess;
    } else
        res = pcdBadParam;

    GlobalUnlock(hPcd);
    GlobalUnlock(hbytes);
    if (res != pcdSuccess) {
        if (hbytes)
            GlobalFree(hbytes);
        *lphPCDbitmap = 0;
    }
    return(res);
}

/*\
 *		Assumption: Progress and Abort functions always called in pairs.
 *					The return value of PCDdoCallbacks is the return
 *					value of the Abort callback function, if it is invoked;
 *					Otherwise, a FALSE value is returned.
 *
\*/
BOOL
PCDdoCallbacks(PCDphotoPtr pcd )
{
    abortFuncPtr	abortFunction;
    progFuncPtr		progFunction;
	DWORD			dNowTime, dDiff;
	WORD			wNumerator;

    abortFunction = pcd->abort;
    progFunction = pcd->check;


/*\
 *	Determine whether to invoke the application progress callback function.
 *	This is done when the percentage difference equals or exceeds the trigger value.
 *	Always invoke the callback the first time with a numerator equal to 0.
\*/
	if(progFunction != (progFuncPtr) 0)
	{
		if(bFirstProgress)
		{
			bFirstProgress = FALSE;									/* First time */
			wLastNumerator = 0;
			(*progFunction)( 0, 100, pcd->checkData);
		}
		else
		{
			if(pcd->cNumerator > pcd->cDenominator)
				pcd->cNumerator = pcd->cDenominator;
			wNumerator = (WORD) ((pcd->cNumerator * 100) / pcd->cDenominator);
			if( (wNumerator - wLastNumerator) >= PROGRESS_INTERVAL ||
				(pcd->cNumerator == pcd->cDenominator) )
			{
				wLastNumerator = wNumerator;					/* hit Trigger value */
				(*progFunction)( wNumerator, 100, pcd->checkData);
			}
		}
	}

/*\
 *	Determine whether to invoke the application abort callback function.
 *	This is done when the time interval equals or exceeds the trigger value.
 *	Always invoke the callback the first time.
\*/
	if (abortFunction != (abortFuncPtr) 0)
	{
		dNowTime = GetCurrentTime() / 1000;				/* time in seconds */
		if(dLastTime == 0)
		{
			dLastTime = dNowTime;						/* First time */
			return( (*abortFunction)(pcd->abortData) );
		}
		else
		{
			dDiff = dNowTime - dLastTime;
			if( dDiff >= ABORT_INTERVAL )
			{
				dLastTime = dNowTime;					/* hit Trigger value */
				return( (*abortFunction)(pcd->abortData) );
			}
		}
	}

	return(FALSE);										/* abort not called */
}




