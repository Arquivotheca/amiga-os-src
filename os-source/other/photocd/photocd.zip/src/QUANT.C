/*
 *  Photo CD Development Toolkit
 *
 *  quant.c
 *  Color reduction routines using using Octree Quantization.
 *  Stubs only - not used.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)quant.c    1.120 - 92/06/03"
#endif
#include <windows.h>
#include <ctype.h>
#include <assert.h>
#include <errno.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "quant.h"
#include "ycctab.h"

/*
 * Free all resources associated with an Octree.
 */
void
oqFree(PCDpaletteHdl hPal)
{
    
    return;
}

/*
 * Initialize Octree instance variables.
 */

void
oqInit(lphPal)
PCDpaletteHdl FAR   *lphPal;
{
    return;
}

/*
 * Get a block of nodes so that oqGetNode() can allocate one.
 */

int
oqGetMoreNodes(pp)
PCDpalettePtr pp;
{

    return(0);
}

/*
 * Remove a node from the free list; if empty, try to get another
 * block of nodes.
 */

Octree
oqGetNode(pp)
PCDpalettePtr   pp;
{
    return((Octree)0);
}

/*
 * Release a node to the free list.
 */

void
oqFreeNode(pp, thisnode)
PCDpalettePtr pp;
Octree  thisnode;
{
    return;
}
    
/*
 * Find the deepest interior node. This node will have its
 * children folded into it and will become a leaf.
 */

Octree
oqGetReducible(pp) 
PCDpalettePtr pp;
{
    return (Octree) 0;
}


#define oqBit(b, v) ((b) <= 1 ? ((v) & 1) : (((v) >> ((b) - 1)) & 1))

/*
 * Determine which subtree represents the color at this depth in the
 * tree.
 */

oqBranch(r, g, b, depth)
int r, g, b;
int depth;
{
    return (0);
}

/*
 * Put a (newly created) interior node onto the list of
 * reducible nodes.
 */

int
oqMakeReducible(pp, depth, tree)
PCDpalettePtr pp;
int depth;
Octree  tree;
{
	return(0);
}


/*
 * Insert a color in the Octree. Starting with the root
 * navigate through the tree, allocating subtrees as needed,
 * until a leaf is reached.
 */

void
oqInsertTree(pp, r, g, b)
PCDpalettePtr pp;
int r, g, b;
{
    return;
}


/*
 * Eliminate colors from the tree. GetReducible() returns the deepest
 * interior node whose children are folded in and freed.
 */ 

int
oqReduceTree(pp)
PCDpalettePtr pp;
{
    return(0);
}


void
oqAddColor(pp, r, g, b)
PCDpalettePtr pp;
int r, g, b;
{
    return;
}

/*
 * Insert a list of colors into the Octree, which is reduced as needed.
 */

void
oqInsertColors(hPal, r, rPlane, rCol, npix)
PCDpaletteHdl hPal;
unsigned char HUGE *r;
long rPlane; 
int rCol;
unsigned long npix;
{
    return;
}

/*
 * Same as above, but uses planar YCC.
 */

void
oqInsertYCCcolors(PCDpaletteHdl hPal, unsigned char HUGE *y, 
                  unsigned char HUGE *c1, unsigned char HUGE *c2,
                  unsigned long npix)
{
    return;
}

/*
 * Traverse the Octree and build the color table.
 * XXX - this is (still) a recursive function.
 */
int
oqInitColorTable(pp, tree, index)
PCDpalettePtr pp;
Octree  tree;
int index;
{
    return(0);
}

/*
 * Traverse the Octree and build the color table.
 * Similar to above, but more general.
 * XXX - this is (still) a recursive function.
 */

int
oqRetrieveColorTable(pp, tree, index, ctab, planeBytes, columnBytes, maxix)
PCDpalettePtr pp;
Octree  tree;
int index;
unsigned char FAR *ctab;
long planeBytes;
int columnBytes;
int maxix;
{
    return(0);
}


/*
 * Map an RGB triple to its nearest representative.
 */

int
oqQuant(tree, r, g, b)
Octree tree;
unsigned char r, g, b;
{
    return(0);
}

/*
 * Map an RGB triple to its nearest representative,
 * indicating the error in each of the 3 components.
 */

int
oqQuantErr(tree, r, g, b, rerr, gerr, berr)
Octree tree;
unsigned char r, g, b;
int FAR *rerr, FAR *gerr, FAR *berr;
{
    return(0);
}

/*
 * Convert a run of RGB values into palette indices based on
 * the given palette/Octree.
 */
void
oqReduceImage(hPal, r, rPlane, rCol, newp, npix, ctab)
PCDpaletteHdl hPal;
unsigned char HUGE  *r;
long rPlane; 
long rCol;
unsigned char HUGE  *newp;
unsigned long       npix;
RGBQUAD FAR *ctab;
{
    return;
}


/*
 * Enters colors into a palette/Octree.
 * XXX - should have a way to set "K"?.
 */
PCDstatus FAR PASCAL
PCDloadPaletteColors(PCDpaletteHdl hPal, unsigned char HUGE *hpImage, 
                long planeBytes, int colBytes, DWORD npix)
{
    oqInsertColors(hPal, hpImage, planeBytes, colBytes, npix);
    return(pcdSuccess); /*XXX - check for errors*/
}

PCDstatus FAR PASCAL
PCDretrievePaletteColors(PCDpaletteHdl hPal, unsigned char HUGE *lpColors, 
                long planeBytes, int colBytes, WORD npix)
{
    PCDpalettePtr pp;

    if ((HANDLETOPOINTER(hPal, pp, PCDpalettePtr)) == 0)
        return(ENOMEM);
    oqRetrieveColorTable(pp, pp->base, 0, lpColors, planeBytes, colBytes, npix);
    RELEASEHANDLE(hPal);
    return(pcdSuccess); /*XXX - check for errors*/
}

#include "image.h"

/*
 * Reduce an entire image given a palette/Octree.
 * XXX - incomplete.
 */

PCDstatus FAR PASCAL    
PCDreduceImage(PCDbitmapHdl hBitmap, PCDpaletteHdl hPal, BOOL bInplace,
                PCDbitmapHdl FAR *lphNewBitmap)
{
    int             depth; 
    long            rows, cols;
    long            planeBytes, colBytes;
    unsigned long   npix;
    unsigned char   HUGE *hpImage, HUGE *hpNewImage;
    PCDstatus       retval;
    PCDpalettePtr   pp;
    HANDLE          hNew;
    LPBITMAPINFO    lpbi, lpNewbi;

    paramck(hBitmap);
    paramck(hPal);
    if (!bInplace)
        paramck(lphNewBitmap);

    if ((HANDLETOPOINTER(hPal, pp, PCDpalettePtr)) == 0)
        return(ENOMEM);
    if ((retval = getImageInfo(hBitmap, &lpbi, &depth, &rows, &cols, 
                        &planeBytes, &colBytes, &hpImage)) != pcdSuccess)
        return(retval);

    if (bInplace) {
        hpNewImage = hpImage;
        hNew = 0;
        pp->colorTable = PaletteAddr(lpbi);
/* XXX - pre-existing palettes? */
    } else {
        if ((retval = makeNewImage(hBitmap, &lpNewbi, 
                                    &hNew, &hpNewImage)) != pcdSuccess) {
            RELEASEHANDLE(hPal);
            relseImage(hBitmap);
            return(retval);
        }

/* XXX - pre-existing palettes? */
        if (lpNewbi->bmiHeader.biClrUsed == 0) {
            lpNewbi->bmiHeader.biClrUsed = 256; /*XXX*/
            hpNewImage += PaletteSize(lpNewbi);
        }

        pp->colorTable = PaletteAddr(lpNewbi);
    }

    npix = rows * cols;

    oqInitColorTable(pp, pp->base, 0);
    oqReduceImage(hPal, hpImage, planeBytes, colBytes, 
                    hpNewImage, npix, pp->colorTable);

    RELEASEHANDLE(hPal);
    relseImage(hBitmap);
    if (!bInplace) 
    {
        relseImage(hNew);
    }
    
    if (lphNewBitmap) {
        if (bInplace)
            *lphNewBitmap = hBitmap;
        else
            *lphNewBitmap = hNew;
    }
    return(pcdSuccess); /*XXX - check for errors*/
}


