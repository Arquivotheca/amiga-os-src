#include <windows.h>
#include <assert.h>
#include "pcdlib.h"
#include "pal.h"

#define PALETTESIZE 256

LPLOGPALETTE CurrentPalette = 0;

#define NRED    8
#define NGREEN  8
#define NBLUE   4

#include "photo.h"

HPALETTE Palette_Create(int ptype)
{
    int entriesPerAxis = 6;
    int entryCount = NRED * NGREEN * NBLUE;
    HANDLE logPaletteH;
    HPALETTE hPalette = NULL;

    logPaletteH = GlobalAlloc(GMEM_MOVEABLE,
                              sizeof(LOGPALETTE) + 
                              (sizeof(PALETTEENTRY) * entryCount));
    if (logPaletteH)
    {
        CurrentPalette = (LPLOGPALETTE) GlobalLock(logPaletteH);
        if (CurrentPalette)
        {    
            CurrentPalette->palVersion = 0x0300;
            CurrentPalette->palNumEntries = entryCount;
            /* Initialize entries */
            switch(ptype) {
            case IDM_PGRAY:
                makeGrayPalette((RGBQUAD FAR *)CurrentPalette->palPalEntry,
                                256);
                break;
            case IDM_PGRAYISH:
                makeKBPalette((RGBQUAD FAR *)CurrentPalette->palPalEntry);
                break;
            case IDM_PREDDISH:
                makeRBPalette((RGBQUAD FAR *)CurrentPalette->palPalEntry);
                break;
            case IDM_PGREENISH:
                makeGBPalette((RGBQUAD FAR *)CurrentPalette->palPalEntry);
                break;
            case IDM_PBLUISH:
                makeBBPalette((RGBQUAD FAR *)CurrentPalette->palPalEntry);
                break;
            default:
            case IDM_P332:
                make332Palette((RGBQUAD FAR *)CurrentPalette->palPalEntry);
                break;
            }
            /* Create the palette object */
            hPalette = CreatePalette(CurrentPalette);
        }
    }
    return (hPalette);
}

void
copyPalette(RGBQUAD FAR *to, PALETTEENTRY FAR *from, WORD nentries)
{
    while (nentries-- > 0) {
        to->rgbRed      = from->peRed;
        to->rgbGreen    = from->peGreen;
        to->rgbBlue     = from->peBlue;
        to->rgbReserved = 0;
        to++; 
        from++;
    }
}

int     palinit = 0;
RGBQUAD pal332[256];

copyToPalette(PALETTEENTRY FAR *to, RGBQUAD FAR *from, WORD nentries)
{
    if (!from) {
        if (!palinit) {
            make332Palette(pal332);
            palinit++;
        }
        from = pal332;
    }
    while (nentries-- > 0) {
        to->peRed   = from->rgbRed;
        to->peGreen = from->rgbGreen;
        to->peBlue  = from->rgbBlue;
        to->peFlags = 0;
        to++; 
        from++;
    }
}

void
make332Palette(RGBQUAD FAR *pep)
{
    int rColorStep = (PALETTESIZE - 1) / (NRED    - 1);
    int gColorStep = (PALETTESIZE - 1) / (NGREEN  - 1);
    int bColorStep = (PALETTESIZE - 1) / (NBLUE   - 1);
    int r, g, b;

    for (r = 0; r < NRED; r++) /* 3 */
        for (g = 0; g < NGREEN; g++) /* 3 */
            for (b = 0; b < NBLUE; b++) /* 2 */
            {
                pep->rgbRed      = r * rColorStep;
                pep->rgbGreen    = g * gColorStep;
                pep->rgbBlue     = b * bColorStep;
                pep->rgbReserved = 0;
                pep++;
            }
}

#define WHITE_THRESHOLD (ngrays / 8)

/* Hacked for more light */
void
makeGrayPalette(RGBQUAD FAR *pep, int ngrays)
{
    int i;
    int fact = 255 / (ngrays - 1);

    for (i = 0; i < ngrays; i++) {
        if (i >= ngrays - WHITE_THRESHOLD)
            pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 255;
        else if (i == 0)
            pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 0;
        else
            pep->rgbRed = pep->rgbGreen = pep->rgbBlue = (i + WHITE_THRESHOLD)
                                                            * fact;
        pep->rgbReserved = 0;
        pep++;
    }
}

make221Palette(RGBQUAD FAR *pep)
{
    int r, g, b;
    int rColorStep = (PALETTESIZE - 1) / (NRED/2    - 1);
    int gColorStep = (PALETTESIZE - 1) / (NGREEN/2  - 1);
    int bColorStep = (PALETTESIZE - 1) / (NBLUE/2   - 1);

    for (r = 0; r < NRED / 2; r++) 
        for (g = 0; g < NGREEN / 2; g++)
            for (b = 0; b < NBLUE / 2; b++) {
                pep->rgbRed      = r * rColorStep;
                pep->rgbGreen    = g * gColorStep;
                pep->rgbBlue     = b * bColorStep;
                pep->rgbReserved = 0;
                pep++;
            }
}

#define NBIAS   127
#define BIASSTEP  2

void
makeKBPalette(RGBQUAD FAR *pep)
{
    int i, j;

    for (i = 0; i < NBIAS; i++) {
        pep->rgbRed = pep->rgbGreen = pep->rgbBlue = (i * 255) / (NBIAS - 1);
        pep->rgbReserved = 0;
        pep++;
    }
    make221Palette(pep);
}

void
makeRBPalette(RGBQUAD FAR *pep)
{
    int i, j;

    for (i = 0; i < NBIAS; i++) {
        pep->rgbRed = (i * 255) / (NBIAS - 1);
        pep->rgbGreen = pep->rgbBlue = 0;
        pep->rgbReserved = 0;
        pep++;
    }
    make221Palette(pep);
}

void
makeGBPalette(RGBQUAD FAR *pep)
{
    int i, j;

    for (i = 0; i < NBIAS; i++) {
        pep->rgbGreen = (i * 255) / (NBIAS - 1);
        pep->rgbRed = pep->rgbBlue = 0;
        pep->rgbReserved = 0;
        pep++;
    }
    make221Palette(pep);
}

void
makeBBPalette(RGBQUAD FAR *pep)
{
    int i, j;

    for (i = 0; i < NBIAS; i++) {
        pep->rgbBlue = (i * 255) / (NBIAS - 1);
        pep->rgbRed = pep->rgbGreen = 0;
        pep->rgbReserved = 0;
        pep++;
    }
    make221Palette(pep);
}

HPALETTE
paletteFromDib(RGBQUAD FAR*rgb, WORD nent)
{
    HANDLE logPaletteH;
    HPALETTE hPalette = NULL;

    nent = 256;
    logPaletteH = GlobalAlloc(GMEM_MOVEABLE,
                              sizeof(LOGPALETTE) + 
                              (sizeof(PALETTEENTRY) * nent));
    if (logPaletteH)
    {
        CurrentPalette = (LPLOGPALETTE) GlobalLock(logPaletteH);
        if (CurrentPalette)
        {    
            CurrentPalette->palVersion = 0x0300;
            CurrentPalette->palNumEntries = nent;
            /* Initialize entries */
            copyToPalette(CurrentPalette->palPalEntry, rgb, nent);
            /* Create the palette object */
            hPalette = CreatePalette(CurrentPalette);
        }
    }
    return (hPalette);
}
