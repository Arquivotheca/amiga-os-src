/*
 *  Photo CD Development Toolkit
 *
 *  image.c
 *  Low-level image management routines.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)image.c    1.120 - 92/06/03"
#endif
#include <windows.h>
#include <assert.h>
#include <errno.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "image.h"

/*
 * Platform-specific image header routines.
 */

PCDstatus
getImageInfo(HANDLE h, LPBITMAPINFO FAR *lpbp, LPINT lpDepth, 
             LPLONG lpRows, LPLONG lpCols,
             LPLONG lpPlaneBytes, LPLONG lpColumnBytes,
             char _huge * FAR *hpImage)
{
    LPBITMAPINFO    lpb;
    long            planeBytes;
    short           columnBytes;

    assert(lpbp != 0);
    assert(lpDepth != 0);
    assert(lpRows != 0);
    assert(lpCols != 0);
    assert(lpPlaneBytes != 0);
    assert(lpColumnBytes != 0);
    if ((lpb = (LPBITMAPINFO)GlobalLock(h)) == 0)
        return(ENOMEM);

    *lpDepth = lpb->bmiHeader.biBitCount;
    *lpRows = lpb->bmiHeader.biHeight;
    *lpCols = lpb->bmiHeader.biWidth;

    *hpImage = ((char _huge *)lpb + lpb->bmiHeader.biSize+PaletteSize(lpb));
    *lpbp = lpb;

    getPlaneCol(h, &planeBytes, &columnBytes);
    *lpPlaneBytes = planeBytes;
    *lpColumnBytes = columnBytes;

    return(pcdSuccess);
}

PCDstatus
makeNewImage(HANDLE h, LPBITMAPINFO FAR *lpbp, 
             HANDLE FAR *lpNewH, char _huge * FAR *hpImage)
{
    LPBITMAPINFO    lpOldB, lpNewB;
    RGBQUAD FAR     *lpOldRGB, FAR *lpNewRGB;
    int             nColors;
    long            planeBytes;
    short           columnBytes;
    char HUGE       *hpOldImage;

    paramck(h != 0);
    paramck(lpbp != 0);
    paramck(lpNewH != 0);
    paramck(hpImage != 0);

    if ((lpOldB = (LPBITMAPINFO)GlobalLock(h)) == 0)
        return(ENOMEM);

    if ((*lpNewH = GlobalAlloc(GMEM_MOVEABLE, GlobalSize(h))) == 0) {
        GlobalUnlock(h);
        return(ENOMEM);
    }

    assert(GlobalSize(*lpNewH) == GlobalSize(h));

    if ((lpNewB = (LPBITMAPINFO)GlobalLock(*lpNewH)) == 0) {
        GlobalUnlock(h);
        GlobalFree(*lpNewH);
        return(ENOMEM);
    }
    /*
     * Copy the BITMAPINFO header
     */
    *lpNewB = *lpOldB;

    /*
     * Copy the color table.
     */
    nColors = DibNumColors(lpOldB);
    lpOldRGB = lpOldB->bmiColors;
    lpNewRGB = lpNewB->bmiColors;
    while (nColors-- > 0)
        *lpNewRGB++ = *lpOldRGB++;

    /*
     * Image data starts here. XXX - check for alignment?
     */
    *hpImage = ((char _huge *)lpNewB + lpNewB->bmiHeader.biSize + 
                    PaletteSize(lpNewB));

    hpOldImage = ((char _huge *)lpOldB + lpOldB->bmiHeader.biSize + 
                    PaletteSize(lpOldB));

    getPlaneCol(h, &planeBytes, &columnBytes);
    setPlaneCol(*lpNewH, planeBytes, columnBytes);

    GlobalUnlock(h);
    *lpbp = lpNewB;
    return(pcdSuccess);
}


void
relseImage(HANDLE h)
{
    assert(h != 0);
    GlobalUnlock(h);
}

void
freeImage(HANDLE h)
{
    assert(h != 0);
    GlobalFree(h);
}

void
swapRowCol(LPBITMAPINFO lpb)
{
    long    tmp;
    assert(lpb != 0);

    tmp = lpb->bmiHeader.biHeight;
    lpb->bmiHeader.biHeight = lpb->bmiHeader.biWidth;
    lpb->bmiHeader.biWidth  = tmp;
}

/*
 * Windows DIB functions.
 */

unsigned short 
DibNumColors (VOID FAR *pv)
{
    int         bits;
    LPBITMAPINFOHEADER  lpbi;
    LPBITMAPCOREHEADER  lpbc;

    lpbi = ((LPBITMAPINFOHEADER)pv);
    lpbc = ((LPBITMAPCOREHEADER)pv);

    /*  With the BITMAPINFO format headers, the size of the palette
     *  is in biClrUsed, whereas in the BITMAPCORE - style headers, it
     *  is dependent on the bits per pixel ( = 2 raised to the power of
     *  bits/pixel).
     */
    if (lpbi->biSize != sizeof(BITMAPCOREHEADER)){
        if (lpbi->biClrUsed != 0)
            return (WORD)lpbi->biClrUsed;
        bits = lpbi->biBitCount;
    }
    else
        bits = lpbc->bcBitCount;

    switch (bits){
    case 1:
        return 2;
    case 4:
        return 16;
    case 8:
        return 256;
    default:
        /* A 24 bitcount DIB has no color table */
        return 0;
    }
}

unsigned short 
PaletteSize (pv)
VOID FAR * pv;
{
    LPBITMAPINFOHEADER lpbi;
    WORD           NumColors = 0;

    lpbi      = (LPBITMAPINFOHEADER)pv;
    NumColors = DibNumColors(lpbi);

    if (lpbi->biSize == sizeof(BITMAPCOREHEADER))
        return NumColors * sizeof(RGBTRIPLE);
    else
        return NumColors * sizeof(RGBQUAD);
}

RGBQUAD FAR * 
PaletteAddr(VOID FAR *pv)
{
    LPBITMAPINFOHEADER lpbi;

    lpbi = (LPBITMAPINFOHEADER)pv;
    return((RGBQUAD FAR *)((char FAR *)lpbi + lpbi->biSize));
}

#define PCD_PB_MAGIC    (0x01030507L)
/*
 * DIBs have no notion of plane and column bytes -
 * these get stored just after image data.
 */

void
getPlaneCol(HANDLE h, long FAR *lpPlane, short FAR *lpCol)
{
    LPBITMAPINFO    lpb;
    char _huge      *hpImage;
    long HUGE       *magicPtr;
    long HUGE       *pbPtr;
    short HUGE      *cbPtr;
    DWORD           imageSize, expectedSize;

    assert(h);
    assert(lpPlane);
    assert(lpCol);
    if ((lpb = (LPBITMAPINFO)GlobalLock(h)) == 0)
        return;

    hpImage = ((char _huge *)lpb + lpb->bmiHeader.biSize + 
                    PaletteSize(lpb));

    expectedSize = lpb->bmiHeader.biSize + PaletteSize(lpb) +
            lpb->bmiHeader.biSizeImage + sizeof(long) + sizeof(long) +
            sizeof(short);
    imageSize = GlobalSize(h);

    if (imageSize >= expectedSize) {
        magicPtr = (long HUGE *)(hpImage + lpb->bmiHeader.biSizeImage); 
        pbPtr = magicPtr + 1;
        cbPtr = (short HUGE *)(pbPtr + 1);
    }
    if (imageSize < expectedSize || *magicPtr != PCD_PB_MAGIC ||
            !*pbPtr || !*cbPtr) {
    /* Fake to defaults if obviously bogus */
        switch(lpb->bmiHeader.biBitCount) {
        case 24:
            *lpPlane = 1;
            *lpCol = 3;
            break;
        default:
            *lpPlane = 1;
            *lpCol = 1;
            break;
        }
    } else {
        *lpPlane = *pbPtr;
        *lpCol = *cbPtr;
    }
    GlobalUnlock(h);
}

void 
setPlaneCol(HANDLE h, long planeBytes, short columnBytes)
{
    LPBITMAPINFO    lpb;
    char _huge      *hpImage;
    long HUGE       *magicPtr;
    long HUGE       *pbPtr;
    short HUGE      *cbPtr;

    assert(h);
    if ((lpb = (LPBITMAPINFO)GlobalLock(h)) == 0)
        return;

    hpImage = ((char _huge *)lpb + lpb->bmiHeader.biSize+PaletteSize(lpb));

    /* Plane and column bytes are stashed in extra space after image data */
    magicPtr = (long HUGE *)(hpImage + lpb->bmiHeader.biSizeImage); 
    pbPtr = magicPtr + 1;
    cbPtr = (short HUGE *)(pbPtr + 1);

    *magicPtr = PCD_PB_MAGIC;
    *pbPtr = planeBytes;
    *cbPtr = columnBytes;

    GlobalUnlock(h);
}

