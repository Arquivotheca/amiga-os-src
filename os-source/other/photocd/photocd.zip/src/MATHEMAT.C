



/*\    
 *     Windows PCDopen, PCDrefOpen, PCDclose & PCDrefClose;
 *             PCDOopen, PCDOrefOpen, PCDOclose & PCDOrefClose.
 *
 *     source: Toolkit version 1.36 - 2-3-93.
 *
 *     Note use of PCD_IO_LEAVE_OPEN flag.
 *	
 *
\*/



struct _stat sbuf;


/*
 *  Open an Image Pac for I/O, allocate and fill the
 *  structure pointed to by PCDphotoPtr.
 */
PCDstatus FAR PASCAL PCDopen(path, pcdptr)
    LPSTR path;
    PCDphotoHdl FAR *pcdptr;
{
    OFSTRUCT of;
    int fd;
    PCDstatus err;
    PCDphotoPtr pcd;

    if ((fd = OpenFile(path, &of, OF_READ)) < 0) {
        if (!errno) 
            err = ENOENT;
          else
            err = errno;
        if (pcdptr)
            *pcdptr = (PCDphotoHdl) NULL;
        return err;
    }
    if ((err = PCDrefOpen (fd, pcdptr)) != pcdSuccess) /* create pcd struct */
        {
        (void) close(fd);
        return err;
        }
    GetPhotoPtr (*pcdptr, pcd);
    pcd->iostate.of = of;
    pcd->iostate.flags &= ~(PCD_IO_LEAVE_OPEN); /* we get to close 
                                                                                                                                                                it--not user */
    return pcdSuccess;
} /* end PCDopen */


PCDstatus FAR PASCAL PCDrefOpen(fd, pcdptr)
    int fd;
    PCDphotoHdl FAR *pcdptr;
{
    PCDstatus err = pcdSuccess;
    PCDphotoPtr pcd;
    unsigned char hdrbuf[20];
    unsigned char FAR *hdr = hdrbuf;
    unsigned char ipeclaimed, rotation, maxstep; 
    unsigned char bytes4tv[2], bytes16tv[2], bytesipe[2];
    short end4tv, end16tv, endipe;
    HANDLE hpcd;

    paramck(pcdptr != 0);
    if ((hpcd = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
                            sizeof(PCDphotoRec))) == 0) {
        err = ENOMEM;
        goto botch;
    }
    if ((pcd = (PCDphotoPtr)GlobalLock(hpcd)) == PCDNULL) {
        GlobalFree(hpcd);
        err = ENOMEM;
        goto botch;
    }
    mkphoto(pcd); /* Mark with magic number */
    pcd->hpcd = hpcd;
    pcd->iostate.fd = fd;
    pcd->iostate.throwInError = FALSE;
    if (_fstat(fd, &sbuf) != 0) {
        err = errno;
        goto botch;
    }
    pcd->iostate.filesize = sbuf.st_size;
    
    /* assume user must close file - reset in PCDopen if we opened file */
    pcd->iostate.flags = (PCD_IO_IS_OPEN | PCD_IO_LEAVE_OPEN);
    getVolInfo(&pcd->iostate); /* initialize vol ID info */
	pcd->iostate.hBuff = (HANDLE) NULL; /* avoid pain */
    /*
     *  Setup default state for image access
     *  Resolution = BASE
     *  Format = RGB
     *  Planar configuration = interleaved
     */
    pcd->step = PCD_BASE;
    pcd->format = PCD_RGB;
    pcd->planeBytes = 1;
    pcd->columnBytes = 3;

    /*
     * Get IPI
     */
    if (readImageInfo(pcd) != pcdSuccess) {
        if (!doCompat) {
            err = pcdBadFmt;
            goto botch;
        }
    } 
    else {
        PCDpacInfoPtr lpCachedInfo = 0;

        if (!pcd->pacInfo || 
            (lpCachedInfo = (PCDpacInfoPtr)GlobalLock(pcd->pacInfo)) == 0) {
            err = pcdBadFmt;
            goto botch;
        }
        /* Double check specification version */
        pcd->specVersLo = lpCachedInfo->version & 0xff;
        pcd->specVersHi = (lpCachedInfo->version >> 8) & 0xff;
        GlobalUnlock(pcd->pacInfo);
		if (pcd->specVersHi < SPEC_MAJOR_VERS ||
			(pcd->specVersHi == SPEC_MAJOR_VERS && pcd->specVersLo < SPEC_MINOR_VERS) ) {
	            err = pcdBadFmt;
    	        goto botch;
        }
    }
    /*
     *  Read in Image Pac Header.
     *  Would be nice just to read this into a structure,
     *  but this won't work because of alignment.
     */

    PCDsetMark(&pcd->iostate, 0, 0);
    if (read(pcd->iostate.fd, hdr, 20) != 20) {
/*XXX err = pcdIOerr; */
        goto botch1;
    }

	{
    long    seekloc = stob(1) + 1536;

    pcd->version = PCD_NEW_VERSION;
    _llseek(pcd->iostate.fd, seekloc, 0);
    read(pcd->iostate.fd, hdr, 20);

    pcd->imgno = hdr[1] | (hdr[0] << 8);
    hdr += 2;
    maxstep = hdr[0] & 0xc;
    rotation = hdr[0] & 0x3;
    ipeclaimed = hdr[0] & 0x10;
    bytes4tv[0] = hdr[1];
    bytes4tv[1] = hdr[2];
    bytes16tv[0] = hdr[3];
    bytes16tv[1] = hdr[4];
    bytesipe[0] = hdr[5];
    bytesipe[1] = hdr[6];
    }
    
   switch (rotation) {
    case 0:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_0);
        break;
    case 1:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_90);
        break;
    case 2:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_180);
        break;
    case 3:
        pcd->rotation = pcd->xform = EXTERNAL_XFORM(PCD_ROTATE_270);
        break;
    }
    switch (maxstep) {
    case 0x0:
        pcd->maxstep = PCD_BASE;
        break;
    case 0x4:
        pcd->maxstep = PCD_4BASE;
        break;
    case 0x8:
        pcd->maxstep = PCD_16BASE;
        break;
    default:
        err = pcdBadFmt;
        goto botch;
    }

    /*
     *  Seek pointers to high-resolution images.
     *  Image Pac seek pointers are sector offsets
     *  to the end of image data; we use byte offsets
     *  to the beginning of the data (more useful).
     */
    end4tv = (bytes4tv[0] << 8) | bytes4tv[1];
    end16tv = (bytes16tv[0] << 8) | bytes16tv[1];
    endipe = (bytesipe[0] << 8) | bytesipe[1];
    
    pcd->pos4tv = end4tv ? PCDS_4TV : 0L;
    pcd->pos16tv = end16tv ? stob(end4tv) : 0L; /* Byte offset to 16BASE ICA */
    if (endipe) {
        if (end16tv)
            pcd->posipe = stob(end16tv);
        else if (end4tv)
            pcd->posipe = stob(end4tv);
        else
            pcd->posipe = PCDS_4TVICA;
    } else
        pcd->posipe = 0L;
#ifndef NDEBUG
    if (pcd->maxstep == PCD_BASE)
        assert(!pcd->pos4tv && !pcd->pos16tv);
    if (pcd->maxstep == PCD_4BASE)
        assert(pcd->pos4tv && !pcd->pos16tv);
    if (pcd->maxstep == PCD_16BASE)
        assert(pcd->pos4tv && pcd->pos16tv);
    if (ipeclaimed)
        assert(pcd->posipe);
#endif
    pcd->huffid4 = (int) (hdr[18]);

    if ((err = PCDcloseFile(&pcd->iostate)) != pcdSuccess)
        goto botch;

    /*
     *  Miscellaneous initialization.
     */
    pcd->bounds.top = 0;
    pcd->bounds.left = 0;
    pcd->bounds.right = rowsiz(pcd->step);
    pcd->bounds.bottom = colsiz(pcd->step);

    pcd->check = (FARPROC) NULL;
    pcd->abort = (FARPROC) NULL;
    pcd->cDenominator = 0;

    pcd->palette = 0;

    if ((err = PCDcreatePalette((unsigned char FAR *)0, 0, 0, 256, (HANDLE)0, 
                    3, 3, 2, TRUE, TRUE, TRUE, &pcd->palette)) != pcdSuccess)
        goto botch;

    pcd->autoPalette = FALSE;
    err = pcdSuccess;
    GlobalUnlock(hpcd);
    *pcdptr = hpcd;
    return(0);

botch1:
    err = errno;
botch:
    if (pcdptr)
        *pcdptr = 0;
    if (hpcd && pcd) {
        if (pcd->iostate.fd >= 0 && pcd->iostate.flags & PCD_IO_IS_OPEN)
            (void) close(pcd->iostate.fd);
        if (pcd->pacInfo)
            GlobalFree(pcd->pacInfo);
    }
    if (hpcd) {
        if (pcd)
            GlobalUnlock(hpcd);
        GlobalFree(hpcd);
    }
    return (err);
}

/*
 *  Close an Image Pac and release resources.
 *  Do not close image pac file if user opened it. 
 */
PCDstatus FAR PASCAL PCDclose(hpcd)
    PCDphotoHdl hpcd;
{
    int rv = 0;
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);
    paramck(pcd->iostate.fd >= 0);
    if (!(pcd->iostate.flags & PCD_IO_LEAVE_OPEN))
        if (pcd->iostate.flags & PCD_IO_IS_OPEN) {
            if (close(pcd->iostate.fd) < 0)
                rv = errno ? errno : EIO;
    }

    if (pcd->palette)
        PCDfreePalette(pcd->palette);
    pcd->palette = 0;
    if (pcd->lpt4tv)
        PCDfree((PCDRAWDATA) pcd->lpt4tv);
    if (pcd->lpt16tv)
        PCDfree((PCDRAWDATA) pcd->lpt16tv);
    if (pcd->pacInfo) {
        GlobalFree(pcd->pacInfo);
    }
    GlobalUnlock(hpcd);
    GlobalFree(hpcd);
    return (rv);
} /* end PCDclose */


/*
 *  Close an Image Pac and release resources.
 *  Guarantees that image pac file remains open. 
 */
PCDstatus FAR PASCAL PCDrefClose(hpcd)
    PCDphotoHdl hpcd;
{
    PCDphotoPtr pcd;

    GetPhotoPtr(hpcd, pcd);
    pcd->iostate.flags &= PCD_IO_LEAVE_OPEN;
    return PCDclose(hpcd);
} /* end PCDrefClose */


				  



/* Overview Pac open and close functions */

/*
 *	Open an Overview Pac for I/O, allocate and fill the
 *	structure pointed to by PCDoviewPtr.
 */
PCDstatus FAR PASCAL PCDOopen(LPSTR path, PCDoviewHdl FAR *pcdptr)
{
	OFSTRUCT of;
	int fd;
	PCDstatus err;
	PCDoviewPtr pcdo;

	if ((fd = OpenFile(path, &of, OF_READ)) < 0) 
		return(ENOENT);
	if ((err = PCDOrefOpen (fd, pcdptr)) != pcdSuccess) {
		_lclose(fd);
		return err;
	}
	GetOviewPtr (*pcdptr, pcdo);
	pcdo->iostate.of = of;
	pcdo->iostate.flags &= ~(PCD_IO_LEAVE_OPEN); /* we get to close 
																																								it--not user */
	return pcdSuccess;
} /* end PCDOopen */


/*
 *	User has already opened file version of PCDOopen ****
 *  Open an Overview Pac for I/O, allocate and fill the
 *	structure pointed to by PCDoviewPtr.
 */
PCDstatus FAR PASCAL PCDOrefOpen(int fd, PCDoviewHdl FAR *pcdptr)
{
	PCDoviewPtr pcdo;
	PCDstatus theErr;
	struct opa FAR *lpOpa = 0;

	paramck(pcdptr);
	*pcdptr = (PCDoviewHdl) GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
											sizeof (PCDoviewRec));
	if (!*pcdptr)
		return(ENOMEM);
	if (!(pcdo = (PCDoviewPtr)GlobalLock(*pcdptr))) {
		GlobalFree(*pcdptr);
		return(ENOMEM);
	}

	mkoview(pcdo);	/* Mark with magic number */
	pcdo->iostate.fd = fd;
	pcdo->imgcount = 0;
	pcdo->imgno = 1;
	pcdo->step = PCD_BASE_OVER_16;
	pcdo->format = PCD_RGB;
	pcdo->xform = PCD_MIRROR_180;
	pcdo->planeBytes = 1;
	pcdo->columnBytes = 3;

	pcdo->iostate.throwInError = FALSE;
	if (fstat(fd, &sbuf) != 0) {
		RELEASEHANDLE(*pcdptr);
		GlobalFree(*pcdptr);
		*pcdptr = NULL;	
		return(ENOENT);
	}
	pcdo->iostate.filesize = sbuf.st_size;
	/* assume user has opened file; (caller resets if not so) */
	pcdo->iostate.flags = (PCD_IO_IS_OPEN | PCD_IO_LEAVE_OPEN);
	
	lpOpa = &(pcdo->opa);

	/*
	 *	Read in Overview Pac Attributes
	 */
	pcdo->iostate.seekloc = 0;
	if ( lseek(fd, 0L, SEEK_SET) != 0)
		theErr = errno;
	pcdo->iostate.seekloc = 0;
	theErr = PCDreadSome(&pcdo->iostate, (unsigned char FAR *)lpOpa,
								sizeof(pcdo->opa));


/*
	if (_fstrncmp(pcdo->opa.signature, "PCD_OPA", 7) != 0) {
		error(pcdBadFmt);
	}
*/
	if (_fstrncmp(pcdo->opa.signature, "PCD_OPA", 7) != 0 ||
		(pcdo->opa.verMajor < SPEC_MAJOR_VERS || 
		 (pcdo->opa.verMajor == SPEC_MAJOR_VERS && pcdo->opa.verMinor < SPEC_MINOR_VERS ))) {
			theErr = pcdBadFmt;
	} else
		pcdo->version = PCD_NEW_VERSION;

	pcdo->imgcount = ((pcdo->opa.nimages[0] & 0xff) << 8) | 
						(pcdo->opa.nimages[1] & 0xff);

	if (theErr != pcdSuccess) {
		RELEASEHANDLE(*pcdptr);
		GlobalFree(*pcdptr);
		return (theErr);
	}

	/* 
	 * Initialize volume ID information.
	 */

	getVolInfo(&pcdo->iostate);

	/*
	 * Set up default rotation.
	 */
	PCDOgetRotation(*pcdptr, &pcdo->xform);
	pcdo->xform = EXTERNAL_XFORM(pcdo->xform);
 	if ((theErr = PCDcloseFile(&pcdo->iostate)) == pcdSuccess) {
 	
	/*
	 * Default 332 palette.
	 */
	    theErr = PCDcreatePalette((unsigned char FAR *)0, 0, 0, 256, (HANDLE)0, 
						3, 3, 2, TRUE, TRUE, TRUE, &pcdo->palette);
	}

	RELEASEHANDLE(*pcdptr);
	if (theErr != pcdSuccess)
		GlobalFree(*pcdptr);
	return(theErr);
} /* end PCDOrefOpen */


#pragma	optimize("azegc", on)

/*
 *	Close an Overview Pac and release resources.
 *	close oview file only if opened by toolkit; do not close user-opened file. 
 */
PCDstatus FAR PASCAL PCDOclose(PCDoviewHdl hpcd)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);	
	if (!(pcdo->iostate.flags & PCD_IO_LEAVE_OPEN))
		if (pcdo->iostate.fd >= 0 && pcdo->iostate.flags & PCD_IO_IS_OPEN)
			_lclose(pcdo->iostate.fd);
	if (pcdo->palette)
		PCDfreePalette(pcdo->palette);
	pcdo->palette = 0;
	RELEASEHANDLE(hpcd);
	FREEHANDLE(hpcd);
	return(pcdSuccess);
} /* end PCDOclose */

/*
 *	Guarantee overview file stays open & 
 *  release overview handle & resources.
 */
PCDstatus FAR PASCAL PCDOrefClose(PCDoviewHdl hpcd)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);	
	pcdo->iostate.flags &= PCD_IO_LEAVE_OPEN; /* guarantee file stays open */
	return PCDOclose(hpcd);
} /* end PCDOrefClose */

