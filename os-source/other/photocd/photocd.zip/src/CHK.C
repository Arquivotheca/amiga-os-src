/*
 *  Photo CD Development Toolkit
 *
 *  pcdchk.c
 *  Low-level I/O and chunk management.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)chk.c  1.46 - 91/08/02"
#endif
#include <assert.h>
#include <windows.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#ifdef  NDEBUG
#define STATIC  static
#else
#define STATIC
#endif

lowchunkptr ycache, c1cache, c2cache;

/*
 *  Allocate a new chunk.  Should be balanced by calls to
 *  freechk().
 */
lowchunkptr newchk(pcd, step, num, chan, datsiz)
    PCDphotoPtr pcd;
    PCDresolution step;
    short num;
    short chan;
    long datsiz;
{
    lowchunkptr l;
    HANDLE hchkbytes;
    HANDLE hdatabytes;

    assert(pcd != PCDNULL);
    assert((step >= PCD_BASE_OVER_16) && (step <= PCD_BASE));
    assert((chan == Y_CHAN) || (chan == C1_CHAN) || (chan == C2_CHAN));
    assert(num >= 0);
#ifndef NDEBUG
    if (step == PCD_BASE_OVER_16)
        assert(num < 2);
    if (step == PCD_BASE_OVER_4)
        assert(num < 8);
    if (step == PCD_BASE)
        assert(num < 32);
#endif

    if ((hchkbytes = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
                                 sizeof(lowchunk))) == 0)
        return ((lowchunkptr) 0);
    if ((l = (lowchunkptr) GlobalLock(hchkbytes)) == 0) {
        GlobalFree(hchkbytes);
        return ((lowchunkptr) 0);
    }
    l->hchk = hchkbytes;
    l->hpcd = pcd->hpcd;
    l->step = step;
    l->num = num;
    l->chan = chan;
    if ((hdatabytes = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
                                    datsiz)) == 0) {
        GlobalUnlock(hchkbytes);
        GlobalFree(hchkbytes);
        return ((lowchunkptr) 0);
    }
    if ((l->data = (unsigned char HUGE *) GlobalLock(hdatabytes)) == 0) {
        GlobalUnlock(hchkbytes);
        GlobalFree(hchkbytes);
        GlobalFree(hdatabytes);
        return ((lowchunkptr) 0);
    }
    l->hdata = hdatabytes;
    GlobalUnlock(hchkbytes);
    GlobalUnlock(hdatabytes);
    return (l);
}

void freechk(l)
    lowchunkptr l;
{
    assert(l != (lowchunkptr) 0);
    assert(l->hdata != 0);
    assert(l->hchk  != 0);
    GlobalFree(l->hdata);
    GlobalFree(l->hchk);
}

/*
 *  This should be used to free a chunk that may be re-used
 *  later.
 */

void relsechk(l)
    lowchunkptr l;
{
    assert(l != (lowchunkptr) 0);
    GlobalUnlock(l->hdata);
    l->data = 0;
}

/*
 * Un-relse a chunk. Not complete. If handle is discarded, program crashes.
 */
void
chkrevive(l)
    lowchunkptr l;
{
    if (l->data == (lowchunkptr)0) {
        assert(l->hdata != 0);
        l->data = (unsigned char HUGE *) GlobalLock(l->hdata);
        assert(l->data != 0);
    }
}

/*
 *  Get a chunk.  Interface to higher toolkit layers.  This
 *  is currently pretty dumb.
 */
lowchunkptr getchk(pcd, step, num, chan)
    PCDphotoPtr pcd;
    PCDresolution step;
    short num;
    short chan;
{

    if (!chkestablish(pcd, step, num))
        return ((lowchunkptr) 0);
    switch (chan) {
    case Y_CHAN:
        return (ycache);
    case C1_CHAN:
        return (c2cache);
    case C2_CHAN:
        return (c1cache);
    }
}

/* Cache entry identified by a handle */
#define CACHEOK(l, pcd, step, num)  \
    (l->hpcd == pcd->hpcd) && (l->step == step) && (l->num == num)

chkestablish(pcd, step, num)
    PCDphotoPtr pcd;
    PCDresolution step;
    short num;
{
    register unsigned char HUGE *yp, HUGE *c1p, HUGE *c2p;
    register int i;
    int totrows, rowlen;

    assert(pcd);

    if (ycache == (lowchunkptr) 0) {
        ycache = newchk(pcd, step, num, Y_CHAN, CHKDATASIZ);
        if (ycache == (lowchunkptr) 0)
            return (0);
        c1cache = newchk(pcd, step, num, C1_CHAN, CHKDATASIZ);
        if (c1cache == (lowchunkptr) 0) {
            freechk(ycache);
            return (0);
        }
        c2cache = newchk(pcd, step, num, C2_CHAN, CHKDATASIZ);
        if (c2cache == (lowchunkptr) 0) {
            freechk(ycache);
            freechk(c1cache);
            return (0);
        }
        assert(ycache->data != 0);
        assert(c1cache->data != 0);
        assert(c2cache->data != 0);
    } else {
        if (CACHEOK(ycache, pcd, step, num) &&
          CACHEOK(c1cache, pcd, step, num) &&
          CACHEOK(c2cache, pcd, step, num)) {
            assert(ycache->data != 0);
            assert(c1cache->data != 0);
            assert(c2cache->data != 0);
            return (1);
        }
        if (ycache->data == 0)
            chkrevive(ycache);
        if (c1cache->data == 0)
            chkrevive(c1cache);
        if (c2cache->data == 0)
            chkrevive(c2cache);

        assert(ycache->data != 0);
        assert(c1cache->data != 0);
        assert(c2cache->data != 0);
    }
    switch (step) {
    case PCD_BASE_OVER_16:
        lseek(pcd->fd, PCDS_TV16 + chtob(num), 0);
        totrows = 64;
        break;
    case PCD_BASE_OVER_4:
        lseek(pcd->fd, PCDS_TV4 + chtob(num), 0);
        totrows = 32;
        break;
    case PCD_BASE:
        lseek(pcd->fd, PCDS_TV + chtob(num), 0);
        totrows = 16;
        break;
    }
    ycache->hpcd = pcd->hpcd; 
    c1cache->hpcd = pcd->hpcd; 
    c2cache->hpcd = pcd->hpcd; 

    ycache->step = step; ycache->num = num;
    c1cache->step = step; c1cache->num = num;
    c2cache->step = step; c2cache->num = num;
    yp = ycache->data;

    c1p = c1cache->data + ((CHKDATASIZ * 3) / 4);
    c2p = c2cache->data + ((CHKDATASIZ * 3) / 4);
    rowlen = rowsiz(step);

    for (i = 0; i < totrows / 2; i++) {
        int nb = 0;

        nb = read(pcd->fd, yp, rowlen * 2);
        assert(nb == (rowlen * 2));
        yp += nb;

        nb = read(pcd->fd, c1p, rowlen / 2);
        assert(nb == (rowlen / 2));
        c1p += nb;

        nb = read(pcd->fd, c2p, rowlen / 2);
        assert(nb == (rowlen / 2));
        c2p += nb;
    }

    assert(CHKDATASIZ < (64L * 1024L)); /* Second arg is an int */
    rchroma(c1cache->data, CHKDATASIZ, rowlen);
    rchroma(c2cache->data, CHKDATASIZ, rowlen);
    return (1);
}

/*
 *  Replicate chroma from (cp + 3/4 * size) to cp.
 *  Output line stride is |stride|.
 */
STATIC void rchroma(cp, size, stride)
    register unsigned char HUGE *cp;
    unsigned int size, stride;
{
    register unsigned char HUGE *sp;
    register int i;
    unsigned char HUGE *pp;

    assert(!(size % 4));
    assert(!(stride % 2));
    assert(stride != 0);
    assert(cp != 0);

    sp = cp + 3 * (size / 4);
    while (size) {
        assert(size > 0);
        pp = cp;
        for (i = 0; i < stride / 2; i++) {  /* columns */
            *cp++ = *sp;
            *cp++ = *sp++;
        }
        for (i = 0; i < stride; i++)        /* rows */
            *cp++ = *pp++;
        size -= (2 * stride);
    }
    assert(cp == sp);   /* should end up in the same place */
}

char HUGE *memcpyg(dst, src, n, dstskip)
    register unsigned char HUGE *dst, HUGE *src;
    int n;
    int dstskip;
{
    char HUGE *rv;

    rv = dst;
    if (dstskip == 1) {
        while (n--)
            *dst++ = *src++;
        return (rv);
    }
    while (n--) {
        *dst = *src++;
        dst += dstskip;
    }
    return (rv);
}

char HUGE *memcpy8to4(dst, src, n, dstskip)
    register unsigned char HUGE *dst, HUGE *src;
    int n;
    int dstskip;
{
    char HUGE *rv;

    rv = dst;
    if (dstskip > 0) {
        while (n > 0) {
            *dst = ((src[1] >> 4) & 0xf) | (src[0] & 0xf0);
            dst += dstskip;
            src += 2;
            n -= 2;
        }
    } else {
        while (n > 0) {
            *dst = ((src[0] >> 4) & 0xf) | (src[1] & 0xf0);
            dst += dstskip;
            src += 2;
            n -= 2;
        }
    }
    return(rv);
}

char HUGE *memcpyv8to4(dst, src, n, dstskip, loworder)
    register unsigned char HUGE *dst, HUGE *src;
    int n;
    int dstskip;
    int loworder;
{
    char HUGE *rv;

    rv = dst;

    if (loworder) { 
        while (n > 0) {
            *dst = (*dst & 0xf0 ) | (*src++ >> 4) & 0xf;
            dst += dstskip;
            n--;
        }
    } else {
        while (n > 0) {
            *dst = (*src++ & 0xf0) | (*dst & 0xf);
            dst += dstskip;
            n--;
        }
    }
    return (rv);
}

#include <stdio.h>
state(buf, fmt, a1, a2, a3, a4, a5, a6)
    unsigned char *buf;
    char *fmt;
    char *a1, *a2, *a3, *a4, *a5, *a6;
{

    fprintf(stderr, fmt, a1, a2, a3, a4, a5, a6);
    fprintf(stderr, ": %02x%02x %02x%02x %02x%02x %02x%02x\n",
      buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7]);
}
