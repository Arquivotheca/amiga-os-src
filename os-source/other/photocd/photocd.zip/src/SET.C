/*
 *	Photo CD Development Toolkit
 *
 *	set.c
 *	Set primitives used by in-place mapping functions.
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)set.c	1.120 - 92/06/03"
#endif
#include <windows.h>
#include "set.h"

/*
 * Create a set capable of holding up to max elements
 */
SET
allocset(long max)
{
	HANDLE	h;
	SET		s;

	max += 3;
	max /= 4;
	max += 4 - (max & 3);
	h = GlobalAlloc(GMEM_FIXED|GMEM_ZEROINIT, max + 4);
	if (h == 0)
		return(0);
	
	if (s = (SET)GlobalLock(h)) {
		s->size = max;
		s->h = h;
	}
	return(s);
}

void
emptyset(SET s)
{
	long				size;
	unsigned char HUGE	*cp;

	if (!s)
		return;
	for (size = 0, cp = s->bmap; size < s->size; size++, cp++)
		cp = 0;
}

void
freeset(SET s)
{
	HANDLE	h;

	if (!s)
		return;
	h = s->h;
	GlobalUnlock(h);
	GlobalFree(h);
	return;
}

void
insert(SET s, long m)
{
	long	whichchar = m / 8;
	long	whichbit = m % 8;
	unsigned char HUGE *lp = (unsigned char HUGE *)s->bmap;

	lp[whichchar] |= ((unsigned char)1) << (whichbit);
}

void
delete(SET s, long m)
{
	long	whichchar = m / 8;
	long	whichbit = m % 8;
	unsigned char HUGE *lp = (unsigned char HUGE *)s->bmap;

	lp[whichchar] &= ~(((unsigned char)1) << (whichbit));
}

BOOL
member(SET s, long m)
{
	long	whichchar = m / 8;
	long	whichbit = m % 8;
	unsigned char HUGE *lp = (unsigned char HUGE *)s->bmap;

	return((lp[whichchar] & ((unsigned char)1) << (whichbit)) != 0L);
}
