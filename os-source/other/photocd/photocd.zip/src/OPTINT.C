/*
 *	Photo CD Development Toolkit
 *
 *	optint.c
 *	optimized interpolation primitives
 * 		included by interp.c twice
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)optint.c	1.48 - 92/06/03"
#endif

#include <windows.h>
#include <assert.h>
#include "pcdlib.h"
#include "pcdpriv.h"


void hlinear2(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short nextSrc, nextNext;
	register unsigned short iv1, iv2;

	assert(syndrome >= 0 || syndrome <= (2 - 1));
	assert(base);
	assert(dst);
	assert(count >= 0);

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = 2 - syndrome;
	nextMult = syndrome;

	switch (srcMult) {
	case 1:
		while (count) {
			iv1 = base[src] + base[next];
			iv2 = iv1 + base[nextSrc] + base[nextNext];

			iv1++;
			*dst = (unsigned char)(iv1 >> 1);
			dst += colBytes;

			iv2 += 2;
			*dst = (unsigned char)(iv2 >> 2);
			dst += colBytes;

			base++;
			count -= 2;
		}
		return;
	case 2:
		while (count) {
			iv1 = base[src] + base[nextSrc];
			*dst = (unsigned char)base[src];
			dst += colBytes;
			iv1++;
			*dst = (unsigned char)(iv1 >> 1);
			dst += colBytes;
			base++;
			count -= 2;
		}
		return;
	}
}

void hlinear4(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short factor = 4;
	short nextSrc, nextNext;
	register unsigned short iv1, iv2, iv3, iv4;

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = factor - syndrome;
	nextMult = syndrome;

	switch (srcMult) {
	case 4:
		while (count) {
			iv1 = base[src];
			iv3 = iv1 + base[nextSrc];
			iv4 = iv3 + (base[nextSrc] << 1);
			iv2 = iv3 + (iv1 << 1);

			iv2 += 2;
			iv3++;
			iv4 += 2;

			*dst = (unsigned char)(iv1);
			dst += colBytes;
			*dst = (unsigned char)(iv2 >> 2);
			dst += colBytes;
			*dst = (unsigned char)(iv3 >> 1);
			dst += colBytes;
			*dst = (unsigned char)(iv4 >> 2);
			dst += colBytes;

			base++;
			count -= 4;
		}
		return;
	case 3:
		while (count) {
			iv1 = (3 * base[src]) + base[next];
			iv1 += 2;
			iv2 = ((9 * base[src])
			 	  + (3 * base[nextSrc])
			 	  + (3 * base[next])
			 	  + (base[nextNext]));
			iv2 += 8;
			iv3 = ((3 * base[src])
			 	  + (3 * base[nextSrc])
			 	  + (base[next])
			 	  + (base[nextNext]));
			if (iv3 & 4) iv3 += 4;
			iv4 = ((3 * base[src])
			 	  + (9 * base[nextSrc])
			 	  + (base[next])
			 	  + (3 * base[nextNext]));
			iv4 += 8;

			*dst = (unsigned char)(iv1 >> 2);
			dst += colBytes;
			*dst = (unsigned char)(iv2 >> 4);
			dst += colBytes;
			*dst = (unsigned char)(iv3 >> 3);
			dst += colBytes;
			*dst = (unsigned char)(iv4 >> 4);
			dst += colBytes;
			base++;
			count -= 4;
		}
		return;
	case 2:
		while (count) {
			iv1 = base[src] + base[next];
			iv1++;
			iv2 = ((3 * base[src])
			 	  + (base[nextSrc])
			 	  + (3 * base[next])
			 	  + (base[nextNext]));
			if (iv2 & 4) iv2 += 4;
			iv3 = ((base[src])
			 	  + (base[nextSrc])
			 	  + (base[next])
			 	  + (base[nextNext]));
			iv3 += 2;
			iv4 = ((base[src])
			 	  + (3 * base[nextSrc])
			 	  + (base[next])
			 	  + (3 * base[nextNext]));
			iv4 += 4;

			*dst = (unsigned char)(iv1 >> 1);
			dst += colBytes;
			*dst = (unsigned char)(iv2 >> 3);
			dst += colBytes;
			*dst = (unsigned char)(iv3 >> 2);
			dst += colBytes;
			*dst = (unsigned char)(iv4 >> 3);
			dst += colBytes;
			base++;
			count -= 4;
		}
		return;
	case 1:
		while (count) {
			iv1 = ((base[src]) + (3 * base[next]));
			iv1 += 2;
			iv2 = ((3 * base[src])
			 	  + (base[nextSrc])
			 	  + (9 * base[next])
			 	  + (3 * base[nextNext]));
			iv2 += 8;
			iv3 = ((base[src])
			 	  + (base[nextSrc])
			 	  + (3 * base[next])
			 	  + (3 * base[nextNext]));
			iv3 += 4;
			iv4 = ((base[src])
			 	  + (3 * base[nextSrc])
			 	  + (3 * base[next])
			 	  + (9 * base[nextNext]));
			iv4 += 8;

			*dst = (unsigned char)(iv1 >> 2);
			dst += colBytes;
			*dst = (unsigned char)(iv2 >> 4);
			dst += colBytes;
			*dst = (unsigned char)(iv3 >> 3);
			dst += colBytes;
			*dst = (unsigned char)(iv4 >> 4);
			dst += colBytes;
			base++;
			count -= 4;
		}
		return;
	}
}
 

void hlinear8(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char HUGE *dst, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short factminus1, factsquared;
	short factor = 8;
	short nextSrc, nextNext;
	register unsigned short iv;

	factminus1 = factor - 1;
	factsquared = factor * factor;

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = factor - syndrome;
	nextMult = syndrome;

	while (count) {
/* 0 */
		iv = (srcMult  * 8  * base[src])
		 	  + (srcMult  * 0 * base[nextSrc])
		 	  + (nextMult * 8  * base[next])
		 	  + (nextMult * 0 * base[nextNext]);
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 1 */
		iv = ((srcMult  * 7  * base[src])
		 	  + (srcMult  * 1 * base[nextSrc])
		 	  + (nextMult * 7  * base[next])
		 	  + (nextMult * 1 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 2 */
		iv = ((srcMult  * 6  * base[src])
		 	  + (srcMult  * 2 * base[nextSrc])
		 	  + (nextMult * 6  * base[next])
		 	  + (nextMult * 2 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 3 */
		iv = ((srcMult  * 5  * base[src])
		 	  + (srcMult  * 3 * base[nextSrc])
		 	  + (nextMult * 5  * base[next])
		 	  + (nextMult * 3 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 4 */
		iv = ((srcMult  * 4  * base[src])
		 	  + (srcMult  * 4 * base[nextSrc])
		 	  + (nextMult * 4  * base[next])
		 	  + (nextMult * 4 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 5 */
		iv = ((srcMult  * 3  * base[src])
		 	  + (srcMult  * 5 * base[nextSrc])
		 	  + (nextMult * 3  * base[next])
		 	  + (nextMult * 5 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 6 */
		iv = ((srcMult  * 2  * base[src])
		 	  + (srcMult  * 6 * base[nextSrc])
		 	  + (nextMult * 2  * base[next])
		 	  + (nextMult * 6 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 7 */
		iv = ((srcMult  * 1  * base[src])
		 	  + (srcMult  * 7 * base[nextSrc])
		 	  + (nextMult * 1  * base[next])
		 	  + (nextMult * 7 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
		base++;
		count -= 8;
	}
}
