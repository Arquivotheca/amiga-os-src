/*
 *	Photo CD Development Toolkit
 *
 *	oview.c
 *	Open, close, and access methods for variables in a
 *	PCDoviewRec.
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 *
 *      K.S. 8-12-92
 * catalog image revision: added PCDOloadImageR(), PCDOgetBlockR\(), 
 * PCDOgetBlockQuicklyR(), and PCDOgetQuadRect(). Functions are included if 
 * ENABLE_CATALOG_CALLS is defined.
 *  �TS4,8,12,16,20,24,28�
 */

/* LINTLIBRARY */
#ifdef	IDENT
#ident	"@(#)oview.c	1.97 - 92/06/03"
#endif
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <windows.h>
#include <string.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "RectCalc.h"
#include "pcdovw.h"
#include "util.h"
#include "quant.h"
#include "raw.h"
#include "interp.h"
#include "image.h"

/* This code supports the following versions of the PhotoCD spec */
#define	ALT_VERS_OK	1

#ifndef	SPEC_MAJOR_VERS
#define	SPEC_MAJOR_VERS	0
#endif
#ifndef	SPEC_MINOR_VERS
#define	SPEC_MINOR_VERS	6
#endif

#ifdef	ALT_VERS_OK
#ifndef	SPEC_ALT_MINOR_VERS
#define	SPEC_ALT_MINOR_VERS	5
#endif
#endif

extern struct _stat sbuf;
#ifdef	NDEBUG
#define	STATIC	static
#else
#define	STATIC
#endif

/* MSC 6.0 seems to drop the ball optimizing this function */
#pragma	optimize("azegc", off)
/*
 *	Open an Overview Pac for I/O, allocate and fill the
 *	structure pointed to by PCDoviewPtr.
 */
PCDstatus FAR PASCAL PCDOopen(LPSTR path, PCDoviewHdl FAR *pcdptr)
{
	OFSTRUCT of;
	int fd;
	PCDstatus err;
	PCDoviewPtr pcdo;

	if ((fd = OpenFile(path, &of, OF_READ)) < 0) 
		return(ENOENT);
	if ((err = PCDOrefOpen (fd, pcdptr)) != pcdSuccess) {
		_lclose(fd);
		return err;
	}
	GetOviewPtr (*pcdptr, pcdo);
	pcdo->iostate.of = of;
	pcdo->iostate.flags &= ~(PCD_IO_LEAVE_OPEN); /* we get to close 
																																								it--not user */
	return pcdSuccess;
} /* end PCDOopen */


/*
 *	User has already opened file version of PCDOopen ****
 *  Open an Overview Pac for I/O, allocate and fill the
 *	structure pointed to by PCDoviewPtr.
 */
PCDstatus FAR PASCAL PCDOrefOpen(int fd, PCDoviewHdl FAR *pcdptr)
{
	PCDoviewPtr pcdo;
	PCDstatus theErr;
	struct opa FAR *lpOpa = 0;

	paramck(pcdptr);
	*pcdptr = (PCDoviewHdl) GlobalAlloc(GMEM_ZEROINIT|GMEM_MOVEABLE,
											sizeof (PCDoviewRec));
	if (!*pcdptr)
		return(ENOMEM);
	if (!(pcdo = (PCDoviewPtr)GlobalLock(*pcdptr))) {
		GlobalFree(*pcdptr);
		return(ENOMEM);
	}

	mkoview(pcdo);	/* Mark with magic number */
	pcdo->iostate.fd = fd;
	pcdo->imgcount = 0;
	pcdo->imgno = 1;
	pcdo->step = PCD_BASE_OVER_16;
	pcdo->format = PCD_RGB;
	pcdo->xform = PCD_MIRROR_180;
	pcdo->planeBytes = 1;
	pcdo->columnBytes = 3;

	pcdo->iostate.throwInError = FALSE;
	if (_fstat(fd, &sbuf) != 0) {
		RELEASEHANDLE(*pcdptr);
		GlobalFree(*pcdptr);
		*pcdptr = (PCDoviewHdl) NULL;	
		return(ENOENT);
	}
	pcdo->iostate.filesize = sbuf.st_size;
	/* assume user has opened file; (caller resets if not so) */
	pcdo->iostate.flags = (PCD_IO_IS_OPEN | PCD_IO_LEAVE_OPEN | PCD_IO_USE_BUF);
	pcdo->iostate.hBuff = (HANDLE)NULL;
	pcdo->iostate.dosAlloc = 0L;
	lpOpa = &(pcdo->opa);

	/*
	 *	Read in Overview Pac Attributes
	 */
	pcdo->iostate.seekloc = 0;
	if ( lseek(fd, 0L, SEEK_SET) != 0)
		theErr = errno;
   	theErr = PCDreadSome(&pcdo->iostate, (unsigned char FAR *)lpOpa,
								sizeof(pcdo->opa));


/*
	if (_fstrncmp(pcdo->opa.signature, "PCD_OPA", 7) != 0) {
		error(pcdBadFmt);
	}
*/
		if (_fstrncmp(pcdo->opa.signature, "PCD_OPA", 7) != 0 ||
		(pcdo->opa.verMajor < SPEC_MAJOR_VERS || 
		 (pcdo->opa.verMajor == SPEC_MAJOR_VERS && pcdo->opa.verMinor < SPEC_MINOR_VERS ))) {
#ifdef	ENHANCED_COMPAT
		extern BOOL doCompat;

		if (doCompat) {
			_fmemmove(&(pcdo->opa.ope), &(pcdo->opa.signature), 1024);
			if (pcdo->opa.nimages[0]) {
/* guess this is a wicked old disc: otherwise > 256 images */
				pcdo->opa.nimages[1] = pcdo->opa.nimages[0];
				pcdo->opa.nimages[0] = pcdo->opa.ope;
				pcdo->version = PCD_OLD_VERSION;
			} else {
				pcdo->version = PCD_NEW_VERSION;
			}
		} else
#endif /* ENHANCED_COMPAT */
			theErr = pcdBadFmt;
	} else
		pcdo->version = PCD_NEW_VERSION;

	pcdo->imgcount = ((pcdo->opa.nimages[0] & 0xff) << 8) | 
						(pcdo->opa.nimages[1] & 0xff);

	if (theErr != pcdSuccess) {
		RELEASEHANDLE(*pcdptr);
		GlobalFree(*pcdptr);
		return (theErr);
	}

	/* 
	 * Initialize volume ID information.
	 */

	getVolInfo(&pcdo->iostate);

	/*
	 * Set up default rotation.
	 */
	PCDOgetRotation(*pcdptr, &pcdo->xform);
	pcdo->xform = EXTERNAL_XFORM(pcdo->xform);
 	if ((theErr = PCDcloseFile(&pcdo->iostate)) == pcdSuccess) {
 	
	/*
	 * Default 332 palette.
	 */
	    theErr = PCDcreatePalette((unsigned char FAR *)0, 0, 0, 256, (HANDLE)0, 
						3, 3, 2, TRUE, TRUE, TRUE, &pcdo->palette);
	}

	RELEASEHANDLE(*pcdptr);
	if (theErr != pcdSuccess)
		GlobalFree(*pcdptr);
	return(theErr);
} /* end PCDOrefOpen */


#pragma	optimize("azegc", on)

/*
 *	Close an Overview Pac and release resources.
 *	close oview file only if opened by toolkit; do not close user-opened file. 
 */
PCDstatus FAR PASCAL PCDOclose(PCDoviewHdl hpcd)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);	
	if (!(pcdo->iostate.flags & PCD_IO_LEAVE_OPEN))
		if (pcdo->iostate.fd >= 0 && pcdo->iostate.flags & PCD_IO_IS_OPEN)
			_lclose(pcdo->iostate.fd);
	if (pcdo->palette)
		PCDfreePalette(pcdo->palette);
	pcdo->palette = 0;
	if (pcdo->iostate.hBuff)
		GlobalFree (pcdo->iostate.hBuff);
	if (pcdo->iostate.dosAlloc)
		GlobalDosFree (LOWORD(pcdo->iostate.dosAlloc));
	RELEASEHANDLE(hpcd);
	FREEHANDLE(hpcd);
	return(pcdSuccess);
} /* end PCDOclose */

/*
 *	Guarantee overview file stays open & 
 *  release overview handle & resources.
 */
PCDstatus FAR PASCAL PCDOrefClose(PCDoviewHdl hpcd)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);	
	pcdo->iostate.flags &= PCD_IO_LEAVE_OPEN; /* guarantee file stays open */
	return PCDOclose(hpcd);
} /* end PCDOrefClose */

/*
 *	Return supported resolutions:
 */

PCDstatus FAR PASCAL PCDOgetCount(hpcd, lpImgCnt)
	PCDoviewHdl hpcd;
	short FAR *lpImgCnt;
{
	PCDoviewPtr	pcdo;

	paramck(lpImgCnt);
	GetOviewPtr(hpcd, pcdo);

	*lpImgCnt = pcdo->imgcount;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

/*
 *	Select a resolution |step| and pixel type |format| for
 *	I/O from the specified PCDoviewPtr.
 */
PCDstatus FAR PASCAL PCDOsetSelect(hpcd, wImgNo)
	PCDoviewHdl hpcd;
	short wImgNo;
{
	PCDoviewPtr	pcdo;
	PCDstatus	res = pcdSuccess;

	GetOviewPtr(hpcd, pcdo);
	if ((wImgNo > 0) && (wImgNo <= pcdo->imgcount)) {
		pcdo->imgno = wImgNo;
		PCDOgetRotation(hpcd, &pcdo->xform);
		pcdo->xform = EXTERNAL_XFORM(pcdo->xform);
	} else
		res = pcdBadParam;
	RELEASEHANDLE(hpcd);
	return(res);
}

PCDstatus FAR PASCAL 
PCDOgetSelect(PCDoviewHdl hpcd, short FAR *lpwImgNo)
{
	PCDoviewPtr	pcdo;

	paramck(lpwImgNo);
	GetOviewPtr(hpcd, pcdo);
	*lpwImgNo = pcdo->imgno;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

/*
 *	Get the size of the image currently selected by
 *	|pcd->step|.
 */


PCDstatus FAR PASCAL PCDOgetSize(hpcd, r)
	PCDoviewHdl hpcd;
	LPRECT	   r;
{
	PCDoviewPtr	pcdo;

	paramck(r);
	GetOviewPtr(hpcd, pcdo);

	r->top = 0;
	r->left = 0;
	if (pcdo->xform & PCD_90_ROTATION) {
		r->right = colsiz(pcdo->step);
		r->bottom = rowsiz(pcdo->step);
	} else {
		r->bottom = colsiz(pcdo->step);
		r->right = rowsiz(pcdo->step);
	}

	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

/*
 *	Set values for plane and column bytes.
 */
PCDstatus FAR PASCAL PCDOsetPlaneColumn(hpcd, planeBytes, columnBytes)
	PCDoviewHdl hpcd;
	long planeBytes;
	short columnBytes;
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	pcdo->planeBytes = planeBytes;
	pcdo->columnBytes = columnBytes;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

/*
 *	Get the values for plane and column bytes.
 */
PCDstatus FAR PASCAL PCDOgetPlaneColumn(hpcd, lpPlaneBytes, lpColumnBytes)
	PCDoviewHdl hpcd;
	long FAR *lpPlaneBytes;
	short FAR *lpColumnBytes;
{
	PCDoviewPtr	pcdo;

	paramck(lpPlaneBytes);
	paramck(lpColumnBytes);
	GetOviewPtr(hpcd, pcdo);

	*lpPlaneBytes = pcdo->planeBytes;
	*lpColumnBytes = pcdo->columnBytes;

	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOsetProgress(PCDoviewHdl hpcd, FARPROC lpfnCheck)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	return(pcdLazyHacker);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOsetTransform(PCDoviewHdl hpcd, PCDtransform op)
{
	PCDoviewPtr	pcdo;

	paramck(validTransform(op));
	GetOviewPtr(hpcd, pcdo);
	pcdo->xform = EXTERNAL_XFORM(op);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOgetTransform(PCDoviewHdl hpcd, PCDtransform FAR *lpOp)
{
	PCDoviewPtr	pcdo;

	paramck(lpOp);
	GetOviewPtr(hpcd, pcdo);
	*lpOp = EXTERNAL_XFORM(pcdo->xform);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOgetAutoPalette(PCDoviewHdl hpcd, BOOL FAR *lpbOn)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	return(pcdLazyHacker);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOsetAutoPalette(PCDoviewHdl hpcd, BOOL bOn)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	return(pcdLazyHacker);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOsetPalette(PCDoviewHdl hpcd, PCDpaletteHdl hpal)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	if (pcdo->palette)
		PCDfreePalette(pcdo->palette);
	pcdo->palette = hpal;
	incPalRef(hpal);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL PCDOgetPalette(PCDoviewHdl hpcd, PCDpaletteHdl FAR *lphpal)
{
	PCDoviewPtr	pcdo;

	paramck(lphpal);
	GetOviewPtr(hpcd, pcdo);
	*lphpal = pcdo->palette;
	incPalRef(pcdo->palette);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}


PCDstatus FAR PASCAL 
PCDOgetResolution(PCDoviewHdl hpcd, PCDresolution FAR *lpRes)
{
	PCDoviewPtr	pcdo;

	paramck(lpRes);
	GetOviewPtr(hpcd, pcdo);
	*lpRes = pcdo->step;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDOsetResolution(PCDoviewHdl hpcd, PCDresolution res)
{
	PCDoviewPtr	pcdo;

	paramck(res == PCD_BASE_OVER_64 || res == PCD_BASE_OVER_16);
	GetOviewPtr(hpcd, pcdo);
	pcdo->step = res;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDOgetRotation(PCDoviewHdl hpcd, PCDtransform FAR *lpXform)
{
	PCDoviewPtr	pcdo;
	PCDstatus rv = pcdSuccess;

	paramck(lpXform);
	GetOviewPtr(hpcd, pcdo);
	if (pcdo->imgno < N_OPA_ATTR - 1) {
		switch (pcdo->opa.attributes[pcdo->imgno - 1] & 0x3) {
		case 0:
			*lpXform = PCD_ROTATE_0;
			break;
		case 1:
			*lpXform = PCD_ROTATE_90;
			break;
		case 2:
			*lpXform = PCD_ROTATE_180;
			break;
		case 3:
			*lpXform = PCD_ROTATE_270;
			break;
		}
	} else
		rv = pcdBadParam;/*XXX*/
	RELEASEHANDLE(hpcd);
	return(rv);
}


PCDstatus FAR PASCAL 
PCDOgetFormat(PCDoviewHdl hpcd, PCDformat FAR *lpFmt)
{
	PCDoviewPtr	pcdo;

	paramck(lpFmt);
	GetOviewPtr(hpcd, pcdo);
	*lpFmt = pcdo->format;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDOsetFormat(PCDoviewHdl hpcd, PCDformat fmt)
{
	PCDoviewPtr	pcdo;

	paramck(validFormat(fmt));
	GetOviewPtr(hpcd, pcdo);
	if (fmt == PCD_SINGLE || fmt == PCD_PALETTE) {
		pcdo->planeBytes = 1;
		pcdo->columnBytes = 1;
	} else if (pcdo->columnBytes == 1) {
		pcdo->planeBytes = 1;
		pcdo->columnBytes = 3;
	}
	pcdo->format = fmt;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDOsetDiscChanged(PCDoviewHdl hpcd, FARPROC lpDiscChg, long lData)
{
	PCDoviewPtr	pcdo;

	GetOviewPtr(hpcd, pcdo);
	pcdo->iostate.volChg = lpDiscChg;
	pcdo->iostate.volChgData = lData;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

PCDstatus FAR PASCAL 
PCDOgetDiscChanged(PCDoviewHdl hpcd, FARPROC FAR *lplpDiscChg, 
					long FAR *lplData)
{
	PCDoviewPtr	pcdo;

	paramck(lplpDiscChg);
	paramck(lplData);
	GetOviewPtr(hpcd, pcdo);
	*lplpDiscChg = pcdo->iostate.volChg;
	*lplData = pcdo->iostate.volChgData;
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}


PCDstatus FAR PASCAL
PCDOgetFriend(PCDoviewHdl hpcd, LPSTR lpPath)
{
	PCDoviewPtr	pcdo;

	paramck(lpPath);
	GetOviewPtr(hpcd, pcdo);
	wsprintf(lpPath, "img%4.4d.pcd", pcdo->imgno);
	RELEASEHANDLE(hpcd);
	return(pcdSuccess);
}

/*
 *	Return the number of bytes a row of |width| pixels will
 *	occupy.
 */
PCDstatus FAR PASCAL PCDOgetBytesPerRow(hpcd, width, rowbytes)
	PCDoviewHdl hpcd;
	short width;
	long FAR *rowbytes;
{
	PCDoviewPtr pcdo;
	int rv;

	paramck(rowbytes != NULL);
	GetOviewPtr(hpcd, pcdo);
	if (pcdo->format == PCD_SINGLE || pcdo->format == PCD_PALETTE) 
		rv = width;
	else
		rv = (width * pcdo->columnBytes);
	GlobalUnlock(hpcd);
	*rowbytes = rv;
	return(pcdSuccess);
}

PCDstatus FAR PASCAL
PCDOgetBlock(PCDoviewHdl hpcd, PCDRAWDATA buffer, long stride)
{
	register int line;						/* current line */
	unsigned char FAR *databuf = 0;			/* raw data buffer */
	PCDRAWDATA ybuf, c1buf, c2buf;			/* pointers to raw line data */
	PCDRAWDATA buf1, buf2, buf3;			/* output buffer plane pointers */
	long linelen;
	int  totlines;
	int imglinelen, imgtotlines;
	PCDoviewPtr	pcdo = 0;
	PCDrawYCCPtr pcdr = 0;
	RECT r;
	long startoff;							/* computed for input remap */
	long effcolbytes, effstride;		  	/* computed for input remap */
	PCDstatus rv = pcdSuccess;

	paramck(buffer);
	paramck(stride > 0);
	GetOviewPtr(hpcd, pcdo);

	paramck(pcdo->step == PCD_BASE_OVER_64 || pcdo->step ==PCD_BASE_OVER_16);

	if ((rv = PCDopenFile(&pcdo->iostate)) != pcdSuccess) {
		RELEASEHANDLE(hpcd);
		return(rv);
	}

	if (!checkVolume(&pcdo->iostate)) {
		RELEASEHANDLE(hpcd);
		return(pcdWrongVolume);
	}
	imglinelen = rowsiz(PCD_BASE_OVER_16);
	imgtotlines = colsiz(PCD_BASE_OVER_16);

	linelen = (long) rowsiz(pcdo->step);
	totlines = colsiz(pcdo->step);

	PCDOgetSize(hpcd, &r);

	/*
	 * Calculate input transform parameters.
	 */
	calcInputXform(pcdo->xform, pcdo->format, pcdo->step,
					pcdo->columnBytes, &r, stride, 
					&startoff, &effcolbytes, &effstride);
	buf1 = buffer + startoff;
	if (pcdo->format != PCD_SINGLE) {
		buf2 = buf1 + pcdo->planeBytes;
		buf3 = buf2 + pcdo->planeBytes;
	}

	if ((pcdr = openRawYCC(&pcdo->iostate, pcdo->step, pcdo->format, 
	pcdo->version, FALSE)) == 0) {
		rv = ENOMEM;
		goto out;
	}
	setOviewImgNo(pcdr, pcdo->imgno);

	for (line = 0; line < totlines; line++) {
		if ((ybuf = getRawLine(pcdr, line, Y)) == 0) {
			rv = EIO;
			goto out;
		}
		if (pcdo->format != PCD_SINGLE) {
			if ((c1buf = getRawLine(pcdr, line, C1)) == 0 ||
			    (c2buf = getRawLine(pcdr, line, C2)) == 0) {
				rv = EIO;
				goto out;
			}
		}

		switch (pcdo->format) {
		case PCD_SINGLE:
			memcpyg(buf1, ybuf, linelen, effcolbytes);
			buf1 += effstride;
			break;
		case PCD_RGB:
			if (pcdo->step == PCD_BASE_OVER_16)
				PCDxiYCCtoRGB(ybuf, c1buf, c2buf, 1,
					buf1, pcdo->planeBytes, effcolbytes, linelen, TRUE);
			else
				PCDiYCCtoRGB(ybuf, c1buf, c2buf, 1,
					buf1, pcdo->planeBytes, effcolbytes, linelen);
			buf1 += effstride;
			break;
		case PCD_YCC:
			if (pcdo->step == PCD_BASE_OVER_16) {
				PCDxiYCCtoYCC(ybuf, c1buf, c2buf, 1,
					buf1, pcdo->planeBytes, effcolbytes, linelen, TRUE);
			} else {
				memcpyg(buf1, ybuf, linelen, effcolbytes);
				memcpyg(buf2, c1buf, linelen, effcolbytes);
				memcpyg(buf3, c2buf, linelen, effcolbytes);
				buf2 += effstride;
				buf3 += effstride;
			}
			buf1 += effstride;
			break;

		case PCD_PALETTE: 
			if (pcdo->step == PCD_BASE_OVER_16)
				PCDxiYCCtoPalette(ybuf, c1buf, c2buf, 1,
				  effcolbytes, buf1, linelen, 
				  pcdo->palette, TRUE);
			else
				PCDiYCCtoPalette(ybuf, c1buf, c2buf, 1,
				  effcolbytes, buf1, linelen, 
				  pcdo->palette);
			buf1 += effstride;
			break;

		default:
			rv = pcdBadParam;
			goto out;
		}
	}
	(void)PCDcloseFile(&pcdo->iostate);
out:
	if (pcdr)
		closeRawYCC(pcdr);
	if (hpcd)
		RELEASEHANDLE(hpcd);
	return(rv);
} /* end PCDOgetBlock */



#ifdef  ENABLE_CATALOG_CALLS
/* 
 * takes quad (numbered 1 - 4, left to right, top to bottom) and returns rect
 * taking current orientation and resolution into account.
 */
static char quadmap[8][4] = {{1,2,3,4}, {3,4,1,2}, {2,1,4,3}, {4,3,2,1},                                                         {3,1,4,2}, {1,3,2,4}, {4,2,3,1}, {2,4,1,3}};
PCDstatus FAR PASCAL
PCDOgetQuadRect(PCDoviewHdl pcdo, int quadrant, LPRECT theRectPtr)
{
	int myquad;
	PCDtransform theTransform;

	PCDOgetTransform(pcdo, &theTransform);
	PCDOgetSize(pcdo, theRectPtr);
	if (quadrant == 0) 
		return(pcdSuccess);
	if ((theTransform > 7) || (theTransform < 0))           
		return(pcdBadParam);
	myquad = quadmap[theTransform][quadrant-1];
	if (myquad == 1) { 
		theRectPtr->right >>= 1;  
 		theRectPtr->bottom >>= 1;
	}
	else if (myquad == 2)   { 
		theRectPtr->left = (theRectPtr->right >> 1);               
		theRectPtr->bottom >>= 1;
	}
	else if (myquad == 3)   {  
		theRectPtr->right >>= 1; 
		theRectPtr->top = (theRectPtr->bottom >> 1);
	}
	else if (myquad == 4){
		theRectPtr->left = (theRectPtr->right >> 1);   
		theRectPtr->top = (theRectPtr->bottom >> 1);
	}
	return(pcdSuccess);
} /* end PCDOgetQuadRect */

/* rect version of PCDOgetBlock to support reading catalog images */
PCDstatus FAR PASCAL
PCDOgetBlockR   (PCDoviewHdl hpcd, 
				LPRECT lprect,
				PCDRAWDATA buffer, 
				long stride)
{
	register int line;/* current line */
	unsigned char FAR *databuf = 0;         /* raw data buffer */
	PCDRAWDATA ybuf, c1buf, c2buf;          /* pointers to raw line data */
	PCDRAWDATA buf1, buf2, buf3;            /* output buffer plane pointers */
	long linelen;
	int totlines;
	int imglinelen, imgtotlines;
	PCDoviewPtr     pcdo = 0;
	PCDrawYCCPtr pcdr = 0;
	RECT r;
	long startoff;                          /* computed for input remap */
	long effcolbytes, effstride;             /* computed for input remap */
	PCDstatus rv = pcdSuccess;
	int yoff, coff;
	BOOL replicateLast;

	paramck(buffer);
	paramck(stride > 0);
	GetOviewPtr(hpcd, pcdo);

	paramck(/* pcdo->step == PCD_BASE_OVER_64 ||*/ pcdo->step ==PCD_BASE_OVER_16);

	if ((rv = PCDopenFile(&pcdo->iostate)) != pcdSuccess) {
		RELEASEHANDLE(hpcd);
		return(rv);
	}

	if (!checkVolume(&pcdo->iostate)) {
		RELEASEHANDLE(hpcd);
		return(pcdWrongVolume);
	}
	imglinelen = rowsiz(PCD_BASE_OVER_16); /* we always read base/16 image */
	imgtotlines = colsiz(PCD_BASE_OVER_16);


	if (lprect == NULL)
		PCDOgetSize(hpcd, &r); /* use full image */
	  else
		r = *lprect;


	/*
	 * Calculate input transform parameters.
	 */
	calcInputXform(pcdo->xform, pcdo->format, pcdo->step,
					pcdo->columnBytes, &r, stride, 
					&startoff, &effcolbytes, &effstride);

/*	linelen = rowsiz(pcdo->step); */
	linelen = (long) (r.right - r.left);
/*	totlines = colsiz(pcdo->step); */
	totlines = r.bottom - r.top;

	buf1 = buffer + startoff;
	if (pcdo->format != PCD_SINGLE) {
		buf2 = buf1 + pcdo->planeBytes;
		buf3 = buf2 + pcdo->planeBytes;
	}

	if ((pcdr = openRawYCC(&pcdo->iostate, pcdo->step, pcdo->format, 
							pcdo->version, FALSE)) == 0) {
		rv = ENOMEM;
		goto out;
	}
	setOviewImgNo(pcdr, pcdo->imgno);

/*	for (line = 0; line < totlines; line++) { */
	for (line = r.top; line < r.bottom; line++) { 
		if ((ybuf = getRawLine(pcdr, line, Y)) == 0) {
			rv = EIO;
			goto out;
		}
	yoff = r.left;
	coff = r.left/2;
	replicateLast = (linelen + yoff == rowsiz(pcdo->step));

	ybuf += yoff;
	if (pcdo->format != PCD_SINGLE) {
		if ((c1buf = getRawLine(pcdr, line, C1)) == 0 ||
		    (c2buf = getRawLine(pcdr, line, C2)) == 0) {
			rv = EIO;
			goto out;
		}
		c1buf += coff;	/* adjust for rect; */
		c2buf += coff;
	}
	
		switch (pcdo->format) {
		case PCD_SINGLE:
			memcpyg(buf1, ybuf, linelen, effcolbytes);
			buf1 += effstride;
			break;
		case PCD_RGB:
			if (pcdo->step == PCD_BASE_OVER_16)
				PCDxiYCCtoRGB(ybuf, c1buf, c2buf, 1, buf1, pcdo->planeBytes,
 					effcolbytes, linelen, replicateLast);
			else
				PCDiYCCtoRGB(ybuf, c1buf, c2buf, 1,
					buf1, pcdo->planeBytes, effcolbytes, linelen);
			buf1 += effstride;
			break;
		case PCD_YCC:
			if (pcdo->step == PCD_BASE_OVER_16) {
				PCDxiYCCtoYCC(ybuf, c1buf, c2buf, 1, buf1, pcdo->planeBytes,
 					effcolbytes, linelen, replicateLast);
			} else {
				memcpyg(buf1, ybuf, linelen, effcolbytes);
				memcpyg(buf2, c1buf, linelen, effcolbytes);
				memcpyg(buf3, c2buf, linelen, effcolbytes);
				buf2 += effstride;
				buf3 += effstride;
			}
			buf1 += effstride;
			break;

		case PCD_PALETTE: 
			if (pcdo->step == PCD_BASE_OVER_16)
				PCDxiYCCtoPalette(ybuf, c1buf, c2buf, 1,
				  effcolbytes, buf1, linelen, pcdo->palette, replicateLast);
			else
				PCDiYCCtoPalette(ybuf, c1buf, c2buf, 1,
				  effcolbytes, buf1, linelen, pcdo->palette);
			buf1 += effstride;
			break;

		default:
			rv = pcdBadParam;
			goto out;
		}
	}
	(void)PCDcloseFile(&pcdo->iostate);
out:
	if (pcdr)
		closeRawYCC(pcdr);
	if (hpcd)
		RELEASEHANDLE(hpcd);
	return(rv);
} /* end PCDOgetBlockR [catalog image version] */
#endif /* ENABLE_CATALOG_CALLS */ 



/* Copy the Y channel of a BASE/64 image. Only used below. */
void NEAR PASCAL
copysmallY(const _segment seg,
		unsigned char _based(void) *in,
		unsigned char _based(void) *out,
		long rCol,
		int count)
{
	while (count--) {
		*(seg:>out) = *(seg:>in);
		in += 2;
		out += rCol;
	}
}

void FAR PASCAL 
cvtytor3(const _segment seg,
		unsigned char _based(void) *y,
		unsigned char _based(void) *c1,
		unsigned char _based(void) *c2,
		unsigned char _based(void) *r,
		unsigned char _based(void) *g,
		unsigned char _based(void) *b,
		int rCol,
		int count);

#define	RAWCHKSIZE(step)	(3L * (long)rowsiz(step))
#define	RAWSIZE(step)		((RAWCHKSIZE(step) * (long)colsiz(step)) / 2L)
#define	IMGSIZE(fmt, step) \
	((fmt == PCD_RGB || fmt == PCD_RGB) ? \
		(3L * (long)rowsiz(step) * (long)colsiz(step)) : \
		((long)rowsiz(step) * (long)colsiz(step)))

#include <dos.h>

PCDstatus NEAR PASCAL
PCDOgetBlockQuickly(PCDoviewHdl hpcd, unsigned char FAR *buffer, long stride)
{
	int line;						/* current line */
	PCDoviewPtr	pcdo = 0;
	RECT rect;
	long startoff;					/* computed for input remap */
	long effcolbytes, effstride;		/* computed for input remap */
	PCDstatus rv = pcdSuccess;
	const _segment seg = _FP_SEG(buffer);
	unsigned char _based(void) *y = (unsigned char _based(void) *) _FP_OFF(buffer); 
	unsigned char _based(void) *c1; 
	unsigned char _based(void) *c2;
	unsigned char _based(void) *r;
	unsigned char _based(void) *g;
	unsigned char _based(void) *b;
	PCDformat format;

	assert(buffer);
	assert(stride > 0);

	GetOviewPtr(hpcd, pcdo);

	assert(pcdo->step == PCD_BASE_OVER_64);

	if ((rv = PCDopenFile(&pcdo->iostate)) != pcdSuccess) {
		RELEASEHANDLE(hpcd);
		return(rv);
	}

	if (!checkVolume(&pcdo->iostate)) {
		RELEASEHANDLE(hpcd);
		return(pcdWrongVolume);
	}
	PCDOgetSize(hpcd, &rect);
	format = pcdo->format;

	/*
	 * Calculate input transform parameters.
	 */
	calcInputXform(pcdo->xform, format, pcdo->step,
					pcdo->columnBytes, &rect, stride, 
					&startoff, &effcolbytes, &effstride);

	PCDsetMark(&pcdo->iostate, (long)PCDOS_IMG(pcdo->imgno), 0);
	rv = PCDreadSome(&pcdo->iostate, buffer + IMGSIZE(format,PCD_BASE_OVER_64), 
						RAWSIZE(PCD_BASE_OVER_16));
	if (rv != pcdSuccess)
		goto out;

	buffer += startoff;

	y += IMGSIZE(format,PCD_BASE_OVER_64);
	c1 = y + (rowsiz(PCD_BASE_OVER_16) * 2);
	c2 = c1 + (rowsiz(PCD_BASE_OVER_16) / 2);

	b = (unsigned char _based(void) *) _FP_OFF(buffer);
	g = b + pcdo->planeBytes;
	r = g + pcdo->planeBytes;

	for (line = 0; line < colsiz(PCD_BASE_OVER_64); line++) {
		switch (format) {
		case PCD_RGB:
			PCDziYCCtoRGB(seg, y, c1, c2, r, g, b,
					effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		case PCD_SINGLE:
			copysmallY(seg, y, b, effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		case PCD_PALETTE:
			PCDziYCCto332(seg, y, c1, c2, b,
					effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		default:
			assert(9090 == 33);
		}
		r += effstride;
		g += effstride;
		b += effstride;

		y  += RAWCHKSIZE(PCD_BASE_OVER_16);
		c1 += RAWCHKSIZE(PCD_BASE_OVER_16);
		c2 += RAWCHKSIZE(PCD_BASE_OVER_16);
	}
out:
	if (hpcd && pcdo)
		RELEASEHANDLE(hpcd);
	return(rv);
} /* end PCDOgetBlockQuickly */


#ifdef  ENABLE_CATALOG_CALLS
PCDstatus NEAR PASCAL
PCDOgetBlockQuicklyR (  PCDoviewHdl hpcd, 
						LPRECT lprect,
						unsigned char FAR *buffer, 
						long stride)
{
	int line;            /* current line */
	PCDoviewPtr     pcdo = 0;
	RECT rect;
	long startoff;      /* computed for input remap */
	long imgsize;
	long effcolbytes, effstride;             /* computed for input remap */
	PCDstatus rv = pcdSuccess;
	const _segment seg = _FP_SEG(buffer);
	unsigned char _based(void) *y = (unsigned char _based(void) *) _FP_OFF(buffer); 
	unsigned char _based(void) *c1; 
	unsigned char _based(void) *c2;
	unsigned char _based(void) *r;
	unsigned char _based(void) *g;
	unsigned char _based(void) *b;
	PCDformat format;

	assert(buffer);
	assert(stride > 0);

	GetOviewPtr(hpcd, pcdo);

	assert(pcdo->step == PCD_BASE_OVER_64);

	if ((rv = PCDopenFile(&pcdo->iostate)) != pcdSuccess) {
		RELEASEHANDLE(hpcd);
		return(rv);
	}

	if (!checkVolume(&pcdo->iostate)) {
		RELEASEHANDLE(hpcd);
		return(pcdWrongVolume);
	}
	if (lprect == NULL)
		PCDOgetSize(hpcd, &rect);
	  else
		rect = *lprect;
	format = pcdo->format;

	/*
	 * Calculate input transform parameters.
	 */
	calcInputXform(pcdo->xform, format, pcdo->step,
					pcdo->columnBytes, &rect, stride, 
					&startoff, &effcolbytes, &effstride);

	imgsize = (rect.right - rect.left) * (rect.bottom - rect.top);
	if (pcdo->format == PCD_RGB || pcdo->format == PCD_YCC)
		imgsize *= 3L;

	PCDsetMark(&pcdo->iostate, (long)PCDOS_IMG(pcdo->imgno), 0);
	rv = PCDreadSome(&pcdo->iostate, buffer + imgsize,
		 /*IMGSIZE(format,PCD_BASE_OVER_64), pre-rect code */ 
						RAWSIZE(PCD_BASE_OVER_16));
	if (rv != pcdSuccess)
		goto out;

	buffer += startoff;

	y += imgsize; /* IMGSIZE(format,PCD_BASE_OVER_64); pre-rect code */
	c1 = y + (rowsiz(PCD_BASE_OVER_16) * 2);
	c2 = c1 + (rowsiz(PCD_BASE_OVER_16) / 2);

	b = (unsigned char _based(void) *) _FP_OFF(buffer);
	g = b + pcdo->planeBytes;
	r = g + pcdo->planeBytes;

/*	for (line = 0; line < colsiz(PCD_BASE_OVER_64); line++) {*/
	for (line = rect.top; line < rect.bottom; line++) {
		switch (format) {
		case PCD_RGB:
			PCDziYCCtoRGB(seg, y, c1, c2, r, g, b,
					effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		case PCD_SINGLE:
			copysmallY(seg, y, b, effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		case PCD_PALETTE:
			PCDziYCCto332(seg, y, c1, c2, b,
					effcolbytes, rowsiz(PCD_BASE_OVER_64));
			break;
		default:
			assert(9090 == 33);
		}
		r += effstride;
		g += effstride;
		b += effstride;

		y  += RAWCHKSIZE(PCD_BASE_OVER_16);
		c1 += RAWCHKSIZE(PCD_BASE_OVER_16);
		c2 += RAWCHKSIZE(PCD_BASE_OVER_16);
	}
out:
	if (hpcd && pcdo)
		RELEASEHANDLE(hpcd);
	return(rv);
} /* end PCDOgetBlockQuicklyR [quad version] */
#endif /* ENABLE_CATALOG_CALLS */



BOOL NEAR
quick332(HANDLE hPal)
{
	PCDpalettePtr	pp;

	if (!hPal)
		return(FALSE);
	if (!HANDLETOPOINTER(hPal, pp, PCDpalettePtr))
		return(FALSE);
	return(pp->quick332 && !pp->errdiff);
}

void bmiCalc(PCDformat, LPBITMAPINFO, WORD, WORD, short, PCDpaletteHdl); /*XXX*/

PCDstatus FAR PASCAL
PCDOloadImage(PCDoviewHdl hPcd, PCDbitmapHdl FAR *lphPCDbitmap)
{
	PCDoviewPtr	pcd;
	PCDstatus rv = pcdSuccess;
	HANDLE			hbytes;		/* Handle to image data */
	char _huge		*ibuf;		/* Image buffer space */
	unsigned int	width, height, 
					hdrsize;	/* Size of platform-dependent image header */
	long			stride;
	long			imgsize;	/* Size of entire image, including header */
	RECT			r;
	PCDformat		format;
	unsigned short	iobufsize = 0;
	BOOL			doQuickly = FALSE;

	paramck(lphPCDbitmap);
	*lphPCDbitmap = 0;
	GetOviewPtr(hPcd, pcd);

	format = pcd->format;
	PCDlistResolution(pcd->step, &width, &height);

	/*
	 * Swap width and height if user wants rotated data.
	 */
	if (pcd->xform & PCD_90_ROTATION) {
		unsigned int	tmp = width;

		width = height;
		height = tmp;
	}

	SetRectSize(((LPRECT)&r), 0, 0, width, height);

	hdrsize = sizeof(BITMAPINFOHEADER);
	if (format == PCD_SINGLE || format == PCD_PALETTE) {
		pcd->planeBytes = 1;
		pcd->columnBytes = 1;
		imgsize = (unsigned long)RectWidth(&r) * (unsigned long)RectHeight(&r);
		hdrsize += 256 * sizeof(RGBQUAD);
	} else {
		imgsize = 3L * (unsigned long)RectWidth(&r) * 
					(unsigned long)RectHeight(&r);
		if (format == PCD_RGB)
			hdrsize += 256 * sizeof(RGBQUAD);
	}
	PCDOgetBytesPerRow(hPcd, (short)RectWidth(&r), &stride);

/* XXX - Better test */
	if ((format == PCD_RGB || format == PCD_SINGLE || 
				(format == PCD_PALETTE && quick332(pcd->palette))) && 
				pcd->step == PCD_BASE_OVER_64 && pcd->columnBytes < 4) {
			doQuickly = TRUE;
			iobufsize = RAWSIZE(PCD_BASE_OVER_16);
	}

	if ((hbytes = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
				  imgsize + hdrsize + iobufsize + PCDBMEXTRABYTES)) == 0) {
			*lphPCDbitmap = 0;
			return(ENOMEM);
	}
	if ((ibuf = (char _huge *)GlobalLock(hbytes)) == 0) {
		GlobalFree(hbytes);
		*lphPCDbitmap = 0;
		return(ENOMEM);
	}

	if (doQuickly) {
		HANDLE hNew;

		rv = PCDOgetBlockQuickly(hPcd, ibuf + hdrsize, stride);
/* Shrink to correct size */
		if (hNew = GlobalReAlloc(hbytes,imgsize + hdrsize + PCDBMEXTRABYTES,0))
			hbytes = hNew;
	} else
		rv = PCDOgetBlock(hPcd, ibuf + hdrsize, stride);

	if (rv == pcdSuccess) {
		/*XXX*/
		bmiCalc(format, (LPBITMAPINFO)ibuf, RectWidth(&r), RectHeight(&r),
				pcd->columnBytes, pcd->palette);
		/* Store plane and column bytes in extra space after image data */
		setPlaneCol(hbytes, pcd->planeBytes, pcd->columnBytes);
		GlobalUnlock(hPcd);
		GlobalUnlock(hbytes);
		*lphPCDbitmap = hbytes;
		return(pcdSuccess);
	}

	GlobalUnlock(hPcd);
	GlobalUnlock(hbytes);
	GlobalFree(hbytes);
	return(rv);
} /* end PCDOloadImage */


#ifdef  ENABLE_CATALOG_CALLS

PCDstatus FAR PASCAL
PCDOloadImageR (PCDoviewHdl hPcd, 
				LPRECT lpRect, 
				PCDbitmapHdl FAR *lphPCDbitmap)
{
	PCDoviewPtr     pcd;
	PCDstatus rv = pcdSuccess;
	HANDLE                  hbytes;         /* Handle to image data */
	char _huge              *ibuf;          /* Image buffer space */
	unsigned int hdrsize;        /* Size of platform-dependent image header */
	long		stride;
	long    	imgsize;        /* Size of entire image, including header */
	RECT    	r;
	PCDformat   format;
	unsigned short  iobufsize = 0;
	BOOL        doQuickly = FALSE;

	paramck(lphPCDbitmap);
	*lphPCDbitmap = 0;
	GetOviewPtr(hPcd, pcd);

	format = pcd->format;

	if (lpRect)
		r = *lpRect;
	else 
		PCDOgetSize(hPcd, &r);

	hdrsize = sizeof(BITMAPINFOHEADER);
	if (format == PCD_SINGLE || format == PCD_PALETTE) {
		pcd->planeBytes = 1;
		pcd->columnBytes = 1;
		imgsize = 
			(unsigned long)RectWidth(&r) * (unsigned long)RectHeight(&r);
		hdrsize += 256 * sizeof(RGBQUAD);
	} else {
		imgsize = 3L * (unsigned long)RectWidth(&r) * 
					(unsigned long)RectHeight(&r);
		if (format == PCD_RGB)
			hdrsize += 256 * sizeof(RGBQUAD);
	}
	PCDOgetBytesPerRow(hPcd, (short)RectWidth(&r), &stride);

/* XXX - Better test */
	if ((format == PCD_RGB || format == PCD_SINGLE || 
				(format == PCD_PALETTE && quick332(pcd->palette))) && 
				pcd->step == PCD_BASE_OVER_64 && pcd->columnBytes < 4) {
			doQuickly = TRUE;
			iobufsize = RAWSIZE(PCD_BASE_OVER_16);
	}

	if ((hbytes = GlobalAlloc(GMEM_MOVEABLE|GMEM_ZEROINIT, 
				  imgsize + hdrsize + iobufsize + PCDBMEXTRABYTES)) == 0) {
			*lphPCDbitmap = 0;
			return(ENOMEM);
	}
	if ((ibuf = (char _huge *)GlobalLock(hbytes)) == 0) {
		GlobalFree(hbytes);
		*lphPCDbitmap = 0;
		return(ENOMEM);
	}

	if (doQuickly) {
		HANDLE hNew;

		rv = PCDOgetBlockQuicklyR(hPcd, &r, ibuf + hdrsize, stride);
/* Shrink to correct size */
		if (hNew = GlobalReAlloc(hbytes,imgsize + hdrsize + PCDBMEXTRABYTES,0))
			hbytes = hNew;
	} else
		rv = PCDOgetBlockR(hPcd, &r, ibuf + hdrsize, stride);

	if (rv == pcdSuccess) {
		/*XXX*/
		bmiCalc(format, (LPBITMAPINFO)ibuf, RectWidth(&r), RectHeight(&r),
				pcd->columnBytes, pcd->palette);
		/* Store plane and column bytes in extra space after image data */
		setPlaneCol(hbytes, pcd->planeBytes, pcd->columnBytes);
		GlobalUnlock(hPcd);
		GlobalUnlock(hbytes);
		*lphPCDbitmap = hbytes;
		return(pcdSuccess);
	}

	GlobalUnlock(hPcd);
	GlobalUnlock(hbytes);
	GlobalFree(hbytes);
	return(rv);
} /* end PCDOloadImageR */
#endif /* ENABLE_CATALOG_CALLS */

