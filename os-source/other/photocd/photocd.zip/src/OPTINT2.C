/*
 *	Photo CD Development Toolkit
 *
 *	optint.c
 *	optimized interpolation primitives
 * 		included by interp.c twice
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)optint2.c	1.48 - 92/06/03"
#endif

#include <windows.h>
#include <assert.h>
#include "pcdlib.h"
#include "pcdpriv.h"

#include <dos.h>

unsigned char FAR *ndst;

#define	WRAPCHECK() 
/*
	ndst = dst + colBytes; \
	assert(_FP_SEG(ndst) == _FP_SEG(dst)); \
	assert(_FP_OFF(ndst) > _FP_OFF(dst)); 
*/

void FAR *datasegptr = (void FAR *)&datasegptr;

#define	SIXTYFOUR_K	(0x10000L)

void flinear2(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char FAR *dstptr, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short nextSrc, nextNext;
	register unsigned short iv1, iv2;
	unsigned short dstoff = _FP_OFF(dstptr);
//	const register _segment dstseg = _FP_SEG(dstptr);
	unsigned char _based(void) *dst = 0;
	unsigned char NEAR *nbase = 0;
	unsigned short baseseg = _FP_SEG(base);
	unsigned short dataseg = _FP_SEG(datasegptr);
	unsigned char dv;
	unsigned short dstseg = _FP_SEG(dstptr);

	dst += dstoff;
	nbase += _FP_OFF(base);

	assert(syndrome >= 0 || syndrome <= (2 - 1));
	assert(base);
	assert(count >= 0);

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = 2 - syndrome;
	nextMult = syndrome;

	_asm mov ds, baseseg
	_asm mov es, dstseg

	switch (srcMult) {
	case 1:
		while (count) {
			iv1 = nbase[src] + nbase[next];
			iv2 = iv1 + nbase[nextSrc] + nbase[nextNext];

			if (iv1 & 1) iv1++;
			dv = (unsigned char)(iv1 >> 1);
//			*(dstseg:>dst) = dv;
			_asm mov bx, dst
			_asm mov BYTE PTR es:[bx], al
			dst += colBytes;

			if (iv2 & 2) iv2 += 2;
			dv = (unsigned char)(iv2 >> 2);
//			*(dstseg:>dst) = dv;
			_asm mov bx, dst
			_asm mov BYTE PTR es:[bx], al
			dst += colBytes;

			nbase++;
			count -= 2;
		}
		break;
	case 2:
		while (count) {
			iv1 = nbase[src] + nbase[nextSrc];
			dv = (unsigned char)nbase[src];
//			*(dstseg:>dst) = dv;
			_asm mov bx, dst
			_asm mov BYTE PTR es:[bx], cl
			dst += colBytes;
			if (iv1 & 1) iv1++;
			dv = (unsigned char)(iv1 >> 1);
//			*(dstseg:>dst) = dv;
			_asm mov bx, dst
			_asm mov BYTE PTR es:[bx], al
			dst += colBytes;
			nbase++;
			count -= 2;
		}
		break;
	}
	_asm mov ds, dataseg
	return;
}


void flinear4(short syndrome, unsigned char FAR *base, 
			unsigned short isrc,  unsigned short inext, 
			unsigned char FAR *dst, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short factor = 4;
	unsigned char NEAR *src = 0, NEAR *next = 0, 
			NEAR *nextSrc, NEAR *nextNext;
	unsigned short baseseg = _FP_SEG(base);
	unsigned short baseoff = _FP_OFF(base);
	unsigned short dataseg = _FP_SEG(datasegptr);
	unsigned short dstseg = _FP_SEG(dst);
	unsigned short dstoff = _FP_OFF(dst);
	unsigned char dv;
	register unsigned short iv1, iv2, iv3, iv4;

	isrc += baseoff;
	inext += baseoff;

	src += isrc;
	next += inext;

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = factor - syndrome;
	nextMult = syndrome;

	_asm mov ds, baseseg
	_asm mov es, dstseg

	switch (srcMult) {
	case 4:
		while (count) {
			iv1 = *src;
			iv3 = iv1 + *nextSrc;
			iv4 = iv3 + (*nextSrc << 1);
			iv2 = iv3 + (iv1 << 1);

			if (iv2 & 2) iv2 += 2;
			if (iv3 & 1) iv3++;
			if (iv4 & 2) iv4 += 2;

			dv = (unsigned char)(iv1);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv2 >> 2);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv3 >> 1);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv4 >> 2);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al
			dstoff += (unsigned short) colBytes;

			src++;
			nextSrc++;
			next++;
			nextNext++;

			count -= 4;
		}
		break;
	case 3:
		while (count) {
/*
			iv1 = (3 * *src) + *next;
			iv2 = ((9 * *src)
			 	  + (3 * *nextSrc)
			 	  + (3 * *next)
			 	  + (*nextNext));
			iv3 = ((3 * *src)
			 	  + (3 * *nextSrc)
			 	  + (*next)
			 	  + (*nextNext));
			iv4 = ((3 * *src)
			 	  + (9 * *nextSrc)
			 	  + (*next)
			 	  + (3 * *nextNext));
*/
			iv1 = (3 * *src) + *next;
			iv2 = (3 * *nextSrc) + *nextNext;
			iv3 = iv1 + iv2;
			iv4 = iv3 + (iv2 << 1);
			iv2 = iv3 + (iv1 << 1);

			if (iv1 & 2) iv1 += 2;
			if (iv2 & 8) iv2 += 8;
			if (iv3 & 4) iv3 += 4;
			if (iv4 & 8) iv4 += 8;

			dv = (unsigned char)(iv1 >> 2);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv2 >> 4);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv3 >> 3);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv4 >> 4);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			src++;
			nextSrc++;
			next++;
			nextNext++;

			count -= 4;
		}
		break;
	case 2:
		while (count) {
/*
			iv1 = *src + *next;
			iv2 = ((3 * *src)
			 	  + (*nextSrc)
			 	  + (3 * *next)
			 	  + (*nextNext));
			iv3 = ((*src)
			 	  + (*nextSrc)
			 	  + (*next)
			 	  + (*nextNext));
			iv4 = ((*src)
			 	  + (3 * *nextSrc)
			 	  + (*next)
			 	  + (3 * *nextNext));
*/
			iv1 = *src + *next;
			iv2 = *nextSrc + *nextNext;
			iv3 = iv1 + iv2;
			iv4 = iv3 + (iv2 << 1);
			iv2 = iv3 + (iv1 << 1);

			if (iv1 & 1) iv1++;
			if (iv2 & 4) iv2 += 4;
			if (iv3 & 2) iv3 += 2;
			if (iv4 & 4) iv4 += 4;

			dv = (unsigned char)(iv1 >> 1);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv2 >> 3);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv3 >> 2);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv4 >> 3);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			src++;
			nextSrc++;
			next++;
			nextNext++;

			count -= 4;
		}
		break;
	case 1:
		while (count) {
/*
			iv1 = ((*src) + (3 * *next));
			iv2 = ((3 * *src)
			 	  + (*nextSrc)
			 	  + (9 * *next)
			 	  + (3 * *nextNext));
			iv3 = ((*src)
			 	  + (*nextSrc)
			 	  + (3 * *next)
			 	  + (3 * *nextNext));
			iv4 = ((*src)
			 	  + (3 * *nextSrc)
			 	  + (3 * *next)
			 	  + (9 * *nextNext));
*/
			iv1 = (*src + (3 * *next));
			iv2 = (*nextSrc + (3 * *nextNext));
			iv3 = iv1 + iv2;
			iv4 = iv3 + (iv2 << 1);
			iv2 = iv3 + (iv1 << 1);

			if (iv1 & 2) iv1 += 2;
			if (iv2 & 8) iv2 += 8;
			if (iv3 & 4) iv3 += 4;
			if (iv4 & 8) iv4 += 8;

			dv = (unsigned char)(iv1 >> 2);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv2 >> 4);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv3 >> 3);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			dv = (unsigned char)(iv4 >> 4);
//			*dst = dv;

			_asm mov bx, dstoff
			_asm mov BYTE PTR es:[bx], al

			dstoff += (unsigned short) colBytes;
			src++;
			nextSrc++;
			next++;
			nextNext++;

			count -= 4;
		}
		break;
	}
	_asm mov ds, dataseg
	return;
}
 

void flinear8(short syndrome, unsigned char FAR *base, 
			unsigned short src,  unsigned short next, 
			unsigned char FAR *dst, 
			short count, long colBytes)
{
	short srcMult, nextMult;
	short factminus1, factsquared;
	short factor = 8;
	short nextSrc, nextNext;
	register unsigned short iv;

	factminus1 = factor - 1;
	factsquared = factor * factor;

	nextSrc = src + 1;
	nextNext = next + 1;

	srcMult = factor - syndrome;
	nextMult = syndrome;

	while (count) {
/* 0 */
		iv = (srcMult  * 8  * base[src])
		 	  + (srcMult  * 0 * base[nextSrc])
		 	  + (nextMult * 8  * base[next])
		 	  + (nextMult * 0 * base[nextNext]);
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 1 */
		iv = ((srcMult  * 7  * base[src])
		 	  + (srcMult  * 1 * base[nextSrc])
		 	  + (nextMult * 7  * base[next])
		 	  + (nextMult * 1 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 2 */
		iv = ((srcMult  * 6  * base[src])
		 	  + (srcMult  * 2 * base[nextSrc])
		 	  + (nextMult * 6  * base[next])
		 	  + (nextMult * 2 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 3 */
		iv = ((srcMult  * 5  * base[src])
		 	  + (srcMult  * 3 * base[nextSrc])
		 	  + (nextMult * 5  * base[next])
		 	  + (nextMult * 3 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 4 */
		iv = ((srcMult  * 4  * base[src])
		 	  + (srcMult  * 4 * base[nextSrc])
		 	  + (nextMult * 4  * base[next])
		 	  + (nextMult * 4 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 5 */
		iv = ((srcMult  * 3  * base[src])
		 	  + (srcMult  * 5 * base[nextSrc])
		 	  + (nextMult * 3  * base[next])
		 	  + (nextMult * 5 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 6 */
		iv = ((srcMult  * 2  * base[src])
		 	  + (srcMult  * 6 * base[nextSrc])
		 	  + (nextMult * 2  * base[next])
		 	  + (nextMult * 6 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
/* 7 */
		iv = ((srcMult  * 1  * base[src])
		 	  + (srcMult  * 7 * base[nextSrc])
		 	  + (nextMult * 1  * base[next])
		 	  + (nextMult * 7 * base[nextNext]));
		if (iv & 32) iv += 32;
		*dst = (unsigned char)(iv >> 6);
		dst += colBytes;
		base++;
		count -= 8;
	}
}
