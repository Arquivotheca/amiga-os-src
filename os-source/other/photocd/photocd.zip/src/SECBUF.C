/*
 *	Photo CD Development Toolkit
 *
 *	secbuf.c
 *	Sector buffering used by Huffman decoder
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */
#ifdef	IDENT
#ident	"@(#)secbuf.c	1.89 - 92/06/03"
#endif

#include <windows.h>
#include <assert.h>
#include <errno.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "pcdovw.h"
#include "util.h"
#include "secbuf.h"

#define	PCD(X)	(pcd)->X

/*
 *	Internal interface - fill the sector buffer and return
 *	the first byte.  Currently used only by the Huffman
 *	decoding routines.
 */
unsigned char PCDfillbuf(PCDphotoPtr pcd)
{
	unsigned char rc;

	if (PCD(iostate).seekloc + (long)SECBUFSZ > PCD(iostate).filesize)
		PCD(seccnt) = (short) (PCD(iostate).filesize - PCD(iostate).seekloc);
	else
		PCD(seccnt) = (short)SECBUFSZ;
	PCDreadSome(&PCD(iostate), PCD(secbuf), PCD(seccnt));
	PCD(secptr) = PCD(secbuf);
	rc = *PCD(secptr);
	++(PCD(secptr));
	--(PCD(seccnt));
	return (rc);
}

/*
 *	Seek and flush the sector buffer.
 */
void PCDflushbuf(PCDphotoPtr pcd, long off)
{
	PCDsetMark(&PCD(iostate), off, 0);
	PCD(seccnt) = 0;
}

/*
 *	Allocate memory for the sector buffer.
 */
PCDstatus PCDnewsecbuf(PCDphotoPtr pcd)
{
	PCD(secbuf) = PCDmalloc(SECBUFSZ);
	if (PCD(secbuf) == (char FAR *) 0)
		return(errno ? errno : ENOMEM);
	return(pcdSuccess);
}

/*
 *	Release memory for the sector buffer.
 */
PCDstatus PCDrelsesecbuf(PCDphotoPtr pcd)
{

	assert(PCD(secbuf) != (char FAR *) 0);
	PCDfree(PCD(secbuf));
	return (pcdSuccess);
}

unsigned char
PCDgetabyte(PCDphotoPtr pcd)
{
	if (--(pcd)->seccnt < 0) 
		return(PCDfillbuf(pcd));
	return(*(pcd)->secptr++);
}

unsigned long
getalong(PCDphotoPtr pcd)
{
	unsigned long	rv;

/*
	if ((pcd)->seccnt < 4) {
*/
		rv = PCDgetabyte(pcd);
		rv = (rv << 8) | PCDgetabyte(pcd);
		rv = (rv << 8) | PCDgetabyte(pcd);
		rv = (rv << 8) | PCDgetabyte(pcd);
/*
	} else {
		rv = (pcd->secptr[0] << 24) | (pcd->secptr[1] << 16) |
			 (pcd->secptr[2] << 8) | (pcd->secptr[3]);
		pcd->secptr += 4;
		pcd->seccnt -= 4;
	}
*/
	return(rv);
}

