/*
 *	Photo CD Development Toolkit
 *
 *	pal.c
 *	Low-level palette routines.
 *
 *	Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *	All rights reserved.
 */

#ifdef	IDENT
#ident	"@(#)pal.c	1.120 - 92/06/03"
#endif
#include <windows.h>
#include <assert.h>
#include "pcdlib.h"
#include "pal.h"

#define	PALETTESIZE	256

/*
 * Numbers of each color in a 332 colormap.
 */
#define	NRED	8
#define	NGREEN	8
#define	NBLUE  	4

void
copyPalette(RGBQUAD FAR *to, PALETTEENTRY FAR *from, WORD nentries)
{
	while (nentries-- > 0) {
		to->rgbRed 		= from->peRed;
		to->rgbGreen 	= from->peGreen;
		to->rgbBlue 	= from->peBlue;
		to->rgbReserved	= 0;
		to++; 
		from++;
	}

	return;
}

void
copyToPalette(PALETTEENTRY FAR *to, RGBQUAD FAR *from, WORD nentries)
{
	while (nentries-- > 0) {
		to->peRed 	= from->rgbRed;
		to->peGreen	= from->rgbGreen;
		to->peBlue 	= from->rgbBlue;
		to->peFlags	= 0;
		to++; 
		from++;
	}

	return;
}

void
make332Palette(RGBQUAD FAR *pep)
{
	int rColorStep = (PALETTESIZE - 1) / (NRED    - 1);
	int gColorStep = (PALETTESIZE - 1) / (NGREEN  - 1);
	int bColorStep = (PALETTESIZE - 1) / (NBLUE   - 1);
	int r, g, b;

	for (r = 0; r < NRED; r++) /* 3 */
		for (g = 0; g < NGREEN; g++) /* 3 */
			for (b = 0; b < NBLUE; b++) /* 2 */
			{
				pep->rgbRed      = r * rColorStep;
				pep->rgbGreen    = g * gColorStep;
				pep->rgbBlue     = b * bColorStep;
				pep->rgbReserved = 0;
				pep++;
			}

	return;
}

#if 1

unsigned char	grayGammaLUT[256] = {
#if 0
	   0,  15,  22,  27,  31,  35,  39,  42,
	  45,  47,  50,  52,  55,  57,  59,  61,
	  63,  65,  67,  69,  71,  73,  74,  76,
	  78,  79,  81,  82,  84,  85,  87,  88,
	  90,  91,  93,  94,  95,  97,  98,  99,
	 100, 102, 103, 104, 105, 107, 108, 109,
	 110, 111, 112, 114, 115, 116, 117, 118,
	 119, 120, 121, 122, 123, 124, 125, 126,
	 127, 128, 129, 130, 131, 132, 133, 134,
	 135, 136, 137, 138, 139, 140, 141, 141,
	 142, 143, 144, 145, 146, 147, 148, 148,
	 149, 150, 151, 152, 153, 153, 154, 155,
	 156, 157, 158, 158, 159, 160, 161, 162,
	 162, 163, 164, 165, 165, 166, 167, 168,
	 168, 169, 170, 171, 171, 172, 173, 174,
	 174, 175, 176, 177, 177, 178, 179, 179,
	 180, 181, 182, 182, 183, 184, 184, 185,
	 186, 186, 187, 188, 188, 189, 190, 190,
	 191, 192, 192, 193, 194, 194, 195, 196,
	 196, 197, 198, 198, 199, 200, 200, 201,
	 201, 202, 203, 203, 204, 205, 205, 206,
	 206, 207, 208, 208, 209, 210, 210, 211,
	 211, 212, 213, 213, 214, 214, 215, 216,
	 216, 217, 217, 218, 218, 219, 220, 220,
	 221, 221, 222, 222, 223, 224, 224, 225,
	 225, 226, 226, 227, 228, 228, 229, 229,
	 230, 230, 231, 231, 232, 233, 233, 234,
	 234, 235, 235, 236, 236, 237, 237, 238,
	 238, 239, 240, 240, 241, 241, 242, 242,
	 243, 243, 244, 244, 245, 245, 246, 246,
	 247, 247, 248, 248, 249, 249, 250, 250,
	 251, 251, 252, 252, 253, 253, 254, 255
#else
	  0,   1,   3,   4,   6,   7,   8,  10,
	 11,  13,  14,  15,  17,  18,  20,  21,
	 22,  24,  25,  27,  28,  29,  31,  32,
	 34,  35,  37,  38,  39,  41,  42,  44,
	 45,  46,  48,  49,  51,  52,  53,  55,
	 56,  58,  59,  60,  62,  63,  65,  66,
	 67,  69,  70,  72,  73,  75,  76,  77,
	 79,  80,  82,  83,  84,  86,  87,  89,
	 90,  91,  93,  94,  96,  97,  98, 100,
	101, 103, 104, 105, 107, 108, 110, 111,
	113, 114, 115, 117, 118, 120, 121, 122,
	124, 125, 127, 128, 129, 131, 132, 134,
	135, 136, 138, 139, 141, 142, 144, 145,
	146, 148, 149, 151, 152, 153, 155, 156,
	158, 159, 160, 162, 163, 165, 166, 167,
	169, 170, 172, 173, 174, 176, 177, 179,
	180, 182, 183, 184, 186, 187, 189, 190,
	191, 193, 194, 196, 197, 198, 200, 201,
	203, 204, 205, 207, 208, 210, 211, 212,
	214, 215, 217, 218, 220, 221, 222, 224,
	225, 227, 228, 229, 231, 232, 234, 235,
	236, 238, 239, 241, 242, 243, 245, 246,
	248, 249, 250, 252, 253, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255,
	255, 255, 255, 255, 255, 255, 255, 255
#endif
};

void
makeGrayPalette(RGBQUAD FAR *pep, int ngrays)
{
	int	i;

	for (i = 0; i < ngrays; i++) {
		pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 
			grayGammaLUT[i * (256 / ngrays)];
		pep->rgbReserved = 0;
		pep++;
	}

	return;
}
#else

#define	WHITE_THRESHOLD	(ngrays / 8)

/* Hacked for more light */
void
makeGrayPalette(RGBQUAD FAR *pep, int ngrays)
{
	int	i;
	int fact = 255 / (ngrays - 1);

	for (i = 0; i < ngrays; i++) {
		if (i >= ngrays - WHITE_THRESHOLD)
			pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 255;
		else if (i == 0)
			pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 0;
		else
			pep->rgbRed = pep->rgbGreen = pep->rgbBlue = (i + WHITE_THRESHOLD)
															* fact;
		pep->rgbReserved = 0;
		pep++;
	}

	return;
}
#endif /* DARKANDFOREBODING */

void
make221Palette(RGBQUAD FAR *pep)
{
	int r, g, b;
	int rColorStep = (PALETTESIZE - 1) / (NRED/2    - 1);
	int gColorStep = (PALETTESIZE - 1) / (NGREEN/2  - 1);
	int bColorStep = (PALETTESIZE - 1) / (NBLUE/2   - 1);

	for (r = 0; r < NRED / 2; r++) 
		for (g = 0; g < NGREEN / 2; g++)
			for (b = 0; b < NBLUE / 2; b++) {
				pep->rgbRed      = r * rColorStep;
				pep->rgbGreen    = g * gColorStep;
				pep->rgbBlue     = b * bColorStep;
				pep->rgbReserved = 0;
				pep++;
			}

	return;
}

#define	NBIAS	127
#define	BIASSTEP  2

void
makeKBPalette(RGBQUAD FAR *pep)
{
	int	i;

	for (i = 0; i < NBIAS; i++) {
		pep->rgbRed = pep->rgbGreen = pep->rgbBlue = i * BIASSTEP;
		pep->rgbReserved = 0;
		pep++;
	}
	pep->rgbRed = pep->rgbGreen = pep->rgbBlue = 255;
	pep->rgbReserved = 0;
	pep++;

	make221Palette(pep);

	return;
}

void
makeRBPalette(RGBQUAD FAR *pep)
{
	int	i;

	for (i = 0; i < NBIAS; i++) {
		pep->rgbRed = i * BIASSTEP;
		pep->rgbGreen = pep->rgbBlue = 0;
		pep->rgbReserved = 0;
		pep++;
	}
	pep->rgbRed = 255;
	pep->rgbGreen = pep->rgbBlue = 0;
	pep->rgbReserved = 0;
	pep++;

	make221Palette(pep);

	return;
}

void
makeGBPalette(RGBQUAD FAR *pep)
{
	int	i;

	for (i = 0; i < NBIAS; i++) {
		pep->rgbGreen = i * BIASSTEP;
		pep->rgbRed = pep->rgbBlue = 0;
		pep->rgbReserved = 0;
		pep++;
	}
	pep->rgbGreen = 255;
	pep->rgbRed = pep->rgbBlue = 0;
	pep->rgbReserved = 0;
	pep++;

	make221Palette(pep);

	return;
}

void
makeBBPalette(RGBQUAD FAR *pep)
{
	int	i;

	for (i = 0; i < NBIAS; i++) {
		pep->rgbBlue = i * BIASSTEP;
		pep->rgbRed = pep->rgbGreen = 0;
		pep->rgbReserved = 0;
		pep++;
	}
	pep->rgbBlue = 255;
	pep->rgbRed = pep->rgbGreen = 0;
	pep->rgbReserved = 0;
	pep++;

	make221Palette(pep);

	return;
}
