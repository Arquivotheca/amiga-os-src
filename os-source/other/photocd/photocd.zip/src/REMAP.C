/*
 *  Photo CD Development Toolkit
 *
 *  remap.c
 *  Image remapping (rotate, mirror, etc.) functions.
 *
 *  Copyright (c) 1991, INTERACTIVE Systems Corporation.
 *  All rights reserved.
 */
#ifdef  IDENT
#ident  "@(#)remap.c    1.122 - 92/06/03"
#endif

#include <windows.h>
#include <assert.h>
#include <errno.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "rectcalc.h"
#include "image.h"
#include "set.h"
#include "pcdcbf.h"

/*
 * In-place rotation support function. Given the one dimensional coordinate
 * of a pixel and a description of a remapping operation, calculates
 * the new location of that pixel.
 */


long
nextloc(long loc, PCDtransform op, long nrows, long ncols)
{
    long    oldx, oldy, newx, newy;

    oldy = loc / ncols;
    oldx = loc % ncols;

    switch(op) {
    case PCD_ROTATE_0:
        return(loc);
    case PCD_ROTATE_90:
        newx = (nrows - 1) - oldy;
        newy = oldx;
        return(newy * nrows + newx);
    case PCD_ROTATE_180:
        newx = (ncols - 1) - oldx;
        newy = (nrows - 1) - oldy;
        return(newy * ncols + newx);
    case PCD_ROTATE_270:
        newy = (ncols - 1) - oldx;
        newx = oldy;
        return(newy * nrows + newx);
    case PCD_MIRROR_0:
        newx = (ncols - 1) - oldx;
        newy = oldy;
        return(newy * ncols + newx);
    case PCD_MIRROR_90:
        newx = oldy;
        newy = oldx;
        return(newy * nrows + newx);
    case PCD_MIRROR_180:
        newx = oldx;
        newy = (nrows - 1) - oldy;
        return(newy * ncols + newx);
    case PCD_MIRROR_270:
        newx = (nrows - 1) - oldy;
        newy = (ncols - 1) - oldx;
        return(newy * nrows + newx);
    default:
        /* "Cannot happen" */
        assert(validTransform(op));
        return(loc); 
    }
}

/*
 * Stopgap function - used during in-place remapping to determine
 * whether a cycle still needs to be moved.
 */

BOOL
alreadydone(long start, PCDtransform op, long nrows, long ncols)
{
    long    loc = start;

    while ((loc = nextloc(loc, op, nrows, ncols)) != start)
        if (loc < start)
            return(TRUE);
    return(FALSE);
}

/* Global data for use by callbacks */
progFuncPtr     progressFunc = 0;
abortFuncPtr    abtFunc = 0;
long            progressData = 0;
long            abtData = 0;
BOOL            aborted = FALSE;
unsigned short nKmoved = 0, nKtoMove = 0, nKmovedBefore = 0;
short           denom;

/* Call progress and abort callbacks every 1K pixels */
#define DO_CALLBACKS(NMOVED) \
            if (progressFunc) { \
                if ((NMOVED % 1024) == 0) { \
                    nKmoved = (unsigned short)(NMOVED / 1024) + nKmovedBefore; \
                    (*progressFunc)((short)nKmoved, (short)nKtoMove, progressData); \
                } \
            } \
            if (abtFunc) { \
                if ((NMOVED % 1024) == 0) { \
                    if ((*abtFunc)(abtData)) { \
                        aborted = TRUE; \
                        return; \
                    } \
                } \
            }


/* In-place remap for 8-bit bytes.
 */

long	lastloc;

void
in_remap8(PCDtransform op, unsigned char HUGE *image, long columnBytes, 
          long nrows, long ncols, long nToMove, long maxcycle, SET done)
{
    long            cycle, loc; 
    long            nMoved = 0;
    long            endloc = nrows * ncols;
    unsigned char   save, oldsave;

    assert(nrows > 0);
    assert(ncols > 0);
    assert(endloc > 0);

    cycle = 0;
    for (;;) {
        loc = cycle;
        oldsave = image[loc * columnBytes];

        do {
            lastloc = loc;
            loc = nextloc(loc, op, nrows, ncols);
            assert(loc >= 0 && loc < endloc);
            save = image[loc * columnBytes];
            image[loc * columnBytes] = oldsave;

            if (loc > cycle && loc < maxcycle)
                insert(done, loc);
            oldsave = save;
            DO_CALLBACKS(nMoved);
        } while (++nMoved < nToMove && loc != cycle);

        if (nMoved >= nToMove)
            break;

        for (;;) { 
            if (++cycle < maxcycle) {
                if (!member(done, cycle))
                    break;
            } else {
                if (!alreadydone(cycle, op, nrows, ncols))
                    break;
            }
        }
        assert(cycle > 0 && cycle < endloc);
    }
}

#define getNybble(base, pix) \
    (((pix) & 1) ?  ( base[(pix)/2] & 0xf) \
                 :  ((base[(pix)/2] >> 4) & 0xf))

#define putNybble(base, pix, val) \
    (((pix) & 1) ?  (base[(pix)/2] = (base[(pix)/2] & 0xf0) | ((val) & 0xf)) \
                 :  (base[(pix)/2] = (base[(pix)/2] & 0xf)  | \
                                        (((val) << 4) & 0xf0)))

/* In-place remap for 4-bit nybbles.
 */

void
in_remap4(PCDtransform op, unsigned char HUGE *image, long nrows, long ncols, 
          long nToMove, long maxcycle, SET done)
{
}

/* 
 * Normal (not in-place) remap for 8-bit bytes.
 */

void
remap8(PCDtransform op, unsigned char HUGE *from, unsigned char HUGE *to, 
       long columnBytes, long nrows, long ncols, long nToMove) 
{
    long colinc, rowinc;
    int ci, ri;
    long cx;
    long startoff;
    long nMoved = 0;

    calcXform(op, nrows, ncols, ncols * columnBytes,
            columnBytes * 8L, &startoff, &colinc, &rowinc);

    from += startoff;

    /* For remaps which exchange width and height... */
    if ((int)op & PCD_90_ROTATION) {
            long tmp = ncols;
            ncols = nrows;
            nrows = tmp;
    }
    for (ri = 0; ri < nrows; ri++) {
        DO_CALLBACKS(nMoved);
        for (cx = 0, ci = 0; ci < ncols; ci++) {
            *to = from[cx];
            cx += colinc;
            to += columnBytes;
        }
        from += rowinc;
        nMoved += ncols;
    }
}

/* 
 * Normal (not in-place) remap for 4-bit nybbles.
 */

void
remap4(PCDtransform op, unsigned char HUGE *from, unsigned char HUGE *to, 
       long nrows, long ncols, long nToMove)
{
}


/* 
 * "Simple" byte-wise in-place remap. 
 * Fast and no memory overhead, but only
 * works for mirrors / 180 rotates. 
 */
void FAR PASCAL
si_remap8(PCDtransform op, unsigned char HUGE *to, 
       long columnBytes, long nrows, long ncols) 
{
    long colinc, rowinc;
    int ci, ri;
    long cx;
    long startoff;
    long rowlim, collim;
    unsigned char HUGE *from = to;
    long nMoved = 0;

    calcXform(op, nrows, ncols, ncols * columnBytes,
            columnBytes * 8L, &startoff, &colinc, &rowinc);

    from += startoff;

    assert(((int)op & PCD_90_ROTATION) == 0);

    if (op == PCD_MIRROR_180) {
        rowlim = nrows / 2;
        collim = ncols;
    } else {
        rowlim = nrows;
        collim = ncols / 2;
    }
    for (ri = 0; ri < rowlim; ri++) {
        DO_CALLBACKS(nMoved);
        for (cx = 0, ci = 0; ci < collim; ci++) {
            unsigned char tmp = *to;
            *to = from[cx];
            from[cx] = tmp;
            cx += colinc;
            to += columnBytes;
            nMoved += 2;
        }
        to += ((ncols - collim) * columnBytes);
        from += rowinc;
    }
}

/* "Simple" nybble-wise in-place remap.
 * Fast and no memory overhead, but only
 * works for mirrors / 180 rotates. 
 */

void
si_remap4(PCDtransform op, unsigned char HUGE *to, long nrows, long ncols) 
{
}

typedef void FAR PASCAL SR8(PCDtransform, unsigned char HUGE *, 
                            long, long, long, long /* index or dummy */);
typedef SR8 FAR *SR8PTR;

PCDstatus FAR PASCAL
PCDapplyTransform(PCDbitmapHdl h, PCDtransform op, BOOL inplace, 
         FARPROC lpAbort, long lAbortData, 
         FARPROC lpProgress, long lProgressData,
         PCDbitmapHdl FAR *lpNewh)
{
    LPBITMAPINFO    lpb;
    HANDLE          hnew = 0; 
    long            nrows, ncols; 
    long           maxcycle;
    int             depth;
    unsigned char   HUGE *image, HUGE *newimage;
    SET             done = 0;
    long            nMoved = 0, nToMove;
    long            planeBytes, columnBytes;
    PCDstatus       retval = pcdSuccess;


    paramck(h);
    paramck(validTransform(op));
    if (!inplace)
        paramck(lpNewh != 0);

    /* This evil is due to the upside-down nature of DIBs. */
    if (op == PCD_MIRROR_90)
        op = PCD_MIRROR_270;
    else if (op == PCD_MIRROR_270)
        op = PCD_MIRROR_90;

/* 
 * Decode image header info
 */
    retval = getImageInfo(h, &lpb, &depth, &nrows, &ncols, 
                          &planeBytes, &columnBytes, &image);
    if (retval != pcdSuccess)
        return(retval);

    assert(lpb);
    assert(image);
    assert(planeBytes > 0);
    assert(depth == 4 || depth == 8 || depth == 24);

    nToMove = nrows * ncols;

    progressFunc = lpProgress;
    progressData = lProgressData;
    nKmovedBefore = 0;
    abtFunc = lpAbort;
    abtData = lAbortData;
    aborted = FALSE;

#define CHECK_ABORT \
if (aborted) { \
    aborted = FALSE; \
    retval = pcdUserAbort; \
    if (done) freeset(done); \
    goto out; \
}

    if (progressFunc) {
        denom = (short) ((depth * nToMove) / (8 * 1024));
        if (denom <= 0) denom = 1;
        (*progressFunc)(0, denom, progressData);
    }

    if (inplace) {
        /* Already done */
        if (op == PCD_ROTATE_0 || nrows <= 0 || ncols <= 0) {
            if (lpNewh) 
                *lpNewh = h;
            goto out;
        }
        /* Mirrors / 180 rotations can be done simply and quickly */
        if (((int)op & PCD_90_ROTATION) == 0) {
            switch(depth) {
            case 24:
                nKtoMove = (unsigned short) ((3 * nToMove) / 1024);
                /*
                 * Remap the red (or C2) pixels, then the green, etc.
                 */
                si_remap8(op, image + (2 * planeBytes), columnBytes, 
                            nrows, ncols); 
                CHECK_ABORT;
                nKmovedBefore += (unsigned short) (nToMove / 1024);
                si_remap8(op, image + planeBytes, columnBytes, 
                            nrows, ncols); 
                CHECK_ABORT;
                nKmovedBefore += (unsigned short) (nToMove / 1024);
                /*FALLTHROUGH*/
            case 8:
                if (depth == 8)
                    nKtoMove = (unsigned short) (nToMove / 1024);
                si_remap8(op, image, columnBytes, nrows, ncols); 
                CHECK_ABORT;
                break;
            default:
                h = 0;
                retval = pcdLazyHacker;
                goto out;
            }

            if (lpNewh) 
                *lpNewh = h;
            goto out;
        }

        /*
         * Odd multiples of 90 degree rotation need special handling.
         *
         * Try to allocate full-sized set. Halve maxcycle
         * until allocation succeeds.
         */

        for (maxcycle = ((nrows * ncols) / 2L) + 1L; 
             maxcycle > 0 && (done = allocset(maxcycle)) == 0;
             maxcycle /= 2)
                ;

        if (done == 0) {
            retval = ENOMEM;
            goto out;
        }

        switch(depth) {
        case 24:
            nKtoMove = (unsigned short) ((3 * nToMove) / 1024);
            /*
             * Remap the red (or C2) pixels, then the green, etc.
             */
            in_remap8(op, image + (2 * planeBytes), columnBytes, 
                      nrows, ncols, nToMove, maxcycle, done);
            CHECK_ABORT;
            emptyset(done);
            nKmovedBefore +=  (unsigned short) (nToMove / 1024);
            in_remap8(op, image + planeBytes, columnBytes, 
                      nrows, ncols, nToMove, maxcycle, done);
            CHECK_ABORT;
            emptyset(done);
            nKmovedBefore += (unsigned short) (nToMove / 1024);
        /*FALLTHROUGH*/
        case 8:
            if (depth == 8)
                nKtoMove = (unsigned short) (nToMove / 1024);
            in_remap8(op, image, columnBytes, 
                      nrows, ncols, nToMove, maxcycle, done);
            CHECK_ABORT;
            break;
        default:
            h = 0;
            retval = pcdLazyHacker;
            goto out;
        }
        freeset(done);
    } else {
        if ((retval = makeNewImage(h, &lpb, &hnew, &newimage)) != pcdSuccess)
            goto out;

        if (nrows <= 0 || ncols <= 0)
            goto out;

        switch(depth) {
        case 24:
            nKtoMove =  (unsigned short) ((3 * nToMove) / 1024);
            /*
             * Remap the red (or C2) pixels, then the green, etc.
             */
            remap8(op, image + (2 * planeBytes), 
                   newimage + (2 * planeBytes), columnBytes, 
                   nrows, ncols, nToMove) ;
            CHECK_ABORT;
            nKmovedBefore += (unsigned short) (nToMove / 1024);
            remap8(op, image + planeBytes, 
                   newimage + planeBytes, columnBytes, 
                   nrows, ncols, nToMove) ;
            CHECK_ABORT;
            nKmovedBefore += (unsigned short) (nToMove / 1024);
        /*FALLTHROUGH*/
        case 8:
            if (depth == 8)
                nKtoMove =  (unsigned short) (nToMove / 1024);
            remap8(op, image, 
                   newimage, columnBytes, 
                   nrows, ncols, nToMove) ;
            CHECK_ABORT;
            break;
        default:
            h = 0;
            freeImage(hnew);
            retval = pcdLazyHacker;
            goto out;
        }
        h = hnew;
    }
    /*
     * For remaps which exchange width and height...
     */
    if (op == PCD_ROTATE_90 || op == PCD_ROTATE_270 ||
        op == PCD_MIRROR_90 || op == PCD_MIRROR_270)
            swapRowCol(lpb);

    if (lpNewh) 
        *lpNewh = h;
out:

if (progressFunc)
    (*progressFunc)(denom, denom, progressData);

progressFunc = 0;
progressData = 0;
abtFunc = 0;
abtData = 0;

    relseImage(h);
    return(retval);
}

/*
 * Set up parameters for input transformations.
 */

#ifndef NBITSPERBYTE
#define NBITSPERBYTE 8
#endif

void
calcInputXform(PCDtransform xform, PCDformat format, PCDresolution step,
                short columnBytes, LPRECT r, long stride,
                LPLONG start, LPLONG colinc, LPLONG rowinc)
{
    long columnBits;
    short width, height;

    assert(r);
    assert(start);
    assert(colinc);
    assert(rowinc);

    columnBits = columnBytes * NBITSPERBYTE;

    calcXform(xform, (long) RectHeight(r), (long) RectWidth(r), stride, columnBits,
                start, colinc, rowinc);

    /* 
     * Input rectangle is how the user sees the data - convert
     * it into a rectangle describing the data to retrieve from
     * disk.
     */
    if (xform & PCD_90_ROTATION) {
        height = rowsiz(step);
        width = colsiz(step);
    } else {
        height = colsiz(step);
        width = rowsiz(step);
    }

    if (xform & PCD_VERT_MIRROR)
        RectVertMirror(r, width);

    /* Windows bitmaps are upside-down, so mirror about horizontal axis
    * is done iff not called for. Since user is not aware, rect need
    * not be transformed.
    */
    
    if (!(xform & PCD_HORIZ_MIRROR))
        RectHorizMirror(r, height);
    if (xform & PCD_90_ROTATION)
        RectRotate(r, height, width);
}


void
calcXform(PCDtransform op, long nrows, long ncols, 
          long stride, long columnBits,
          LPLONG start, LPLONG colinc, LPLONG rowinc)
{
    assert(start);
    assert(colinc);
    assert(rowinc);
    assert(validTransform(op));

#define UPPER_LEFT  ((long) 0)
#define UPPER_RIGHT (((ncols - 1L) * columnBits) / NBITSPERBYTE)
#define LOWER_LEFT  ((nrows - 1L) * stride)
#define LOWER_RIGHT (LOWER_LEFT + UPPER_RIGHT)

#define COLUMNBYTES (columnBits >= NBITSPERBYTE ? columnBits/NBITSPERBYTE : 1)

    switch (op) {
    case PCD_ROTATE_0:
        *start = UPPER_LEFT;
        *colinc = COLUMNBYTES;
        *rowinc = stride;
        break;
    case PCD_MIRROR_0:
        *start = UPPER_RIGHT;
        *colinc = -COLUMNBYTES;
        *rowinc = stride;
        break;
    case PCD_MIRROR_180:
        *start = LOWER_LEFT;
        *colinc = COLUMNBYTES;
        *rowinc = -stride;
        break;
    case PCD_ROTATE_180:
        *start = LOWER_RIGHT;
        *colinc = -COLUMNBYTES;
        *rowinc = -stride;
        break;
    case PCD_ROTATE_90:
        *start = LOWER_LEFT;
        *colinc = -stride;
        *rowinc = COLUMNBYTES;
        break;
    case PCD_MIRROR_270:
        *start = LOWER_RIGHT;
        *colinc = -stride;
        *rowinc = -COLUMNBYTES;
        break;
    case PCD_MIRROR_90:
        *start = UPPER_LEFT;
        *colinc = stride;
        *rowinc = COLUMNBYTES;
        break;
    case PCD_ROTATE_270:
        *start = UPPER_RIGHT;
        *colinc = stride;
        *rowinc = -COLUMNBYTES;
        break;
    default:
        assert(validTransform(op));
        break;
    }
}


/*
 * Convert between internal and external transformation
 * insuring that user gets upside-down data.
 */

PCDtransform
externalXform(PCDtransform op)
{
    switch(op) {
    case PCD_ROTATE_0:
        return(PCD_MIRROR_180);
    case PCD_ROTATE_90:
        return(PCD_MIRROR_90);
    case PCD_ROTATE_180:
        return(PCD_MIRROR_0);
    case PCD_ROTATE_270:
        return(PCD_MIRROR_270);
    case PCD_MIRROR_0:
        return(PCD_ROTATE_180);
    case PCD_MIRROR_90:
        return(PCD_ROTATE_90);
    case PCD_MIRROR_180:
        return(PCD_ROTATE_0);
    case PCD_MIRROR_270:
        return(PCD_ROTATE_270);
    default:
        assert(validTransform(op));
        return(op);
    }
}
