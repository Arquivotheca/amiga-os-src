#include <windows.h>
#include "pcdlib.h"
#include "pcdpriv.h"
#include "ycctab.h"
#include "pcdovw.h"
#include "showdib.h"

#define	CHUNKSIZE	((long)rowsiz(PCD_BASE_OVER_16) * 3L)

void
chkTo332(PCDRAWDATA FAR *lplpchk, PCDRAWDATA lp332)
{
	PCDRAWDATA lpchk = *lplpchk;
	PCDRAWDATA	lpy, lpc1, lpc2, yend;
	short		ysize, csize;
	short		yinc = 2;
	short		rv, gv, bv;

	ysize = rowsiz(PCD_BASE_OVER_16);
	csize = rowsiz(PCD_BASE_OVER_16) / 2;

	lpy = lpchk;
	yend = lpchk + ysize;
	lpc1 = lpy + (2 * ysize);
	lpc2 = lpc1 + csize;

	while (lpy < yend) {
		rv = RFROMYCC(*lpy, *lpc1, *lpc2);
		gv = GFROMYCC(*lpy, *lpc1, *lpc2);
		bv = BFROMYCC(*lpy, *lpc1, *lpc2);
/*		use lut instead; (3-11-93)
		clamp(rv);
		clamp(gv);
		clamp(bv);
*/
		rv = MAPTHROUGHLUT(rv);
		gv = MAPTHROUGHLUT(gv);
		bv = MAPTHROUGHLUT(bv);

		*lp332++ = (rv & 0xe0) | ((gv >> 3) & 0x1c) | ((bv >> 6) & 0x3);
		lpy += yinc;
		lpc1++;
		lpc2++;
	}
	*lplpchk = lpchk + (2 * ysize) + (2 * csize);
}

void
chkToYCC(PCDRAWDATA FAR *lplpchk, PCDRAWDATA lpYCC)
{
	PCDRAWDATA lpchk = *lplpchk;
	PCDRAWDATA	lpy, lpc1, lpc2, yend;
	short		ysize, csize;
	short		yinc = 2;
	short		rv, gv, bv;

	ysize = rowsiz(PCD_BASE_OVER_16);
	csize = rowsiz(PCD_BASE_OVER_16) / 2;

	lpy = lpchk;
	yend = lpchk + ysize;
	lpc1 = lpy + (2 * ysize);
	lpc2 = lpc1 + csize;

	while (lpy < yend) {
		*lpYCC++ = *lpy;
		*lpYCC++ = *lpc1++;
		*lpYCC++ = *lpc2++;

		lpy += yinc;
	}
	*lplpchk = lpchk + (2 * ysize) + (2 * csize);
}

void
chkToRGB(PCDRAWDATA FAR *lplpchk, PCDRAWDATA lpRGB)
{
	PCDRAWDATA lpchk = *lplpchk;
	PCDRAWDATA	lpy, lpc1, lpc2, yend;
	short		ysize, csize;
	short		yinc = 2;
	short		rv, gv, bv;

	ysize = rowsiz(PCD_BASE_OVER_16);
	csize = rowsiz(PCD_BASE_OVER_16) / 2;

	lpy = lpchk;
	yend = lpchk + ysize;
	lpc1 = lpy + (2 * ysize);
	lpc2 = lpc1 + csize;

	while (lpy < yend) {
		rv = RFROMYCC(*lpy, *lpc1, *lpc2);
		gv = GFROMYCC(*lpy, *lpc1, *lpc2);
		bv = BFROMYCC(*lpy, *lpc1, *lpc2);
/* 		use lut instead; (3-11-93)
		clamp(rv);
		clamp(gv);
		clamp(bv);

		*lpRGB++ = bv;
		*lpRGB++ = gv;
		*lpRGB++ = rv;
*/
		*lpRGB++ = MAPTHROUGHLUT(bv);
		*lpRGB++ = MAPTHROUGHLUT(gv);
		*lpRGB++ = MAPTHROUGHLUT(rv);

		lpy += yinc;
		lpc1++;
		lpc2++;
	}
	*lplpchk = lpchk + (2 * ysize) + (2 * csize);
}

void
chkToGray(PCDRAWDATA FAR *lplpchk, PCDRAWDATA lpGray)
{
	PCDRAWDATA lpchk = *lplpchk;
	PCDRAWDATA	lpy, yend;
	short		ysize, csize;
	short		yinc = 2;

	ysize = rowsiz(PCD_BASE_OVER_16);
	csize = rowsiz(PCD_BASE_OVER_16) / 2;

	lpy = lpchk;
	yend = lpchk + ysize;

	while (lpy < yend) {
		*lpGray++ = *lpy;
		lpy += yinc;
	}
	*lplpchk = lpchk + (2 * ysize) + (2 * csize);
}

#define	OVIEW_LINES ((long)colsiz(PCD_BASE_OVER_64))
#define	OVIEW_WIDTH	CHUNKSIZE
#define	OVIEW_SIZE	(OVIEW_WIDTH * OVIEW_LINES)

HANDLE
ReadOview(int fd)
{
	HANDLE h, hDib;
	PCDRAWDATA	lpchk, lp332;
	PCDresolution step = PCD_BASE_OVER_64;
	long stride; 
	int i;

	if (!MakeEmptyDIB(rowsiz(step), colsiz(step), PCD_PALETTE, &hDib, &lp332))
		return(0);
	if ((h = GlobalAlloc(GMEM_FIXED, OVIEW_SIZE)) == 0) {
		return(0);
	}
	if ((lpchk = (PCDRAWDATA)GlobalLock(h)) == 0) {
		GlobalFree(h);
	}
	lread(fd, lpchk, OVIEW_SIZE);
	stride = rowsiz(step);
	for (i = 0; i < OVIEW_LINES; i++) {
		chkTo332(&lpchk, lp332);
		lp332 += stride;
	}
	GlobalUnlock(h);
	GlobalFree(h);
	return(hDib);
}

#define	BORDERWIDTH	8L
#define	MAX_OVIEWS	32L

HANDLE
ReadNOviews(int fd, int n, PCDformat fmt)
{
	HANDLE h, hDib;
	PCDRAWDATA	lpchk, lp332;
	PCDresolution step = PCD_BASE_OVER_64;
	int depth;
	int i, j, k;
	extern BOOL bDoYCC;
	PCDRAWDATA	chkptrs[MAX_OVIEWS];

	if (n < 0 || n > MAX_OVIEWS)
		return(0);
	if (!MakeEmptyDIB((long)n * (BORDERWIDTH + rowsiz(step)), colsiz(step), 
					fmt, &hDib, &lp332))
		return(0);
	if ((h = GlobalAlloc(GMEM_FIXED, (long)n * OVIEW_SIZE)) == 0) {
		return(0);
	}
	if ((lpchk = (PCDRAWDATA)GlobalLock(h)) == 0) {
		GlobalFree(h);
	}
	switch (fmt) {
	case PCD_PALETTE:
	case PCD_SINGLE:
		depth = 1;
		break;
	default:
		depth = 3;
	}
	chkptrs[0] = lpchk;
	for (j = 1; j < n; j++)
		chkptrs[j] = chkptrs[j - 1] + OVIEW_SIZE;

	lread(fd, lpchk, (long)n * OVIEW_SIZE);

	if (!bDoYCC) 
		goto out;

	for (i = 0; i < OVIEW_LINES; i++) {
		for (j = 0; j < n; j++) {
			for (k = 0; k < BORDERWIDTH * depth; k++)
				*lp332++ = 255;
			lpchk = chkptrs[j];
			switch(fmt) {
			case PCD_SINGLE:
				chkToGray(&lpchk, lp332);
				break;
			case PCD_RGB:
				chkToRGB(&lpchk, lp332);
				break;
			case PCD_YCC:
				chkToYCC(&lpchk, lp332);
				break;
			case PCD_PALETTE:
				chkTo332(&lpchk, lp332);
			}
			chkptrs[j] = lpchk;
			lp332 += depth * rowsiz(step);
		}
	}
out:
	GlobalUnlock(h);
	GlobalFree(h);
	return(hDib);
}
