/*
 *	Photo CD Development Toolkit
 *
 *	x.c
 *	eXport functions
 *
 *	Copyright (c) 1993, Eastman Kodak Corporation.
 *	All rights reserved.
 */

/*\
 *		NOTE   NOTE    NOTE    NOTE   NOTE    NOTE
 *
 *		The export functions are no longer supported as part of the
 *		PhotoCD Toolkit.  The PCDexport function, included in this
 *		source module, is simply a place holder to prevent previously
 *		built applications that use PCDexport from crashing if this
 *		version of the Toolkit is used. 
\*/

#include <windows.h>
#include "pcdlib.h"

PCDstatus FAR PASCAL
PCDexport(PCDphotoHdl hPcd, LPRECT lpRect, LPSTR lpszXname, LPSTR lpszFile)
{

	return(pcdNotAvailable);

}
